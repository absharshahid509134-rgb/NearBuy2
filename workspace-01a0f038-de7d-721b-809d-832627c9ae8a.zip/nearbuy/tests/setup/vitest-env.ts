/**
 * Env for the Vitest worker process.
 *
 * globalSetup runs in the parent process, so anything it sets in process.env
 * is invisible to the workers. Anything a module reads at import time has to be
 * present here as well.
 */
const e = process.env as Record<string, string | undefined>;
e.NODE_ENV ??= "test";
e.DATABASE_URL ??= "file:./test.db";
e.SESSION_SECRET ??= "test-secret-that-is-definitely-long-enough-32";
e.HANDOFF_ENCRYPTION_KEY ??= "dGVzdC0zMi1ieXRlLXRlc3QtaGFuZG9mZi1rZXkhIQ==";
e.APP_URL ??= "http://127.0.0.1:3123";
e.STORAGE_DRIVER ??= "local";
e.ENABLE_DEMO_ACCOUNTS ??= "true";
