import { execFileSync, spawn } from "node:child_process";
import { rmSync, existsSync, openSync } from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const PORT = Number(process.env.TEST_PORT ?? 3123);
const BASE = `http://127.0.0.1:${PORT}`;
const DB_FILE = path.join(ROOT, "prisma", "test.db");

let server: ReturnType<typeof spawn> | null = null;

export async function setup() {
  // A dedicated database file per run: tests never touch dev data, and a
  // failed run cannot leave residue behind.
  for (const f of [DB_FILE, `${DB_FILE}-journal`]) {
    if (existsSync(f)) rmSync(f, { force: true });
  }

  const env: NodeJS.ProcessEnv = {
    ...process.env,
    NODE_ENV: "development",
    PORT: String(PORT),
    DATABASE_URL: `file:./test.db`,
    APP_URL: BASE,
    SESSION_SECRET: "test-secret-that-is-definitely-long-enough-32",
    HANDOFF_ENCRYPTION_KEY: "dGVzdC0zMi1ieXRlLXRlc3QtaGFuZG9mZi1rZXkhIQ==",
    STORAGE_DRIVER: "local",
    ENABLE_DEMO_ACCOUNTS: "true",
    DEMO_PASSWORD: "NearBuy@2026",
    // Every test comes from the same loopback IP, so the production signup
    // throttle would (correctly) block the suite. auth.test.ts still asserts
    // the limiter works by lowering nothing — it simply exhausts a high bar.
    SIGNUP_RATE_LIMIT: "10000",
    LOGIN_RATE_LIMIT: "8",
  };

  // `detached: true` puts the server in its own process group. Without it,
  // killing the npx wrapper leaves the actual `next dev` child alive holding
  // the port and the database, and the next run talks to a stale process.
  // The server log is kept on disk: when an integration test fails, the
  // server-side error line is usually the real explanation.
  const logFd = openSync(path.join(ROOT, "test-server.log"), "w");
  server = spawn("npx", ["next", "dev", "-H", "127.0.0.1", "-p", String(PORT)], {
    cwd: ROOT,
    env,
    stdio: ["ignore", logFd, logFd],
    detached: true,
  });

  const deadline = Date.now() + 120_000;
  let healthy = false;
  while (Date.now() < deadline) {
    if (server.exitCode !== null) {
      throw new Error(`Test server exited early with code ${server.exitCode}.`);
    }
    try {
      const res = await fetch(`${BASE}/api/health`);
      if (res.ok) {
        healthy = true;
        break;
      }
    } catch {
      /* not up yet */
    }
    await new Promise((r) => setTimeout(r, 700));
  }
  if (!healthy) throw new Error(`Test server did not become healthy within 120s at ${BASE}.`);

  // Apply migrations to the test database, then seed it.
  execFileSync("npx", ["tsx", "scripts/migrate.ts"], { cwd: ROOT, env, stdio: "pipe" });
  execFileSync("npx", ["tsx", "scripts/seed.ts"], { cwd: ROOT, env, stdio: "pipe" });

  (globalThis as Record<string, unknown>).__NEARBUY_TEST_BASE__ = BASE;
}

export async function teardown() {
  if (!server?.pid) return;
  // Signal the whole group so `next dev` and its children all go away.
  const killGroup = (signal: NodeJS.Signals) => {
    try {
      process.kill(-server!.pid!, signal);
    } catch {
      try {
        server!.kill(signal);
      } catch {
        /* already gone */
      }
    }
  };
  killGroup("SIGTERM");
  await new Promise((r) => setTimeout(r, 800));
  killGroup("SIGKILL");
}
