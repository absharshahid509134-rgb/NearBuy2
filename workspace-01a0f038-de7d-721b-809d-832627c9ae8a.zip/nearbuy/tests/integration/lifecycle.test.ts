import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";
import {
  addProduct,
  addToCart,
  defaultAddressId,
  idemKey,
  makeCustomer,
  makeRider,
  makeSeller,
} from "./fixtures";

/**
 * The full cross-role lifecycle, exercised over real HTTP against the real
 * database. This is the acceptance walkthrough: one order moves through
 * Customer -> Seller -> Rider -> Customer, and after every step each role must
 * observe exactly the same persisted state.
 */

type OrderView = {
  id: string;
  orderNumber: string;
  status: string;
  fulfillmentType: string;
  pickupCode?: string;
  deliveryCode?: string;
  pickupCodeHint: string | null;
  deliveryCodeHint: string | null;
  customerId: string;
  storeId: string;
  subtotalPaise: number;
  deliveryFeePaise: number;
  totalPaise: number;
};

let seller: TestClient;
let customer: TestClient;
let rider: TestClient;
let addressId: string;
let order: OrderView;
let jobId: string;
let pickupCode = "";
let deliveryCode = "";

const load = (c: TestClient, id: string) => c.get<{ order: OrderView }>(`/api/orders/${id}`);
const orderOf = async (c: TestClient, id: string) =>
  data<{ order: OrderView }>((await load(c, id)).body).order;

async function sellerMove(status: string) {
  const res = await seller.post(`/api/seller/orders/${order.id}/status`, { status });
  expect(res.status, `${status}: ${JSON.stringify(res.body)}`).toBe(200);
  return data<{ order: OrderView }>(res.body).order;
}

beforeAll(async () => {
  seller = await makeSeller("lifecycle");
  const productId = await addProduct(seller, "Aashirvaad Atta 5kg", 28500, 10);
  customer = await makeCustomer("lifecyclecust");
  addressId = await defaultAddressId(customer);
  await addToCart(customer, productId, 2);

  const res = await customer.post("/api/checkout", {
    fulfillmentType: "DELIVERY",
    addressId,
    idempotencyKey: idemKey("lifecycle"),
  });
  expect(res.status, JSON.stringify(res.body)).toBe(201);
  order = data<{ orders: OrderView[] }>(res.body).orders[0];
});

describe("cross-role order lifecycle", () => {
  it("starts PLACED with correct INR totals and no delivery job yet", () => {
    expect(order.status).toBe("PLACED");
    expect(order.fulfillmentType).toBe("DELIVERY");
    // 2 × ₹285.00 = ₹570.00, plus a delivery fee on top.
    expect(order.subtotalPaise).toBe(57000);
    expect(order.deliveryFeePaise).toBeGreaterThan(0);
    expect(order.totalPaise).toBe(order.subtotalPaise + order.deliveryFeePaise);
  });

  it("shows the customer their order but no handoff codes", async () => {
    const view = await orderOf(customer, order.id);
    expect(view.status).toBe("PLACED");
    expect(view.pickupCode).toBeUndefined();
    expect(view.pickupCodeHint).toBeNull();
    expect(view.deliveryCodeHint).toBeNull();
  });

  it("stops the customer accepting their own order", async () => {
    const res = await customer.post(`/api/orders/${order.id}/status`, { status: "ACCEPTED" });
    expect(res.status).toBe(403);
    expect(err(res.body).code).toBe("FORBIDDEN");
  });

  it("stops the seller skipping from PLACED straight to DELIVERED", async () => {
    const res = await seller.post(`/api/seller/orders/${order.id}/status`, { status: "DELIVERED" });
    expect(res.status).toBe(409);
  });

  it("moves seller-side: ACCEPTED → PREPARING → PACKED → READY_FOR_PICKUP", async () => {
    expect((await sellerMove("ACCEPTED")).status).toBe("ACCEPTED");
    expect((await sellerMove("PREPARING")).status).toBe("PREPARING");
    expect((await sellerMove("PACKED")).status).toBe("PACKED");
    expect((await sellerMove("READY_FOR_PICKUP")).status).toBe("READY_FOR_PICKUP");
  });

  it("reveals the pickup code to the seller only, and the customer still cannot see it", async () => {
    const sellerView = await orderOf(seller, order.id);
    expect(sellerView.pickupCode, "seller must see the pickup code once ready").toMatch(/^\d{6}$/);
    expect(sellerView.deliveryCode).toBeUndefined();
    expect(sellerView.deliveryCodeHint).toBeNull();
    pickupCode = sellerView.pickupCode!;

    const customerView = await orderOf(customer, order.id);
    expect(customerView.pickupCode).toBeUndefined();
    expect(customerView.pickupCodeHint).toBeNull();
  });

  it("publishes a delivery job a rider can find", async () => {
    rider = await makeRider("lifecyclerider");
    const jobs = await rider.get("/api/rider/jobs");
    expect(jobs.status).toBe(200);
    const view = data<{ jobs: Array<{ id: string; orderId: string; status: string }> }>(jobs.body);
    const job = view.jobs.find((j) => j.orderId === order.id);
    expect(job, "a delivery order must publish a rider job").toBeTruthy();
    expect(job!.status).toBe("AVAILABLE");
    jobId = job!.id;
  });

  it("lets the claiming rider claim it, and only that rider sees it as assigned", async () => {
    const claim = await rider.post(`/api/rider/jobs/${jobId}/claim`);
    expect(claim.status, JSON.stringify(claim.body)).toBe(200);

    const mine = data<{
      active: Array<{ id: string; orderId: string; status: string }>;
      jobs: Array<{ id: string; orderId: string; status: string }>;
    }>((await rider.get("/api/rider/jobs")).body);
    expect(mine.active.find((j) => j.id === jobId)?.status).toBe("ASSIGNED");
    // And it leaves the shared pool, so no second rider can pick it up.
    expect(mine.jobs.find((j) => j.id === jobId)).toBeUndefined();
  });

  it("rejects a wrong pickup code without moving the order", async () => {
    const wrong = `${(Number(pickupCode) + 111111) % 1000000}`.padStart(6, "0");
    const res = await rider.post(`/api/rider/jobs/${jobId}/pickup`, { code: wrong });
    expect(res.status).toBe(409);
    expect(err(res.body).message).toMatch(/code/i);
    expect((await orderOf(seller, order.id)).status).toBe("READY_FOR_PICKUP");
  });

  it("rejects a pickup attempt from a rider who does not hold the job", async () => {
    const other = await makeRider("lifecycleother");
    const res = await other.post(`/api/rider/jobs/${jobId}/pickup`, { code: pickupCode });
    expect(res.status).toBe(403);
  });

  it("accepts the correct pickup code and moves the order to PICKED_UP", async () => {
    const res = await rider.post(`/api/rider/jobs/${jobId}/pickup`, { code: pickupCode });
    expect(res.status, JSON.stringify(res.body)).toBe(200);
    expect((await orderOf(customer, order.id)).status).toBe("PICKED_UP");
  });

  it("now shows the delivery code to the customer, and never to the seller", async () => {
    const customerView = await orderOf(customer, order.id);
    expect(customerView.deliveryCode).toMatch(/^\d{6}$/);
    deliveryCode = customerView.deliveryCode!;
    // The customer must not be able to read the seller's pickup code either.
    expect(customerView.pickupCode).toBeUndefined();

    const sellerView = await orderOf(seller, order.id);
    expect(sellerView.deliveryCode).toBeUndefined();
    expect(sellerView.deliveryCodeHint).toBeNull();
  });

  it("refuses to start delivery before the pickup is verified", async () => {
    // Already PICKED_UP here, so the happy path applies:
    const res = await rider.post(`/api/rider/jobs/${jobId}/delivery`);
    expect(res.status).toBe(200);
    expect((await orderOf(customer, order.id)).status).toBe("OUT_FOR_DELIVERY");
  });

  it("refuses a wrong delivery code", async () => {
    const wrong = `${(Number(deliveryCode) + 222222) % 1000000}`.padStart(6, "0");
    const res = await rider.post(`/api/rider/jobs/${jobId}/complete`, { code: wrong });
    expect(res.status).toBe(409);
    expect(err(res.body).message).toMatch(/code/i);
    expect((await orderOf(customer, order.id)).status).toBe("OUT_FOR_DELIVERY");
  });

  it("completes delivery with the correct code and persists it for every role", async () => {
    const res = await rider.post(`/api/rider/jobs/${jobId}/complete`, { code: deliveryCode });
    expect(res.status, JSON.stringify(res.body)).toBe(200);

    const [c, s, r] = await Promise.all([
      orderOf(customer, order.id),
      orderOf(seller, order.id),
      orderOf(rider, order.id),
    ]);
    expect([c.status, s.status, r.status]).toEqual(["DELIVERED", "DELIVERED", "DELIVERED"]);
  });

  it("records the delivery in the rider's earnings", async () => {
    const res = await rider.get("/api/rider/earnings");
    expect(res.status).toBe(200);
    const body = data<{ totalPaise: number; completedCount: number; history: Array<{ orderNumber: string }> }>(
      res.body,
    );
    expect(body.completedCount).toBe(1);
    // The rider earns a share of the order value, never the whole basket.
    expect(body.totalPaise).toBeGreaterThan(0);
    expect(body.totalPaise).toBeLessThan(order.totalPaise);
    expect(body.history[0].orderNumber).toBe(order.orderNumber);
  });

  it("closes the order to any further transition", async () => {
    const res = await seller.post(`/api/seller/orders/${order.id}/status`, { status: "CANCELLED" });
    expect(res.status).toBe(409);
  });
});
