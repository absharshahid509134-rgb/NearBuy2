import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";
import { addProduct, makeCustomer, makeRider, makeSeller } from "./fixtures";

/**
 * Role isolation. Every workspace API is probed with the wrong role and with no
 * session at all, because a UI that hides a button is not a security control —
 * the server has to refuse the call on its own.
 */

let customer: TestClient;
let seller: TestClient;
let rider: TestClient;

const GET_ONLY = [
  "/api/seller/dashboard",
  "/api/seller/products",
  "/api/seller/orders",
  "/api/seller/reservations",
  "/api/seller/stock-requests",
  "/api/rider/jobs",
  "/api/rider/earnings",
  "/api/rider/profile",
  "/api/cart",
  "/api/orders",
  "/api/addresses",
  "/api/reservations",
  "/api/stock-requests",
  "/api/stores/mine",
];

const WRITE_ACTIONS: Array<{ path: string; method: "post" | "put" | "patch" | "del"; body?: unknown }> = [
  { path: "/api/cart/items", method: "post", body: { productId: "x", quantity: 1 } },
  { path: "/api/checkout", method: "post", body: { fulfillmentType: "PICKUP", idempotencyKey: "iso-1" } },
  { path: "/api/addresses", method: "post", body: { label: "Home", fullName: "X", phone: "9810012345", line1: "1", city: "New Delhi", state: "Delhi", pincode: "110001", latitude: 28.5, longitude: 77.1 } },
  { path: "/api/reservations", method: "post", body: { productId: "x", quantity: 1 } },
  { path: "/api/stock-requests", method: "post", body: { productId: "x", quantity: 1 } },
  { path: "/api/seller/products", method: "post", body: { name: "X" } },
  { path: "/api/stores/mine", method: "post", body: { name: "X" } },
  { path: "/api/rider/profile", method: "patch", body: { isAvailable: true } },
  { path: "/api/rider/jobs/fake-job-id/claim", method: "post" },
];

beforeAll(async () => {
  customer = await makeCustomer("iso-cust");
  seller = await makeSeller("iso-sell");
  rider = await makeRider("iso-ride");
});

describe("role isolation", () => {
  it("refuses every workspace read with no session at all", async () => {
    const anon = new TestClient("anon");
    for (const path of GET_ONLY) {
      const res = await anon.get(path);
      expect(res.status, `${path} should require a session, got ${res.status}`).toBe(401);
    }
  });

  it("refuses every workspace write with no session at all", async () => {
    const anon = new TestClient("anon");
    for (const action of WRITE_ACTIONS) {
      const res = await anon.request(action.path, { method: action.method.toUpperCase(), json: action.body ?? {} });
      expect(res.status, `${action.method.toUpperCase()} ${action.path}`).toBe(401);
    }
  });

  it("keeps seller endpoints away from customers and riders", async () => {
    const sellerPaths = GET_ONLY.filter((p) => p.startsWith("/api/seller") || p === "/api/stores/mine");
    for (const client of [customer, rider]) {
      for (const path of sellerPaths) {
        const res = await client.get(path);
        expect([401, 403], `${client.label} GET ${path} -> ${res.status}`).toContain(res.status);
      }
    }
  });

  it("keeps rider endpoints away from customers and sellers", async () => {
    for (const client of [customer, seller]) {
      for (const path of ["/api/rider/jobs", "/api/rider/earnings", "/api/rider/profile"]) {
        const res = await client.get(path);
        expect([401, 403], `${client.label} GET ${path} -> ${res.status}`).toContain(res.status);
      }
      const claim = await client.post("/api/rider/jobs/fake/claim");
      expect([401, 403], `${client.label} POST claim -> ${claim.status}`).toContain(claim.status);
    }
  });

  it("keeps customer endpoints away from sellers and riders", async () => {
    for (const client of [seller, rider]) {
      for (const path of ["/api/cart", "/api/orders", "/api/addresses", "/api/reservations", "/api/stock-requests"]) {
        const res = await client.get(path);
        expect([401, 403], `${client.label} GET ${path} -> ${res.status}`).toContain(res.status);
      }
      const checkout = await client.post("/api/checkout", {
        fulfillmentType: "PICKUP",
        idempotencyKey: `iso-${client.label}`,
      });
      expect([401, 403], `${client.label} POST /api/checkout -> ${checkout.status}`).toContain(checkout.status);
    }
  });

  it("stops a seller creating a product on somebody else's store", async () => {
    const other = await makeSeller("iso-other");
    const mine = await other.post("/api/seller/products", {
      name: "Tata Salt 1kg", description: "Iodised salt", category: "Grocery", unit: "1 kg",
      pricePaise: 2800, stockQuantity: 10, status: "PUBLISHED",
    });
    expect(mine.status).toBe(201);
    const productId = data<{ product: { id: string } }>(mine.body).product.id;

    // The other seller is not the owner, so every write must be refused.
    const edit = await seller.patch(`/api/seller/products/${productId}`, { pricePaise: 1 });
    expect([403, 404], `patch -> ${edit.status}`).toContain(edit.status);
    const archive = await seller.del(`/api/seller/products/${productId}`);
    expect([403, 404], `delete -> ${archive.status}`).toContain(archive.status);

    // ...and the price is unchanged for the real owner.
    const listed = data<{ products: Array<{ id: string; pricePaise: number }> }>(
      (await other.get("/api/seller/products")).body,
    ).products;
    expect(listed.find((p) => p.id === productId)?.pricePaise).toBe(2800);
  });

  it("stops a customer reading another customer's order by guessing its id", async () => {
    const victim = await makeCustomer("iso-victim");
    const stranger = await makeCustomer("iso-stranger");
    const sellerSide = await makeSeller("iso-orders");
    const productId = await addProduct(sellerSide, "Britannia Bread 400g", 4500, 5);
    await new TestClient("noop");
    const { addToCart, defaultAddressId, idemKey } = await import("./fixtures");
    const addressId = await defaultAddressId(victim);
    await addToCart(victim, productId, 1);
    const placed = await victim.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId, idempotencyKey: idemKey("iso-order"),
    });
    expect(placed.status).toBe(201);
    const orderId = data<{ orders: Array<{ id: string }> }>(placed.body).orders[0].id;

    const peek = await stranger.get(`/api/orders/${orderId}`);
    expect([403, 404], `stranger GET order -> ${peek.status}`).toContain(peek.status);

    const strangerList = await stranger.get("/api/orders");
    expect(
      data<{ orders: Array<{ id: string }> }>(strangerList.body).orders.some((o) => o.id === orderId),
    ).toBe(false);

    // The rightful owner still sees it.
    expect((await victim.get(`/api/orders/${orderId}`)).status).toBe(200);
  });

  it("reports a missing order the same way as a forbidden one", async () => {
    const stranger = await makeCustomer("iso-stranger2");
    const res = await stranger.get("/api/orders/does-not-exist");
    expect(res.status).toBe(404);
    expect(err(res.body).code).toBe("NOT_FOUND");
  });
});
