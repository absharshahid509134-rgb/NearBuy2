import { TestClient, data } from "../helpers/client";

/**
 * Shared fixtures for the integration suite.
 *
 * Tests share one server and one database and run sequentially, so each test
 * file registers its own uniquely-named accounts rather than reusing the
 * seeded demo ones. That keeps files independent of the order they run in.
 */
export const PASSWORD = "Str0ng!Passw0rd";

let counter = 0;
export const uniqueEmail = (prefix: string) =>
  `${prefix}.${process.pid}.${Date.now()}.${counter++}@test.local`;

export async function makeCustomer(prefix = "cust"): Promise<TestClient> {
  const c = new TestClient(prefix);
  const res = await c.signup("CUSTOMER", uniqueEmail(prefix), PASSWORD);
  if (res.status !== 201) throw new Error(`customer signup failed: ${JSON.stringify(res.body)}`);
  return c;
}

/**
 * `publish` controls the store's visibility, not whether it exists: a DRAFT
 * store is what the "unpublished store" acceptance test needs.
 */
export async function makeSeller(prefix = "sell", publish = true): Promise<TestClient> {
  const s = new TestClient(prefix);
  const res = await s.signup("SELLER", uniqueEmail(prefix), PASSWORD);
  if (res.status !== 201) throw new Error(`seller signup failed: ${JSON.stringify(res.body)}`);

  {
    const store = await s.post("/api/stores/mine", {
      name: `${prefix} Fresh Mart`,
      description: "A neighbourhood test store selling everyday essentials.",
      category: "Grocery",
      addressLine1: "Plot 9, Sector 12, Dwarka",
      city: "New Delhi",
      state: "Delhi",
      pincode: "110075",
      latitude: 28.5921,
      longitude: 77.046,
      phone: "011-4000 1234",
      openingTime: "07:00",
      closingTime: "22:00",
      operatingDays: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
      supportsDelivery: true,
      supportsPickup: true,
      deliveryEtaMinutes: 30,
      isOpen: true,
      status: publish ? "PUBLISHED" : "DRAFT",
    });
    if (store.status !== 201) {
      throw new Error(`store creation failed: ${JSON.stringify(store.body)}`);
    }
  }
  return s;
}

export async function makeRider(prefix = "ride"): Promise<TestClient> {
  const r = new TestClient(prefix);
  const res = await r.signup("RIDER", uniqueEmail(prefix), PASSWORD);
  if (res.status !== 201) throw new Error(`rider signup failed: ${JSON.stringify(res.body)}`);
  return r;
}

export async function addProduct(
  seller: TestClient,
  name: string,
  pricePaise: number,
  stock: number,
): Promise<string> {
  const res = await seller.post("/api/seller/products", {
    name,
    description: `${name} — a dependable everyday product for the neighbourhood.`,
    category: "Grocery",
    unit: "1 pc",
    pricePaise,
    stockQuantity: stock,
    lowStockThreshold: 2,
    isAvailable: true,
    status: "PUBLISHED",
  });
  if (res.status !== 201) {
    throw new Error(`product creation failed for ${name}: ${JSON.stringify(res.body)}`);
  }
  return data<{ product: { id: string } }>(res.body).product.id;
}

/** Adds to cart and returns the resulting cart view. */
export async function addToCart(customer: TestClient, productId: string, quantity: number) {
  const res = await customer.post("/api/cart/items", { productId, quantity });
  if (res.status !== 200) {
    throw new Error(`add to cart failed: ${JSON.stringify(res.body)}`);
  }
  return res;
}

export async function defaultAddressId(customer: TestClient): Promise<string> {
  const res = await customer.get<{ addresses: Array<{ id: string; isDefault: boolean }> }>("/api/addresses");
  const list = data<{ addresses: Array<{ id: string; isDefault: boolean }> }>(res.body).addresses;
  return (list.find((a) => a.isDefault) ?? list[0]).id;
}

let keyCounter = 0;
/** A unique idempotency key per logical checkout attempt. */
export const idemKey = (label = "checkout") => `${label}-${process.pid}-${Date.now()}-${keyCounter++}`;

export async function stockOf(seller: TestClient, productId: string): Promise<number> {
  const res = await seller.get(`/api/seller/products`);
  const products = data<{ products: Array<{ id: string; inventory: { stockQuantity: number } | null }> }>(
    res.body,
  ).products;
  return products.find((p) => p.id === productId)?.inventory?.stockQuantity ?? -1;
}
