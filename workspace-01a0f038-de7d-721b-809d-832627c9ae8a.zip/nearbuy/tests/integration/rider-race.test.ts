import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";
import {
  addProduct,
  addToCart,
  defaultAddressId,
  idemKey,
  makeCustomer,
  makeRider,
  makeSeller,
} from "./fixtures";

/**
 * Concurrency. Two riders pressing "Claim" on the same job at the same moment
 * must produce exactly one winner — the loser is a 409, never a double
 * assignment. The service does this with a conditional update, and this suite
 * exists to prove the database, not the UI, is what settles it.
 */

let jobId: string;
const riders: TestClient[] = [];

beforeAll(async () => {
  const seller = await makeSeller("race");
  const productId = await addProduct(seller, "Fortune Sunflower Oil 1L", 14500, 20);
  const customer = await makeCustomer("racecust");
  const addressId = await defaultAddressId(customer);
  await addToCart(customer, productId, 1);
  const placed = await customer.post("/api/checkout", {
    fulfillmentType: "DELIVERY", addressId, idempotencyKey: idemKey("race"),
  });
  expect(placed.status, JSON.stringify(placed.body)).toBe(201);
  const orderId = data<{ orders: Array<{ id: string }> }>(placed.body).orders[0].id;

  for (const status of ["ACCEPTED", "PREPARING", "PACKED", "READY_FOR_PICKUP"]) {
    const res = await seller.post(`/api/seller/orders/${orderId}/status`, { status });
    expect(res.status, `${status}: ${JSON.stringify(res.body)}`).toBe(200);
  }

  for (let i = 0; i < 4; i++) riders.push(await makeRider(`racer${i}`));

  const pool = data<{ jobs: Array<{ id: string; orderId: string }> }>(
    (await riders[0].get("/api/rider/jobs")).body,
  );
  const job = pool.jobs.find((j) => j.orderId === orderId);
  expect(job, "the ready order must publish a claimable job").toBeTruthy();
  jobId = job!.id;
});

describe("rider job claiming", () => {
  it("gives the job to exactly one rider when four claim it at once", async () => {
    const results = await Promise.all(riders.map((r) => r.post(`/api/rider/jobs/${jobId}/claim`)));

    const winners = results.filter((r) => r.status === 200);
    const losers = results.filter((r) => r.status === 409);
    expect(winners, `expected 1 winner, got ${winners.length}`).toHaveLength(1);
    expect(losers).toHaveLength(riders.length - 1);
    for (const loser of losers) {
      expect(err(loser.body).message).toMatch(/another rider|already claimed|taken/i);
    }
  });

  it("rejects a second claim from the rider that already won", async () => {
    const winnerIndex = (
      await Promise.all(riders.map(async (r) => (await r.post(`/api/rider/jobs/${jobId}/claim`)).status))
    ).indexOf(200);
    expect(winnerIndex, "re-claiming must never return 200 twice").toBeGreaterThanOrEqual(0);
  });

  it("shows the job as assigned to only that one rider", async () => {
    const views = await Promise.all(
      riders.map(async (r) =>
        data<{ active: Array<{ id: string }>; jobs: Array<{ id: string }> }>(
          (await r.get("/api/rider/jobs")).body,
        ),
      ),
    );
    const assigned = views.filter((v) => v.active.some((j) => j.id === jobId));
    expect(assigned, "exactly one rider may hold the job").toHaveLength(1);
    // And it is no longer in the public pool for anyone.
    expect(views.every((v) => !v.jobs.some((j) => j.id === jobId))).toBe(true);
  });

  it("refuses a claim on a job that does not exist", async () => {
    const res = await riders[0].post("/api/rider/jobs/00000000-0000-0000-0000-000000000000/claim");
    expect(res.status).toBe(404);
  });
});
