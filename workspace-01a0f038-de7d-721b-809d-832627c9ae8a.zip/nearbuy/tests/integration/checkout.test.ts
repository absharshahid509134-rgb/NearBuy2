import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";
import {
  addProduct,
  addToCart,
  defaultAddressId,
  idemKey,
  makeCustomer,
  makeSeller,
  stockOf,
} from "./fixtures";

/**
 * Checkout is where every money, stock and authorisation rule converges, so
 * these tests drive the real HTTP API and assert against the real database.
 */
describe("checkout", () => {
  let seller: TestClient;
  let customer: TestClient;
  let milk: string;
  let bread: string;
  let salt: string;
  let addressId: string;

  beforeAll(async () => {
    seller = await makeSeller("checkout");
    milk = await addProduct(seller, "Amul Taaza Milk 1L", 6800, 20);
    bread = await addProduct(seller, "Britannia Bread 400g", 4500, 18);
    salt = await addProduct(seller, "Tata Salt 1kg", 2800, 30);

    customer = await makeCustomer("checkoutcust");
    addressId = await defaultAddressId(customer);
  });

  it("rejects checkout of an empty cart", async () => {
    const fresh = await makeCustomer("emptycart");
    const res = await fresh.post("/api/checkout", {
      fulfillmentType: "DELIVERY",
      addressId: await defaultAddressId(fresh),
      idempotencyKey: idemKey("empty"),
    });
    expect(res.status).toBe(400);
    expect(err(res.body).message).toMatch(/empty/i);
  });

  it("places a single-store order with the correct INR totals", async () => {
    await addToCart(customer, milk, 2);

    const res = await customer.post("/api/checkout", {
      fulfillmentType: "DELIVERY",
      addressId,
      idempotencyKey: idemKey("single"),
    });
    expect(res.status).toBe(201);

    const result = data<{
      orders: Array<{ subtotalPaise: number; deliveryFeePaise: number; totalPaise: number; status: string }>;
      grandTotalPaise: number;
    }>(res.body);

    expect(result.orders).toHaveLength(1);
    const order = result.orders[0];
    expect(order.subtotalPaise).toBe(2 * 6800); // 2 × ₹68
    expect(order.deliveryFeePaise).toBeGreaterThan(0);
    expect(order.totalPaise).toBe(order.subtotalPaise + order.deliveryFeePaise);
    expect(result.grandTotalPaise).toBe(order.totalPaise);
    expect(order.status).toBe("PLACED");
  });

  it("deducts stock atomically at checkout", async () => {
    // 20 seeded, 2 bought by the order above.
    expect(await stockOf(seller, milk)).toBe(18);
  });

  it("empties the cart of exactly what was purchased", async () => {
    const cart = await customer.get("/api/cart");
    const view = data<{ itemCount: number; groups: Array<{ items: Array<{ productId: string }> }> }>(cart.body);
    expect(view.itemCount).toBe(0);
  });

  it("replays a duplicate checkout instead of creating a second order", async () => {
    const c2 = await makeCustomer("idem");
    await addToCart(c2, salt, 1);
    const address = await defaultAddressId(c2);
    const key = idemKey("replay");

    const first = await c2.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: key,
    });
    expect(first.status).toBe(201);
    expect(data<{ idempotentReplay: boolean }>(first.body).idempotentReplay).toBe(false);

    // Same key, different cart contents entirely — the key must win.
    await addToCart(c2, bread, 3);
    const second = await c2.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: key,
    });
    expect(second.status).toBe(200);
    expect(data<{ idempotentReplay: boolean }>(second.body).idempotentReplay).toBe(true);
    expect(data<{ orders: unknown[] }>(second.body).orders).toHaveLength(1);

    // And a third time, to be sure it stays idempotent.
    const third = await c2.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: key,
    });
    expect(data<{ orders: unknown[] }>(third.body).orders).toHaveLength(1);

    const orders = await c2.get("/api/orders");
    const list = data<{ orders: unknown[] }>(orders.body).orders;
    expect(list).toHaveLength(1);
  });

  it("splits a multi-store cart into separate orders with separate fees", async () => {
    const otherSeller = await makeSeller("checkoutb");
    const biscuits = await addProduct(otherSeller, "Parle-G Gold 100g", 1000, 50);

    const c3 = await makeCustomer("multistore");
    const address = await defaultAddressId(c3);

    // Store A: 2 × ₹30 + 1 × ₹50 = ₹110. Store B: 1 × ₹10.
    await addToCart(c3, salt, 2);
    await addToCart(c3, bread, 1);
    await addToCart(c3, biscuits, 1);

    const cart = await c3.get("/api/cart");
    expect(data<{ storeCount: number }>(cart.body).storeCount).toBe(2);

    const res = await c3.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: idemKey("multi"),
    });
    // Surface the server's own message on failure — that copy is the thing
    // under test, not an implementation detail.
    expect(res.status, `checkout failed: ${JSON.stringify(res.body)}`).toBe(201);

    const result = data<{
      orders: Array<{
        storeName: string; subtotalPaise: number; deliveryFeePaise: number; totalPaise: number;
      }>;
      grandTotalPaise: number;
    }>(res.body);

    // Two independent operational orders — never merged into one.
    expect(result.orders).toHaveLength(2);

    const storeA = result.orders.find((o) => o.subtotalPaise === 2 * 2800 + 4500)!;
    const storeB = result.orders.find((o) => o.subtotalPaise === 1000)!;
    expect(storeA).toBeDefined();
    expect(storeB).toBeDefined();

    // Each carries its own delivery fee, charged to that store.
    expect(storeA.deliveryFeePaise).toBeGreaterThan(0);
    expect(storeB.deliveryFeePaise).toBeGreaterThan(0);
    expect(storeA.totalPaise).toBe(storeA.subtotalPaise + storeA.deliveryFeePaise);
    expect(storeB.totalPaise).toBe(storeB.subtotalPaise + storeB.deliveryFeePaise);

    const expectedGrand = storeA.totalPaise + storeB.totalPaise;
    expect(result.grandTotalPaise).toBe(expectedGrand);
  });

  it("charges nothing for a pickup order", async () => {
    const c4 = await makeCustomer("pickup");
    await addToCart(c4, bread, 1);
    const res = await c4.post("/api/checkout", {
      fulfillmentType: "PICKUP", addressId: null, idempotencyKey: idemKey("pickup"),
    });
    expect(res.status).toBe(201);
    const order = data<{ orders: Array<{ deliveryFeePaise: number; totalPaise: number; subtotalPaise: number }> }>(
      res.body,
    ).orders[0];
    expect(order.deliveryFeePaise).toBe(0);
    expect(order.totalPaise).toBe(order.subtotalPaise);
  });

  it("requires a delivery address when the order is for delivery", async () => {
    const c5 = await makeCustomer("noaddr");
    await addToCart(c5, bread, 1);
    const res = await c5.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: null, idempotencyKey: idemKey("noaddr"),
    });
    expect(res.status).toBe(400);
    expect(err(res.body).message).toMatch(/address/i);
  });

  it("refuses to use somebody else's address", async () => {
    const victim = await makeCustomer("victim");
    const victimAddress = await defaultAddressId(victim);

    const attacker = await makeCustomer("attacker");
    await addToCart(attacker, bread, 1);
    const res = await attacker.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: victimAddress, idempotencyKey: idemKey("stolen"),
    });
    expect(res.status).toBe(404);
  });

  it("rejects an out-of-stock checkout and creates no order", async () => {
    const s = await makeSeller("oos");
    const scarce = await addProduct(s, "Scarce Item", 5000, 0);

    const c = await makeCustomer("oos");
    const before = await c.get("/api/orders");
    const beforeCount = data<{ orders: unknown[] }>(before.body).orders.length;

    // The cart rejects it up front...
    const add = await c.post("/api/cart/items", { productId: scarce, quantity: 1 });
    expect(add.status).toBe(409);
    expect(err(add.body).message).toMatch(/out of stock/i);

    // ...and the checkout rejects it too, even if the cart is forced.
    const c2 = await makeCustomer("oos2");
    const fakeCart = await c2.post("/api/checkout", {
      fulfillmentType: "PICKUP", addressId: null, idempotencyKey: idemKey("oos"),
    });
    expect(fakeCart.status).toBe(400);

    const after = await c.get("/api/orders");
    expect(data<{ orders: unknown[] }>(after.body).orders).toHaveLength(beforeCount);
  });

  it("rejects a checkout for more units than remain, leaving stock untouched", async () => {
    const s = await makeSeller("partial");
    const item = await addProduct(s, "Limited Item", 2500, 3);

    const c = await makeCustomer("partialcust");
    const address = await defaultAddressId(c);
    await c.post("/api/cart/items", { productId: item, quantity: 2 });
    const res = await c.post("/api/cart/items", { productId: item, quantity: 2 });
    expect(res.status).toBe(409);
    expect(err(res.body).message).toMatch(/only 3/i);

    // The failed add must not have changed the cart or the stock.
    const cart = await c.get("/api/cart");
    const view = data<{ groups: Array<{ items: Array<{ quantity: number }> }> }>(cart.body);
    expect(view.groups[0].items[0].quantity).toBe(2);
    expect(await stockOf(s, item)).toBe(3);

    const co = await c.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: idemKey("partial"),
    });
    expect(co.status, `checkout failed: ${JSON.stringify(co.body)}`).toBe(201);
    // 3 in stock, 2 bought.
    expect(await stockOf(s, item)).toBe(1);
  });

  it("refuses to order from a store that is not published", async () => {
    const hidden = await makeSeller("hidden", false);
    const product = await addProduct(hidden, "Hidden Product", 1000, 10);

    const c = await makeCustomer("hiddencust");
    // A draft product cannot even be added to a cart.
    const add = await c.post("/api/cart/items", { productId: product, quantity: 1 });
    expect([400, 409, 404]).toContain(add.status);
  });

  it("refuses delivery for a store that only offers pickup", async () => {
    const pickupOnly = await makeSeller("pickuponly");
    const storeRes = await pickupOnly.put("/api/stores/mine", {
      name: "Pickup Only Store",
      description: "A store that only offers collection from the counter.",
      category: "Stationery",
      addressLine1: "D-4, Sector 11, Dwarka",
      city: "New Delhi", state: "Delhi", pincode: "110075",
      latitude: 28.5857, longitude: 77.0428, phone: "011-4000 9999",
      openingTime: "09:00", closingTime: "20:00",
      operatingDays: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
      supportsDelivery: false, supportsPickup: true,
      deliveryEtaMinutes: 30, isOpen: true, status: "PUBLISHED",
    });
    expect(storeRes.status).toBe(200);
    const product = await addProduct(pickupOnly, "Notebook A4", 7800, 40);

    const c = await makeCustomer("pickuponlycust");
    const address = await defaultAddressId(c);
    await addToCart(c, product, 1);

    const res = await c.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: address, idempotencyKey: idemKey("nodl"),
    });
    expect(res.status).toBe(409);
    expect(err(res.body).message).toMatch(/does not offer delivery/i);
  });
});
