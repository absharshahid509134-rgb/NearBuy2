import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";
import { addProduct, makeCustomer, makeSeller, stockOf } from "./fixtures";

/**
 * Stock checks and reservations.
 *
 * The product makes a distinction it refuses to blur: a stock check is a
 * question that never moves stock, while a reservation the seller answers with
 * `holdStock` genuinely reduces sellable stock until it is released.
 */

let seller: TestClient;
let customer: TestClient;
let productId: string;

const invOf = async (productId: string) => {
  const products = data<{
    products: Array<{ id: string; inventory: { stockQuantity: number; reservedQuantity: number } | null }>;
  }>((await seller.get("/api/seller/products")).body).products;
  return products.find((p) => p.id === productId)!.inventory!;
};

beforeAll(async () => {
  seller = await makeSeller("reqs");
  productId = await addProduct(seller, "Amul Taaza Milk 1L", 6800, 20);
  customer = await makeCustomer("reqscust");
});

describe("stock checks", () => {
  it("never moves stock, whichever way the seller answers", async () => {
    const before = await invOf(productId);
    const res = await customer.post("/api/stock-requests", { productId, quantity: 2 });
    expect(res.status, JSON.stringify(res.body)).toBe(201);
    const request = data<{ stockRequest: { id: string; status: string } }>(res.body).stockRequest;
    expect(request.status).toBe("PENDING");
    expect(await invOf(productId)).toEqual(before);

    const answered = await seller.post(`/api/stock-requests/${request.id}/respond`, {
      status: "CONFIRMED", response: "Yes, we have it on the shelf.",
    });
    expect(answered.status, JSON.stringify(answered.body)).toBe(200);
    expect(data<{ stockRequest: { status: string } }>(answered.body).stockRequest.status).toBe("CONFIRMED");
    expect(await invOf(productId)).toEqual(before);
  });

  it("shows the answer to the customer and the seller alike", async () => {
    const mine = data<{ stockRequests: Array<{ id: string; status: string; sellerResponse: string | null }> }>(
      (await customer.get("/api/stock-requests")).body,
    ).stockRequests;
    expect(mine[0].status).toBe("CONFIRMED");
    expect(mine[0].sellerResponse).toMatch(/shelf/i);

    const inbox = data<{ stockRequests: Array<{ id: string; status: string }> }>(
      (await seller.get("/api/seller/stock-requests")).body,
    ).stockRequests;
    expect(inbox.some((r) => r.id === mine[0].id && r.status === "CONFIRMED")).toBe(true);
  });

  it("refuses a second open check for the same item", async () => {
    const first = await customer.post("/api/stock-requests", { productId, quantity: 1 });
    expect(first.status).toBe(201);
    const second = await customer.post("/api/stock-requests", { productId, quantity: 1 });
    expect(second.status).toBe(409);

    const id = data<{ stockRequest: { id: string } }>(first.body).stockRequest.id;
    await seller.post(`/api/stock-requests/${id}/respond`, { status: "UNAVAILABLE" });
  });

  it("refuses a CONFIRMED answer the shelf cannot back", async () => {
    const res = await customer.post("/api/stock-requests", { productId, quantity: 999 });
    expect(res.status).toBe(201);
    const id = data<{ stockRequest: { id: string } }>(res.body).stockRequest.id;

    const answer = await seller.post(`/api/stock-requests/${id}/respond`, { status: "CONFIRMED" });
    expect(answer.status).toBe(409);
    expect(err(answer.body).message).toMatch(/sellable stock/i);
  });

  it("stops one seller answering another seller's check", async () => {
    const res = await customer.post("/api/stock-requests", { productId, quantity: 1 });
    const id = data<{ stockRequest: { id: string } }>(res.body).stockRequest.id;
    const intruder = await makeSeller("reqs-intruder");
    const answer = await intruder.post(`/api/stock-requests/${id}/respond`, { status: "CONFIRMED" });
    expect([403, 404], `intruder answer -> ${answer.status}`).toContain(answer.status);
  });
});

describe("reservations", () => {
  it("confirms without holding when the seller says holdStock: false", async () => {
    const before = await invOf(productId);
    const res = await customer.post("/api/reservations", { productId, quantity: 2 });
    expect(res.status, JSON.stringify(res.body)).toBe(201);
    const id = data<{ reservation: { id: string } }>(res.body).reservation.id;

    const answered = await seller.post(`/api/reservations/${id}/respond`, {
      status: "CONFIRMED", holdStock: false, response: "We will keep one aside informally.",
    });
    expect(answered.status, JSON.stringify(answered.body)).toBe(200);
    const view = data<{ reservation: { status: string; stockHeld: boolean; expiresAt: string | null } }>(
      answered.body,
    ).reservation;
    expect(view.status).toBe("CONFIRMED");
    expect(view.stockHeld, "an informal confirmation must not claim to hold stock").toBe(false);
    expect(view.expiresAt, "an informal confirmation must not pretend to expire").toBeNull();
    expect(await invOf(productId)).toEqual(before);
  });

  it("really holds stock when the seller sets holdStock: true", async () => {
    const before = await invOf(productId);
    const res = await customer.post("/api/reservations", { productId, quantity: 3 });
    const id = data<{ reservation: { id: string } }>(res.body).reservation.id;

    const answered = await seller.post(`/api/reservations/${id}/respond`, {
      status: "CONFIRMED", holdStock: true, response: "Held at the counter for 24 hours.",
    });
    expect(answered.status, JSON.stringify(answered.body)).toBe(200);
    const view = data<{ reservation: { status: string; stockHeld: boolean; expiresAt: string | null } }>(
      answered.body,
    ).reservation;
    expect(view.stockHeld).toBe(true);
    expect(view.expiresAt).toBeTruthy();

    const after = await invOf(productId);
    expect(after.stockQuantity, "holding must not decrement physical stock").toBe(before.stockQuantity);
    expect(after.reservedQuantity, "holding must reduce sellable stock").toBe(
      before.reservedQuantity + 3,
    );
  });

  it("gives the held units back when the customer cancels", async () => {
    const list = data<{ reservations: Array<{ id: string; status: string; stockHeld: boolean }> }>(
      (await customer.get("/api/reservations")).body,
    ).reservations;
    const held = list.find((r) => r.stockHeld);
    expect(held, "there must be a held reservation to cancel").toBeTruthy();

    const before = await invOf(productId);
    const cancelled = await customer.post(`/api/reservations/${held!.id}/respond`, {});
    // There is no customer "respond" verb; cancellation is its own endpoint.
    expect([404, 405, 400]).toContain(cancelled.status);

    const res = await customer.del(`/api/reservations/${held!.id}`);
    expect([200, 204], `cancel -> ${res.status}`).toContain(res.status);
    const after = await invOf(productId);
    expect(after.reservedQuantity).toBe(before.reservedQuantity - 3);
  });

  it("refuses to hold more than the sellable stock", async () => {
    const res = await customer.post("/api/reservations", { productId, quantity: 500 });
    const id = data<{ reservation: { id: string } }>(res.body).reservation.id;
    const answer = await seller.post(`/api/reservations/${id}/respond`, {
      status: "CONFIRMED", holdStock: true,
    });
    expect(answer.status).toBe(409);
    expect(err(answer.body).message).toMatch(/available to hold/i);
  });

  it("does not let a second seller answer or cancel a reservation", async () => {
    const res = await customer.post("/api/reservations", { productId, quantity: 1 });
    const id = data<{ reservation: { id: string } }>(res.body).reservation.id;
    const intruder = await makeSeller("res-intruder");

    const answer = await intruder.post(`/api/reservations/${id}/respond`, { status: "REJECTED" });
    expect([403, 404], `intruder respond -> ${answer.status}`).toContain(answer.status);
  });

  it("stops a customer cancelling somebody else's reservation", async () => {
    const res = await customer.post("/api/reservations", { productId, quantity: 1 });
    const id = data<{ reservation: { id: string } }>(res.body).reservation.id;
    const stranger = await makeCustomer("res-stranger");
    const cancelled = await stranger.del(`/api/reservations/${id}`);
    expect([403, 404], `stranger cancel -> ${cancelled.status}`).toContain(cancelled.status);
  });

  it("leaves the shelf count alone throughout", async () => {
    // Reservations move `reservedQuantity`, never `stockQuantity`.
    expect((await stockOf(seller, productId))).toBe(20);
  });
});
