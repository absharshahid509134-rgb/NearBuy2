import { beforeAll, describe, expect, it } from "vitest";
import { TestClient, data, err } from "../helpers/client";

const PASSWORD = "Str0ng!Passw0rd";

describe("authentication", () => {
  const c = new TestClient("auth");

  it("reports health without leaking secrets", async () => {
    const res = await c.get<Record<string, unknown>>("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
    const serialised = JSON.stringify(res.body);
    expect(serialised).not.toContain("postgres://");
    expect(serialised).not.toContain("file:");
    expect(serialised).not.toMatch(/password|secret/i);
  });

  it("registers a customer and returns a session cookie", async () => {
    const res = await c.post("/api/auth/signup", {
      role: "CUSTOMER",
      name: "Aarav Test",
      email: "auth.customer@test.local",
      password: PASSWORD,
      phone: "9810012345",
    });
    expect(res.status).toBe(201);
    expect(data<{ user: { role: string } }>(res.body).user.role).toBe("CUSTOMER");
    expect(c.cookieValue("nb_session")).toBeTruthy();
  });

  it("gives a new customer a saved address and an empty cart", async () => {
    const me = await c.get<{ user: unknown }>("/api/auth/me");
    expect(me.status).toBe(200);

    const cart = await c.get<{ groups: unknown[]; itemCount: number }>("/api/cart");
    expect(cart.status).toBe(200);
    expect(data<{ itemCount: number }>(cart.body).itemCount).toBe(0);

    const addresses = await c.get<{ addresses: unknown[] }>("/api/addresses");
    expect(data<{ addresses: unknown[] }>(addresses.body).addresses.length).toBeGreaterThan(0);
  });

  it("registers sellers and riders too", async () => {
    const seller = new TestClient("auth-seller");
    const s = await seller.signup("SELLER", "auth.seller@test.local");
    expect(s.status).toBe(201);

    const rider = new TestClient("auth-rider");
    const r = await rider.signup("RIDER", "auth.rider@test.local");
    expect(r.status).toBe(201);
  });

  it("rejects a duplicate email", async () => {
    const res = await c.post("/api/auth/signup", {
      role: "CUSTOMER",
      name: "Impostor",
      email: "auth.customer@test.local",
      password: PASSWORD,
    });
    expect(res.status).toBe(409);
  });

  it("rejects a weak password with a field-level message", async () => {
    const res = await c.post("/api/auth/signup", {
      role: "CUSTOMER",
      name: "Weak Password",
      email: "auth.weak@test.local",
      password: "password123",
    });
    expect(res.status).toBe(400);
    expect(err(res.body).details?.password).toBeTruthy();
  });

  it("rejects a malformed email", async () => {
    const res = await c.post("/api/auth/signup", {
      role: "CUSTOMER",
      name: "Bad Email",
      email: "not-an-email",
      password: PASSWORD,
    });
    expect(res.status).toBe(400);
  });

  it("signs in with correct credentials", async () => {
    const fresh = new TestClient("auth-login");
    const res = await fresh.login("CUSTOMER", "auth.customer@test.local", PASSWORD);
    expect(res.status).toBe(200);
    expect(fresh.cookieValue("nb_session")).toBeTruthy();
  });

  it("rejects a wrong password without revealing whether the account exists", async () => {
    const a = new TestClient("bad-pw-known");
    const known = await a.post("/api/auth/login", {
      role: "CUSTOMER", email: "auth.customer@test.local", password: "Wrong!Passw0rd",
    });
    expect(known.status).toBe(401);

    const b = new TestClient("bad-pw-unknown");
    const unknown = await b.post("/api/auth/login", {
      role: "CUSTOMER", email: "nobody@test.local", password: "Wrong!Passw0rd",
    });
    expect(unknown.status).toBe(401);

    // Identical wording, so the response cannot be used to enumerate accounts.
    expect(err(known.body).message).toBe(err(unknown.body).message);
  });

  it("refuses to sign a customer in through the seller page", async () => {
    const res = await c.post("/api/auth/login", {
      role: "SELLER", email: "auth.customer@test.local", password: PASSWORD,
    });
    expect(res.status).toBe(401);
    // The message names the account's REAL role, so a user who picked the
    // wrong tab is told where to go instead of just "no".
    expect(err(res.body).message).toMatch(/registered as customer/i);
  });

  it("protects the session: a tampered cookie is rejected", async () => {
    const tampered = new TestClient("tampered");
    const forged = `nb_session=${"a".repeat(43)}`;
    const res = await tampered.request("/api/auth/me", { headers: { cookie: forged } });
    expect(res.status).toBe(200);
    expect(data<{ user: unknown }>(res.body).user).toBeNull();
  });

  it("requires a session for protected endpoints", async () => {
    const anon = new TestClient("anon");
    for (const path of ["/api/cart", "/api/orders", "/api/addresses", "/api/reservations"]) {
      const res = await anon.get(path);
      expect(res.status, `${path} should require auth`).toBe(401);
    }
    // /api/checkout is POST-only, so an anonymous POST is what must 401.
    const checkout = await anon.post("/api/checkout", {
      fulfillmentType: "DELIVERY", addressId: "x", idempotencyKey: "anon-checkout-key-1",
    });
    expect(checkout.status).toBe(401);
  });

  it("signs out and invalidates the session server-side", async () => {
    const client = new TestClient("logout");
    await client.login("CUSTOMER", "auth.customer@test.local", PASSWORD);
    const before = await client.get("/api/auth/me");
    expect(data<{ user: unknown }>(before.body).user).not.toBeNull();

    const out = await client.post("/api/auth/logout");
    expect(out.status).toBe(200);

    // The cookie is cleared AND the row is gone: a replayed token is useless.
    const after = await client.get("/api/auth/me");
    expect(data<{ user: unknown }>(after.body).user).toBeNull();
  });

  it("rate-limits repeated failed sign-ins", async () => {
    const attacker = new TestClient("ratelimit");
    let sawLimit = false;
    for (let i = 0; i < 20; i++) {
      const res = await attacker.post("/api/auth/login", {
        role: "CUSTOMER", email: "ratelimit@test.local", password: "Nope!Passw0rd",
      });
      if (res.status === 429) {
        expect(err(res.body).message).toMatch(/too many/i);
        sawLimit = true;
        break;
      }
    }
    expect(sawLimit).toBe(true);
  });

  it("never returns a password hash in any auth response", async () => {
    const me = await c.get("/api/auth/me");
    expect(JSON.stringify(me.body)).not.toContain("$2a$");
    expect(JSON.stringify(me.body)).not.toContain("$2b$");
  });
});
