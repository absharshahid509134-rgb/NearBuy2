/**
 * A tiny browser-like HTTP client for the integration suite.
 *
 * It keeps a cookie jar, so sessions behave exactly as they do in a real
 * browser — which is the whole point of testing the auth boundary over HTTP
 * rather than by calling service functions directly.
 */
export const BASE = (globalThis as Record<string, unknown>)
  .__NEARBUY_TEST_BASE__ as string | undefined ?? "http://127.0.0.1:3123";

export class TestClient {
  private cookies = new Map<string, string>();

  constructor(readonly label: string) {}

  cookieHeader(): string {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }

  async request<T = unknown>(
    path: string,
    init: RequestInit & { json?: unknown } = {},
  ): Promise<{ status: number; body: T }> {
    const { json, headers, ...rest } = init;
    const res = await fetch(`${BASE}${path}`, {
      ...rest,
      redirect: "manual",
      headers: {
        ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(this.cookies.size ? { cookie: this.cookieHeader() } : {}),
        ...(headers ?? {}),
      },
      body: json !== undefined ? JSON.stringify(json) : rest.body,
    });

    for (const raw of res.headers.getSetCookie?.() ?? []) {
      const [pair] = raw.split(";");
      const idx = pair.indexOf("=");
      if (idx > 0) {
        const name = pair.slice(0, idx).trim();
        const value = pair.slice(idx + 1).trim();
        if (value === "") this.cookies.delete(name);
        else this.cookies.set(name, value);
      }
    }

    const text = await res.text();
    let body: unknown = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = text;
    }
    return { status: res.status, body: body as T };
  }

  get<T = unknown>(path: string) {
    return this.request<T>(path);
  }
  post<T = unknown>(path: string, json?: unknown) {
    return this.request<T>(path, { method: "POST", json });
  }
  put<T = unknown>(path: string, json?: unknown) {
    return this.request<T>(path, { method: "PUT", json });
  }
  patch<T = unknown>(path: string, json?: unknown) {
    return this.request<T>(path, { method: "PATCH", json });
  }
  del<T = unknown>(path: string) {
    return this.request<T>(path, { method: "DELETE" });
  }

  /** Signs in through the real endpoint and keeps the session cookie. */
  async login(role: "CUSTOMER" | "SELLER" | "RIDER", email: string, password: string) {
    const res = await this.post("/api/auth/login", { role, email, password });
    if (res.status !== 200) {
      throw new Error(`${this.label}: login failed (${res.status}) ${JSON.stringify(res.body)}`);
    }
    return res;
  }

  async signup(role: "CUSTOMER" | "SELLER" | "RIDER", email: string, password = "Str0ng!Passw0rd") {
    return this.post("/api/auth/signup", {
      role,
      email,
      password,
      name: `Test ${role.toLowerCase()}`,
      phone: "9810012345",
      shopName: role === "SELLER" ? "Test Shop" : undefined,
    });
  }

  cookieValue(name: string): string | undefined {
    return this.cookies.get(name);
  }
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, string>;
}

export const data = <T>(body: unknown): T => (body as { data: T }).data;
export const err = (body: unknown): ApiError => (body as { error: ApiError }).error;
