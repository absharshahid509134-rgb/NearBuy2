import { describe, expect, it } from "vitest";
import {
  decryptSecret,
  encryptSecret,
  generateHandoffCode,
  hashPassword,
  safeEqual,
  verifyPassword,
} from "@/lib/crypto";

describe("password hashing", () => {
  it("never stores the plaintext", async () => {
    const hash = await hashPassword("Str0ng!Passw0rd");
    expect(hash).not.toContain("Str0ng!Passw0rd");
    expect(hash.startsWith("$2")).toBe(true);
  });

  it("verifies the right password and rejects the wrong one", async () => {
    const hash = await hashPassword("Str0ng!Passw0rd");
    expect(await verifyPassword("Str0ng!Passw0rd", hash)).toBe(true);
    expect(await verifyPassword("wrong", hash)).toBe(false);
  });

  it("salts, so the same password hashes differently each time", async () => {
    expect(await hashPassword("same")).not.toBe(await hashPassword("same"));
  });

  it("returns false instead of throwing on a malformed hash", async () => {
    expect(await verifyPassword("x", "not-a-bcrypt-hash")).toBe(false);
  });
});

describe("handoff codes", () => {
  it("always produces six digits", () => {
    for (let i = 0; i < 300; i++) {
      expect(generateHandoffCode()).toMatch(/^\d{6}$/);
    }
  });

  it("round-trips through encryption", () => {
    const code = generateHandoffCode();
    const enc = encryptSecret(code);
    expect(enc).not.toContain(code);
    expect(decryptSecret(enc)).toBe(code);
  });

  it("produces different ciphertext for the same code each time", () => {
    const code = "123456";
    expect(encryptSecret(code)).not.toBe(encryptSecret(code));
    expect(decryptSecret(encryptSecret(code))).toBe(code);
  });

  it("fails loudly on tampered ciphertext", () => {
    const enc = encryptSecret("123456");
    const parts = enc.split(".");
    const tampered = `${parts[0]}.${parts[1]}.${parts[2].slice(0, -2)}AA`;
    expect(() => decryptSecret(tampered)).toThrow();
  });
});

describe("safeEqual", () => {
  it("compares equal and unequal values correctly", () => {
    expect(safeEqual("123456", "123456")).toBe(true);
    expect(safeEqual("123456", "654321")).toBe(false);
  });

  it("handles different lengths without throwing", () => {
    expect(safeEqual("1", "123456")).toBe(false);
  });
});
