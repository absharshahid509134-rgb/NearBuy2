import { describe, expect, it } from "vitest";
import {
  ORDER_STATE_MACHINE,
  ORDER_STATUSES,
  canTransition,
  nextTransitions,
  type OrderStatus,
} from "@/lib/enums";

const isReachableFromPlaced = (target: string) => ORDER_STATE_MACHINE.PLACED.some((t) => t.to === target);

describe("order state machine", () => {
  it("covers every declared status as a key", () => {
    for (const s of ORDER_STATUSES) {
      expect(ORDER_STATE_MACHINE[s]).toBeDefined();
    }
  });

  it("forbids PLACED -> DELIVERED entirely", () => {
    expect(canTransition("PLACED", "DELIVERED", "SELLER")).toBe(false);
    expect(canTransition("PLACED", "DELIVERED", "RIDER")).toBe(false);
    expect(canTransition("PLACED", "DELIVERED", "CUSTOMER")).toBe(false);
    expect(isReachableFromPlaced("DELIVERED")).toBe(false);
  });

  it("stops a seller from marking a delivery complete", () => {
    // A seller may only complete a PICKUP order; that extra rule lives in the
    // service layer, so here we assert the rider owns normal delivery.
    expect(canTransition("OUT_FOR_DELIVERY", "DELIVERED", "RIDER")).toBe(true);
    expect(canTransition("OUT_FOR_DELIVERY", "DELIVERED", "SELLER")).toBe(false);
    expect(canTransition("OUT_FOR_DELIVERY", "DELIVERED", "CUSTOMER")).toBe(false);
  });

  it("stops a rider from preparing or packing", () => {
    expect(canTransition("ACCEPTED", "PREPARING", "RIDER")).toBe(false);
    expect(canTransition("PREPARING", "PACKED", "RIDER")).toBe(false);
    expect(canTransition("PACKED", "READY_FOR_PICKUP", "RIDER")).toBe(false);
    expect(canTransition("ACCEPTED", "PREPARING", "SELLER")).toBe(true);
  });

  it("stops a customer from accepting or packing", () => {
    expect(canTransition("PLACED", "ACCEPTED", "CUSTOMER")).toBe(false);
    expect(canTransition("PREPARING", "PACKED", "CUSTOMER")).toBe(false);
  });

  it("requires packed before ready for pickup", () => {
    expect(canTransition("PREPARING", "READY_FOR_PICKUP", "SELLER")).toBe(false);
    expect(canTransition("PACKED", "READY_FOR_PICKUP", "SELLER")).toBe(true);
  });

  it("requires pickup verification before going out for delivery", () => {
    expect(canTransition("READY_FOR_PICKUP", "OUT_FOR_DELIVERY", "RIDER")).toBe(false);
    expect(canTransition("PICKED_UP", "OUT_FOR_DELIVERY", "RIDER")).toBe(true);
  });

  it("treats terminal statuses as final", () => {
    for (const terminal of ["DELIVERED", "REJECTED", "CANCELLED"] as OrderStatus[]) {
      expect(ORDER_STATE_MACHINE[terminal]).toHaveLength(0);
      for (const to of ORDER_STATUSES) {
        expect(canTransition(terminal, to, "SELLER")).toBe(false);
        expect(canTransition(terminal, to, "RIDER")).toBe(false);
        expect(canTransition(terminal, to, "CUSTOMER")).toBe(false);
      }
    }
  });

  it("lets a customer cancel before pickup but not after", () => {
    expect(canTransition("PLACED", "CANCELLED", "CUSTOMER")).toBe(true);
    expect(canTransition("PACKED", "CANCELLED", "CUSTOMER")).toBe(true);
    expect(canTransition("PICKED_UP", "CANCELLED", "CUSTOMER")).toBe(false);
    expect(canTransition("OUT_FOR_DELIVERY", "CANCELLED", "CUSTOMER")).toBe(false);
  });

  it("offers each actor only the moves it owns", () => {
    const sellerMoves = nextTransitions("PACKED", "SELLER").map((t) => t.to);
    expect(sellerMoves).toContain("READY_FOR_PICKUP");

    const riderMoves = nextTransitions("PACKED", "RIDER");
    expect(riderMoves).toHaveLength(0);
  });
});
