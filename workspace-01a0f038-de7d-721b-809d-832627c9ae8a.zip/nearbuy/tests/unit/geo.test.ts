import { describe, expect, it } from "vitest";
import { deliveryFeePaise, haversineKm } from "@/lib/geo";

const PRICING = { basePaise: 2500, perKmPaise: 400, minPaise: 2000, maxPaise: 6000 };

describe("haversine", () => {
  it("returns zero for the same point", () => {
    expect(haversineKm({ lat: 28.5921, lng: 77.046 }, { lat: 28.5921, lng: 77.046 })).toBe(0);
  });

  it("computes a realistic distance between two Dwarka points", () => {
    // Dwarka Sector 12 -> Sector 22 is roughly 4 km.
    const km = haversineKm({ lat: 28.5921, lng: 77.046 }, { lat: 28.5569, lng: 77.0689 });
    expect(km).toBeGreaterThan(3);
    expect(km).toBeLessThan(6);
  });

  it("is symmetric", () => {
    const a = { lat: 28.5921, lng: 77.046 };
    const b = { lat: 19.076, lng: 72.8777 };
    expect(haversineKm(a, b)).toBeCloseTo(haversineKm(b, a), 9);
  });
});

describe("delivery fee", () => {
  it("adds a small per-km charge for a very short hop", () => {
    // 2500 base + round(0.2 km * 400) = 2580
    expect(deliveryFeePaise(0.2, PRICING)).toBe(2580);
  });

  it("adds per-kilometre cost for longer hops", () => {
    expect(deliveryFeePaise(4, PRICING)).toBe(2500 + 1600);
  });

  it("never falls below the minimum", () => {
    expect(deliveryFeePaise(0, { ...PRICING, basePaise: 100 })).toBe(2000);
  });

  it("never exceeds the cap, even across the country", () => {
    expect(deliveryFeePaise(2000, PRICING)).toBe(6000);
  });

  it("always returns whole paise", () => {
    for (const km of [0, 1.234, 7.77, 12.5, 99]) {
      expect(Number.isInteger(deliveryFeePaise(km, PRICING))).toBe(true);
    }
  });
});
