import { describe, expect, it } from "vitest";
import { formatINR, rupeesToPaise, assertValidPaise } from "@/lib/money";

describe("money", () => {
  it("renders whole rupees without decimals, like a real receipt", () => {
    expect(formatINR(6800)).toBe("₹68");
    expect(formatINR(28500)).toBe("₹285");
    expect(formatINR(35800)).toBe("₹358");
  });

  it("keeps paise when they are non-zero", () => {
    expect(formatINR(4999)).toContain("49.99");
  });

  it("never loses precision converting rupees to paise", () => {
    // 0.1 + 0.2 !== 0.3 in floats; rounding to integer paise is the whole point.
    expect(rupeesToPaise(49.99)).toBe(4999);
    expect(rupeesToPaise(0.1) + rupeesToPaise(0.2)).toBe(rupeesToPaise(0.3));
    expect(rupeesToPaise("145")).toBe(14500);
  });

  it("rejects values that would corrupt a money column", () => {
    expect(() => assertValidPaise(1.5)).toThrow();
    expect(() => assertValidPaise(-1)).toThrow();
    expect(() => assertValidPaise(NaN)).toThrow();
    expect(() => assertValidPaise(3_000_000_000)).toThrow();
    expect(assertValidPaise(0)).toBe(0);
  });
});
