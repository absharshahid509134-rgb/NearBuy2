import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: {
    environment: "node",
    include: ["tests/unit/**/*.test.ts", "tests/integration/**/*.test.ts"],
    // Unit tests are pure and need no server; `npm run test:unit` skips the
    // globalSetup entirely so they run in about a second.
    globalSetup: process.env.NEARBUY_UNIT_ONLY ? undefined : ["./tests/setup/global.ts"],
    setupFiles: ["./tests/setup/vitest-env.ts"],
    // Integration tests share one server and one database; running files in
    // parallel would let them race each other's fixtures.
    fileParallelism: false,
    testTimeout: 45_000,
    hookTimeout: 120_000,
  },
});
