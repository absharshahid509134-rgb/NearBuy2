// Reproduce the multi-store 409 directly so we can read the server's message.
const BASE = "http://127.0.0.1:3123";
async function call(path, opts = {}) {
  const res = await fetch(BASE + path, opts);
  const t = await res.text();
  let b; try { b = JSON.parse(t); } catch { b = t; }
  return { status: res.status, body: b, setCookie: res.headers.getSetCookie?.() ?? [] };
}
function jar(list, prev = new Map()) {
  const m = new Map(prev);
  for (const raw of list) { const [p] = raw.split(";"); const i = p.indexOf("=");
    if (i > 0) m.set(p.slice(0,i).trim(), p.slice(i+1).trim()); }
  return m;
}
const hdr = (m) => Array.from(m.entries()).map(([k,v])=>`${k}=${v}`).join("; ");
const j = (body, m) => ({ method: "POST", headers: { "Content-Type":"application/json", ...(m?.size?{cookie:hdr(m)}:{}) }, body: JSON.stringify(body) });
const g = (m) => ({ headers: { cookie: hdr(m) } });

const sellerA = jar((await call("/api/auth/signup", j({ role:"SELLER", name:"PA", email:`pa.${Date.now()}@t.local`, password:"Str0ng!Passw0rd", shopName:"PA" }))).setCookie);
await call("/api/stores/mine", j({ name:"Store A", description:"A test store with enough description.", category:"Grocery", addressLine1:"Plot 1 Sector 12 Dwarka", city:"New Delhi", state:"Delhi", pincode:"110075", latitude:28.5921, longitude:77.046, phone:"011-4000 1234", openingTime:"07:00", closingTime:"22:00", operatingDays:["MON","TUE","WED","THU","FRI","SAT","SUN"], supportsDelivery:true, supportsPickup:true, deliveryEtaMinutes:30, isOpen:true, status:"PUBLISHED" }, sellerA));
const pA = jar((await call("/api/seller/products", j({ name:"Item A", description:"A dependable everyday product.", category:"Grocery", unit:"1 pc", pricePaise:2800, stockQuantity:30, lowStockThreshold:2, isAvailable:true, status:"PUBLISHED" }, sellerA))).setCookie, sellerA);

const sellerB = jar((await call("/api/auth/signup", j({ role:"SELLER", name:"PB", email:`pb.${Date.now()}@t.local`, password:"Str0ng!Passw0rd", shopName:"PB" }))).setCookie);
await call("/api/stores/mine", j({ name:"Store B", description:"A second test store for multi store.", category:"Stationery", addressLine1:"D4 Sector 11 Dwarka", city:"New Delhi", state:"Delhi", pincode:"110075", latitude:28.5857, longitude:77.0428, phone:"011-4000 9999", openingTime:"09:00", closingTime:"20:00", operatingDays:["MON","TUE","WED","THU","FRI","SAT","SUN"], supportsDelivery:true, supportsPickup:true, deliveryEtaMinutes:30, isOpen:true, status:"PUBLISHED" }, sellerB));
const pB = jar((await call("/api/seller/products", j({ name:"Item B", description:"A second dependable product.", category:"Stationery", unit:"1 pc", pricePaise:1000, stockQuantity:50, lowStockThreshold:2, isAvailable:true, status:"PUBLISHED" }, sellerB))).setCookie, sellerB);

const cust = jar((await call("/api/auth/signup", j({ role:"CUSTOMER", name:"PC", email:`pc.${Date.now()}@t.local`, password:"Str0ng!Passw0rd", phone:"9810012345" }))).setCookie);
const addr = (await call("/api/addresses", g(cust))).body.data.addresses[0].id;
await call("/api/cart/items", j({ productId: pA.get("nb_session") ? undefined : undefined }, cust));
const a = await call("/api/seller/products", g(pA));
const prodA = a.body.data.products[0].id;
const b = await call("/api/seller/products", g(pB));
const prodB = b.body.data.products[0].id;
console.log("add A:", (await call("/api/cart/items", j({ productId: prodA, quantity: 2 }, cust))).status);
console.log("add B:", (await call("/api/cart/items", j({ productId: prodB, quantity: 1 }, cust))).status);
const cart = await call("/api/cart", g(cust));
console.log("cart:", cart.status, JSON.stringify(cart.body).slice(0,400));
const co = await call("/api/checkout", j({ fulfillmentType:"DELIVERY", addressId: addr, idempotencyKey:`k-${Date.now()}` }, cust));
console.log("CHECKOUT:", co.status, JSON.stringify(co.body));
