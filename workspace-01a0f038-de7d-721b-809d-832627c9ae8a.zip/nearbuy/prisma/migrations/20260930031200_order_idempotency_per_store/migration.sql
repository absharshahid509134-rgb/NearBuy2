-- Scope the checkout idempotency guard per store.
--
-- One checkout attempt can legitimately produce several Order rows (one per
-- store). Constraining (customerId, idempotencyKey) alone meant the second
-- store in a multi-store cart collided with the first and the whole
-- transaction rolled back. Scoping to the store keeps the double-submit
-- guarantee intact while allowing one order per store per attempt.
DROP INDEX IF EXISTS "Order_customerId_idempotencyKey_key";

CREATE UNIQUE INDEX "Order_customerId_idempotencyKey_storeId_key"
    ON "Order"("customerId", "idempotencyKey", "storeId");
