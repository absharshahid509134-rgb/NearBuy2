"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiErrorShape } from "@/lib/client";
import { Alert, Thumb } from "./ui";
import { formatINR, rupeesToPaise } from "@/lib/money";

export interface SellerProduct {
  id: string;
  name: string;
  description: string;
  category: string;
  unit: string;
  pricePaise: number;
  compareAtPricePaise: number | null;
  imageUrl: string | null;
  status: string;
  isAvailable: boolean;
  inventory: { stockQuantity: number; reservedQuantity: number; lowStockThreshold: number } | null;
}

const CATEGORIES = [
  "Grocery", "Fruits & Vegetables", "Dairy", "Bakery", "Pharmacy",
  "Snacks", "Beverages", "Personal Care", "Household", "Stationery",
];

const BLANK = {
  name: "", description: "", category: "Grocery", unit: "1 pc",
  price: "", stock: "0", lowStockThreshold: "5", status: "DRAFT" as string,
};

/**
 * Seller catalogue management.
 *
 * Prices are entered in rupees for the seller's benefit and converted to paise
 * before they ever leave the browser — but the server re-validates everything,
 * so a tampered payload is rejected rather than trusted.
 */
export function ProductManager({ products, categories }: { products: SellerProduct[]; categories: string[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<SellerProduct | null>(null);
  const [form, setForm] = useState(BLANK);
  const [image, setImage] = useState<File | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<ApiErrorShape | null>(null);

  const fieldErrors = error?.details ?? {};

  function startCreate() {
    setForm(BLANK);
    setEditing(null);
    setImage(null);
    setError(null);
    setOpen(true);
  }

  function startEdit(p: SellerProduct) {
    setForm({
      name: p.name,
      description: p.description,
      category: p.category,
      unit: p.unit,
      price: String(p.pricePaise / 100),
      stock: String(p.inventory?.stockQuantity ?? 0),
      lowStockThreshold: String(p.inventory?.lowStockThreshold ?? 5),
      status: p.status,
    });
    setEditing(p);
    setImage(null);
    setError(null);
    setOpen(true);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);

    const body = new FormData();
    body.set("name", form.name);
    body.set("description", form.description);
    body.set("category", form.category);
    body.set("unit", form.unit);
    body.set("pricePaise", String(rupeesToPaise(form.price)));
    body.set("lowStockThreshold", form.lowStockThreshold);
    body.set("isAvailable", "true");
    body.set("status", form.status);
    if (image) body.set("image", image);
    if (editing) body.set("stockQuantity", form.stock);

    const res = editing
      ? await fetch(`/api/seller/products/${editing.id}`, { method: "PATCH", body }).then(toResult)
      : await (async () => {
          body.set("stockQuantity", form.stock);
          return toResult(await fetch("/api/seller/products", { method: "POST", body }));
        })();

    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setOpen(false);
    router.refresh();
  }

  async function quickUpdate(p: SellerProduct, patch: Record<string, unknown>) {
    setPending(true);
    setError(null);
    const res = await api.patch(`/api/seller/products/${p.id}`, patch);
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    router.refresh();
  }

  async function archive(p: SellerProduct) {
    if (!confirm(`Archive "${p.name}"? It will be hidden from customers but kept for order history.`)) return;
    setPending(true);
    setError(null);
    const res = await api.del(`/api/seller/products/${p.id}`);
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    router.refresh();
  }

  return (
    <div>
      {error && !error.details ? <div className="mb-4"><Alert tone="error" role="alert">{error.message}</Alert></div> : null}

      <div className="mb-4 flex justify-end">
        <button type="button" onClick={startCreate} className="btn-primary">Add a product</button>
      </div>

      {open ? (
        <form onSubmit={save} className="card mb-5 p-5" noValidate>
          <h2 className="font-bold">{editing ? `Edit ${editing.name}` : "New product"}</h2>
          {error?.details ? <div className="mt-3"><Alert tone="error" role="alert">{error.message}</Alert></div> : null}

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="p-name" className="label">Product name</label>
              <input id="p-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" required />
              {fieldErrors.name ? <p className="error-text">{fieldErrors.name}</p> : null}
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="p-desc" className="label">Description</label>
              <textarea id="p-desc" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input" required />
              {fieldErrors.description ? <p className="error-text">{fieldErrors.description}</p> : null}
            </div>

            <div>
              <label htmlFor="p-cat" className="label">Category</label>
              <select id="p-cat" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="input">
                {(categories.length ? categories : CATEGORIES).map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label htmlFor="p-unit" className="label">Unit</label>
              <input id="p-unit" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} className="input" placeholder="1 L, 500 g, 1 dozen" />
            </div>

            <div>
              <label htmlFor="p-price" className="label">Selling price (₹)</label>
              <input id="p-price" type="number" min={1} step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="input" required />
              {fieldErrors.pricePaise ? <p className="error-text">{fieldErrors.pricePaise}</p> : null}
            </div>

            <div>
              <label htmlFor="p-stock" className="label">Stock quantity</label>
              <input id="p-stock" type="number" min={0} value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className="input" required />
              {fieldErrors.stockQuantity ? <p className="error-text">{fieldErrors.stockQuantity}</p> : null}
            </div>

            <div>
              <label htmlFor="p-low" className="label">Low-stock alert below</label>
              <input id="p-low" type="number" min={0} value={form.lowStockThreshold} onChange={(e) => setForm({ ...form, lowStockThreshold: e.target.value })} className="input" />
            </div>

            <div>
              <label htmlFor="p-status" className="label">Visibility</label>
              <select id="p-status" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} className="input">
                <option value="DRAFT">Draft — hidden from customers</option>
                <option value="PUBLISHED">Published — visible to customers</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>

            <div>
              <label htmlFor="p-image" className="label">Product photo</label>
              <input
                id="p-image" type="file" accept="image/*"
                onChange={(e) => setImage(e.target.files?.[0] ?? null)}
                className="input py-1.5"
              />
              <p className="hint">JPG, PNG, WebP, AVIF or GIF, up to 5 MB.</p>
            </div>
          </div>

          <div className="mt-5 flex gap-2">
            <button type="submit" disabled={pending} className="btn-primary">
              {pending ? "Saving…" : editing ? "Save changes" : "Create product"}
            </button>
            <button type="button" onClick={() => setOpen(false)} className="btn-secondary">Cancel</button>
          </div>
        </form>
      ) : null}

      {products.length === 0 ? (
        <div className="card px-6 py-14 text-center">
          <p className="font-semibold">No products yet</p>
          <p className="mt-1 text-sm text-ink-600">Add your first product to start selling.</p>
          <button type="button" onClick={startCreate} className="btn-primary mt-4">Add a product</button>
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => {
            const stock = p.inventory?.stockQuantity ?? 0;
            const reserved = p.inventory?.reservedQuantity ?? 0;
            return (
              <li key={p.id} className="card overflow-hidden">
                <div className="relative aspect-[4/3] w-full bg-ink-100">
                  <Thumb src={p.imageUrl} alt={p.name} category={p.category} />
                  <span className={`absolute left-2 top-2 rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset ${
                    p.status === "PUBLISHED"
                      ? "bg-brand-50 text-brand-700 ring-brand-200"
                      : "bg-ink-100 text-ink-600 ring-ink-200"
                  }`}>
                    {p.status === "PUBLISHED" ? "Live" : p.status === "DRAFT" ? "Draft" : "Archived"}
                  </span>
                </div>

                <div className="p-4">
                  <p className="font-semibold leading-snug">{p.name}</p>
                  <p className="mt-0.5 text-[13px] text-ink-500">{p.category} · {p.unit}</p>
                  <p className="mt-1.5 text-lg font-bold">{formatINR(p.pricePaise)}</p>

                  <p className="mt-1.5 text-[13px]">
                    {stock <= 0 ? (
                      <span className="font-semibold text-red-600">Out of stock</span>
                    ) : stock <= (p.inventory?.lowStockThreshold ?? 5) ? (
                      <span className="font-semibold text-amber-700">Low — {stock} left</span>
                    ) : (
                      <span className="text-ink-600">{stock} in stock</span>
                    )}
                    {reserved > 0 ? <span className="text-ink-500"> · {reserved} held</span> : null}
                  </p>

                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <button type="button" onClick={() => startEdit(p)} className="btn-secondary btn-sm">Edit</button>
                    {p.status !== "PUBLISHED" ? (
                      <button
                        type="button"
                        disabled={pending}
                        onClick={() => quickUpdate(p, { status: "PUBLISHED" })}
                        className="btn-primary btn-sm"
                      >
                        Publish
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={pending}
                        onClick={() => quickUpdate(p, { status: "DRAFT" })}
                        className="btn-secondary btn-sm"
                      >
                        Unpublish
                      </button>
                    )}
                    {p.status !== "ARCHIVED" ? (
                      <button type="button" disabled={pending} onClick={() => archive(p)} className="btn-ghost text-red-600">
                        Archive
                      </button>
                    ) : null}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

async function toResult(res: Response): Promise<{ ok: true } | { ok: false; error: ApiErrorShape }> {
  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    return {
      ok: false,
      error: payload?.error ?? { code: "UNKNOWN", message: "We couldn't save that product." },
    };
  }
  return { ok: true };
}
