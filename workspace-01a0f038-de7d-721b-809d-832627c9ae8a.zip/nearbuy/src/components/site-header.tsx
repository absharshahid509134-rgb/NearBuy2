"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/client";

interface Me {
  user: { id: string; role: string; name: string; email: string } | null;
  store?: { name: string; status: string } | null;
  cartQuantity?: number;
}

const ROLE_HOME: Record<string, string> = {
  CUSTOMER: "/customer",
  SELLER: "/seller",
  RIDER: "/rider",
};

const NAV: Record<string, Array<{ href: string; label: string }>> = {
  CUSTOMER: [
    { href: "/customer/stores", label: "Stores" },
    { href: "/customer/search", label: "Search" },
    { href: "/customer/orders", label: "Orders" },
    { href: "/customer/reservations", label: "Reservations" },
  ],
  SELLER: [
    { href: "/seller", label: "Dashboard" },
    { href: "/seller/orders", label: "Orders" },
    { href: "/seller/products", label: "Products" },
    { href: "/seller/inbox", label: "Inbox" },
  ],
  RIDER: [
    { href: "/rider", label: "Dashboard" },
    { href: "/rider/jobs", label: "Jobs" },
    { href: "/rider/earnings", label: "Earnings" },
  ],
};

export function SiteHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [open, setOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const isPublic = !pathname.startsWith("/customer") && !pathname.startsWith("/seller") && !pathname.startsWith("/rider");

  useEffect(() => {
    let alive = true;
    api.get<Me>("/api/auth/me").then((r) => alive && setMe(r.ok ? r.data : { user: null }));
    return () => { alive = false; };
  }, [pathname]);

  // Close the mobile drawer whenever the route changes.
  useEffect(() => setOpen(false), [pathname]);

  // Escape closes the account menu; a click outside dismisses it too.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenuOpen(false);
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [menuOpen]);

  const role = me?.user?.role ?? "";
  const links = NAV[role] ?? [];

  async function signOut() {
    await api.post("/api/auth/logout");
    setMe({ user: null });
    router.push("/");
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 border-b border-ink-200 bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
        <Link href="/" className="flex shrink-0 items-center gap-2 font-bold text-ink-900">
          <span
            aria-hidden
            className="grid h-8 w-8 place-items-center rounded-lg bg-brand-600 text-white"
          >
            N
          </span>
          <span className="text-[17px] tracking-tight">NearBuy</span>
        </Link>

        <nav aria-label="Main" className="ml-2 hidden items-center gap-1 md:flex">
          {isPublic && !me?.user ? (
            <>
              <Link href="/stores" className="rounded-lg px-3 py-2 text-sm font-medium text-ink-600 hover:bg-ink-100">
                Browse stores
              </Link>
              <Link href="/customer/login" className="rounded-lg px-3 py-2 text-sm font-medium text-ink-600 hover:bg-ink-100">
                Customer sign in
              </Link>
            </>
          ) : (
            links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                aria-current={pathname === l.href ? "page" : undefined}
                className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  pathname === l.href
                    ? "bg-brand-50 text-brand-700"
                    : "text-ink-600 hover:bg-ink-100"
                }`}
              >
                {l.label}
              </Link>
            ))
          )}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {role === "CUSTOMER" ? (
            <Link
              href="/customer/cart"
              className="relative grid h-10 w-10 place-items-center rounded-xl text-ink-700 hover:bg-ink-100"
              aria-label={`Cart${me?.cartQuantity ? `, ${me.cartQuantity} items` : ""}`}
            >
              <span aria-hidden>🛒</span>
              {me?.cartQuantity ? (
                <span className="absolute -right-0.5 -top-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-brand-600 px-1 text-[11px] font-bold text-white">
                  {me.cartQuantity > 99 ? "99+" : me.cartQuantity}
                </span>
              ) : null}
            </Link>
          ) : null}

          {me?.user ? (
            <div className="relative" ref={menuRef}>
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-haspopup="menu"
                className="flex h-10 items-center gap-2 rounded-xl border border-ink-200 px-2.5 text-sm font-medium hover:bg-ink-100"
              >
                <span className="grid h-6 w-6 place-items-center rounded-full bg-brand-100 text-xs font-bold text-brand-800">
                  {me.user.name.charAt(0).toUpperCase()}
                </span>
                <span className="hidden max-w-24 truncate sm:inline">{me.user.name.split(" ")[0]}</span>
                <span aria-hidden className="text-ink-400">▾</span>
              </button>
              {menuOpen ? (
                <div
                  role="menu"
                  className="absolute right-0 mt-2 w-60 overflow-hidden rounded-xl border border-ink-200 bg-white shadow-lg"
                >
                  <div className="border-b border-ink-100 px-4 py-3">
                    <p className="truncate text-sm font-semibold">{me.user.name}</p>
                    <p className="truncate text-[13px] text-ink-500">{me.user.email}</p>
                    <p className="mt-1 inline-flex rounded-full bg-ink-100 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-ink-600">
                      {me.user.role.toLowerCase()}
                    </p>
                  </div>
                  <Link role="menuitem" href={`${ROLE_HOME[me.user.role]}/profile`} className="block px-4 py-2.5 text-sm hover:bg-ink-100">
                    Profile & settings
                  </Link>
                  <button
                    role="menuitem"
                    onClick={signOut}
                    className="block w-full px-4 py-2.5 text-left text-sm text-red-600 hover:bg-red-50"
                  >
                    Sign out
                  </button>
                </div>
              ) : null}
            </div>
          ) : (
            <Link href="/customer/login" className="btn-primary hidden sm:inline-flex">
              Sign in
            </Link>
          )}

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            className="grid h-10 w-10 place-items-center rounded-xl text-ink-700 hover:bg-ink-100 md:hidden"
          >
            <span aria-hidden>{open ? "✕" : "☰"}</span>
          </button>
        </div>
      </div>

      {open ? (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-ink-200 bg-white md:hidden">
          <div className="mx-auto max-w-6xl px-4 py-3">
            {isPublic && !me?.user ? (
              <>
                <MobileLink href="/stores">Browse stores</MobileLink>
                <MobileLink href="/customer/login">Customer sign in</MobileLink>
                <MobileLink href="/seller/login">Seller sign in</MobileLink>
                <MobileLink href="/rider/login">Rider sign in</MobileLink>
              </>
            ) : (
              <>
                {links.map((l) => (
                  <MobileLink key={l.href} href={l.href}>
                    {l.label}
                  </MobileLink>
                ))}
                {role ? <MobileLink href={`${ROLE_HOME[role]}/profile`}>Profile</MobileLink> : null}
              </>
            )}
          </div>
        </nav>
      ) : null}
    </header>
  );
}

function MobileLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="block rounded-lg px-3 py-2.5 text-[15px] font-medium text-ink-700 hover:bg-ink-100"
    >
      {children}
    </Link>
  );
}
