import Image from "next/image";
import type { ReactNode } from "react";

/* ----------------------------------------------------------------- images -- */

const TINTS: Record<string, string> = {
  Dairy: "from-sky-100 to-sky-50",
  Grocery: "from-amber-100 to-amber-50",
  Bakery: "from-orange-100 to-orange-50",
  Pharmacy: "from-teal-100 to-teal-50",
  "Fruits & Vegetables": "from-lime-100 to-lime-50",
  Snacks: "from-rose-100 to-rose-50",
  Beverages: "from-cyan-100 to-cyan-50",
  "Personal Care": "from-purple-100 to-purple-50",
  Household: "from-slate-200 to-slate-50",
  Stationery: "from-indigo-100 to-indigo-50",
};

const DEFAULT_TINT = "from-brand-100 to-brand-50";

/**
 * Product/store imagery with a deterministic, category-tinted fallback.
 *
 * A missing or broken image never shows a broken-image icon: it falls back to
 * a tasteful tile. `alt` is always meaningful for screen readers.
 */
export function Thumb({
  src,
  alt,
  category,
  className = "",
  sizes = "(max-width: 640px) 40vw, 200px",
  priority = false,
}: {
  src?: string | null;
  alt: string;
  category?: string | null;
  className?: string;
  sizes?: string;
  priority?: boolean;
}) {
  const tint = TINTS[category ?? ""] ?? DEFAULT_TINT;
  if (!src) {
    return (
      <div
        className={`flex items-center justify-center bg-gradient-to-br ${tint} ${className}`}
        role="img"
        aria-label={alt}
      >
        <span className="px-2 text-center text-[11px] font-semibold uppercase tracking-wide text-ink-500">
          {category ?? "NearBuy"}
        </span>
      </div>
    );
  }
  return (
    <Image
      src={src}
      alt={alt}
      fill
      sizes={sizes}
      priority={priority}
      className={`object-cover ${className}`}
      unoptimized={src.startsWith("http")}
    />
  );
}

/* ------------------------------------------------------------ status pill -- */

const STATUS_TONE: Record<string, string> = {
  PLACED: "bg-ink-100 text-ink-700 ring-ink-200",
  ACCEPTED: "bg-sky-50 text-sky-700 ring-sky-200",
  PREPARING: "bg-amber-50 text-amber-800 ring-amber-200",
  PACKED: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  READY_FOR_PICKUP: "bg-violet-50 text-violet-700 ring-violet-200",
  PICKED_UP: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  OUT_FOR_DELIVERY: "bg-blue-50 text-blue-700 ring-blue-200",
  DELIVERED: "bg-brand-50 text-brand-700 ring-brand-200",
  REJECTED: "bg-red-50 text-red-700 ring-red-200",
  CANCELLED: "bg-ink-100 text-ink-600 ring-ink-200",

  AVAILABLE: "bg-brand-50 text-brand-700 ring-brand-200",
  ASSIGNED: "bg-sky-50 text-sky-700 ring-sky-200",
  COMPLETED: "bg-brand-50 text-brand-700 ring-brand-200",

  PENDING: "bg-amber-50 text-amber-800 ring-amber-200",
  CONFIRMED: "bg-brand-50 text-brand-700 ring-brand-200",
  REJECTED_: "bg-red-50 text-red-700 ring-red-200",
  UNAVAILABLE: "bg-red-50 text-red-700 ring-red-200",
  EXPIRED: "bg-ink-100 text-ink-600 ring-ink-200",
  FULFILLED: "bg-brand-50 text-brand-700 ring-brand-200",
};

const STATUS_TEXT: Record<string, string> = {
  PLACED: "Placed",
  ACCEPTED: "Accepted",
  PREPARING: "Preparing",
  PACKED: "Packed",
  READY_FOR_PICKUP: "Ready for pickup",
  PICKED_UP: "Picked up",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered",
  REJECTED: "Rejected",
  CANCELLED: "Cancelled",
  AVAILABLE: "Available",
  ASSIGNED: "Assigned",
  COMPLETED: "Completed",
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  UNAVAILABLE: "Not available",
  EXPIRED: "Expired",
  FULFILLED: "Fulfilled",
  DRAFT: "Draft",
  PUBLISHED: "Published",
  SUSPENDED: "Suspended",
  ARCHIVED: "Archived",
  ACTIVE: "Active",
  OPEN: "Open",
  CLOSED: "Closed",
};

/**
 * Status is communicated by a written label first, colour second — so the
 * badge still works for colour-blind users and in a screenshot printed in B&W.
 */
export function StatusBadge({ status, className = "" }: { status: string; className?: string }) {
  const tone = STATUS_TONE[status] ?? "bg-ink-100 text-ink-700 ring-ink-200";
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs
                  font-semibold ring-1 ring-inset ${tone} ${className}`}
    >
      <span aria-hidden className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {STATUS_TEXT[status] ?? status.replace(/_/g, " ").toLowerCase()}
    </span>
  );
}

/* ------------------------------------------------------------------ shell -- */

export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        <h1 className="text-2xl font-bold tracking-tight sm:text-[28px]">{title}</h1>
        {description ? <p className="mt-1.5 text-ink-600 text-[15px]">{description}</p> : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </header>
  );
}

export function EmptyState({
  title,
  description,
  action,
  icon = "🛒",
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: string;
}) {
  return (
    <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
      <span aria-hidden className="text-4xl">{icon}</span>
      <div>
        <p className="font-semibold text-ink-900">{title}</p>
        {description ? <p className="mt-1 text-sm text-ink-600 max-w-sm">{description}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden />;
}

export function ProductCardSkeleton() {
  return (
    <div className="card overflow-hidden">
      <Skeleton className="aspect-[4/3] w-full rounded-none" />
      <div className="space-y-2.5 p-4">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-3 w-1/2" />
        <Skeleton className="h-5 w-1/3" />
      </div>
    </div>
  );
}

export function Alert({
  tone = "info",
  children,
  role = "status",
}: {
  tone?: "info" | "error" | "success" | "warning";
  children: ReactNode;
  role?: "status" | "alert";
}) {
  const tones = {
    info: "bg-sky-50 text-sky-900 border-sky-200",
    error: "bg-red-50 text-red-900 border-red-200",
    success: "bg-brand-50 text-brand-900 border-brand-200",
    warning: "bg-amber-50 text-amber-900 border-amber-200",
  } as const;
  return (
    <div
      role={role}
      className={`rounded-xl border px-3.5 py-3 text-sm font-medium ${tones[tone]}`}
    >
      {children}
    </div>
  );
}

/**
 * A big, unmistakable handoff code. Rendered only by the party entitled to it
 * and only at the correct operational stage (enforced on the server).
 */
export function HandoffCode({
  code,
  label,
  hint,
}: {
  code: string;
  label: string;
  hint: string;
}) {
  return (
    <div className="rounded-xl border border-dashed border-brand-300 bg-brand-50 p-4 text-center">
      <p className="text-xs font-semibold uppercase tracking-wider text-brand-700">{label}</p>
      <p
        className="mt-1.5 font-mono text-3xl font-bold tracking-[0.3em] text-brand-900"
        aria-label={`${label} is ${code.split("").join(" ")}`}
      >
        {code}
      </p>
      <p className="mt-2 text-[13px] text-brand-800">{hint}</p>
    </div>
  );
}

export function Stat({
  label,
  value,
  tone = "default",
  href,
}: {
  label: string;
  value: ReactNode;
  tone?: "default" | "accent" | "warn" | "danger";
  href?: string;
}) {
  const tones = {
    default: "text-ink-900",
    accent: "text-brand-700",
    warn: "text-amber-700",
    danger: "text-red-600",
  } as const;
  const body = (
    <>
      <p className="text-2xl font-bold tabular-nums">{value}</p>
      <p className="mt-0.5 text-[13px] text-ink-500">{label}</p>
    </>
  );
  const cls = `card p-4 ${href ? "transition-shadow hover:shadow-md" : ""}`;
  if (href) {
    return (
      <a href={href} className={`${cls} block focus-visible:outline-2 focus-visible:outline-brand-600`}>
        <span className={tones[tone]}>{body}</span>
      </a>
    );
  }
  return <div className={cls}>{body}</div>;
}
