"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiErrorShape } from "@/lib/client";
import { Alert } from "./ui";

export function RiderOnboarding({
  currentVehicleType,
  currentVehicleNumber,
  isOnboarded,
}: {
  currentVehicleType: string;
  currentVehicleNumber: string | null;
  isOnboarded: boolean;
}) {
  const router = useRouter();
  const [vehicleType, setVehicleType] = useState(currentVehicleType);
  const [vehicleNumber, setVehicleNumber] = useState(currentVehicleNumber ?? "");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<ApiErrorShape | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);
    const res = await api.patch("/api/rider/profile", {
      vehicleType,
      vehicleNumber,
      onboardingStep: 3,
    });
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    router.refresh();
  }

  const steps = [
    { label: "Account created", done: true },
    { label: "Vehicle details", done: Boolean(currentVehicleNumber) },
    { label: "Ready to deliver", done: isOnboarded },
  ];

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <section className="card p-5">
        <h2 className="font-bold">Set up your rider profile</h2>
        <p className="mt-1 text-sm text-ink-600">
          We use this to match you to deliveries and to identify your vehicle at pickup.
        </p>

        <ol className="mt-4 space-y-2" aria-label="Onboarding progress">
          {steps.map((s, i) => (
            <li key={s.label} className="flex items-center gap-2.5 text-sm">
              <span
                aria-hidden
                className={`grid h-6 w-6 place-items-center rounded-full text-xs font-bold ${
                  s.done ? "bg-brand-600 text-white" : "bg-ink-200 text-ink-600"
                }`}
              >
                {s.done ? "✓" : i + 1}
              </span>
              <span className={s.done ? "font-medium text-ink-900" : "text-ink-600"}>{s.label}</span>
            </li>
          ))}
        </ol>

        {isOnboarded ? (
          <div className="mt-5">
            <Alert tone="success">
              You&apos;re all set — {currentVehicleType.toLowerCase()} {currentVehicleNumber}.{" "}
              <button
                type="button"
                onClick={() => router.push("/rider/jobs")}
                className="font-semibold underline"
              >
                Go to available jobs
              </button>
            </Alert>
          </div>
        ) : null}
      </section>

      <section className="card p-5">
        <h2 className="font-bold">Vehicle details</h2>
        <form onSubmit={submit} className="mt-4 space-y-3" noValidate>
          {error ? <Alert tone="error" role="alert">{error.message}</Alert> : null}

          <div>
            <label htmlFor="vehicleType" className="label">Vehicle type</label>
            <select id="vehicleType" value={vehicleType} onChange={(e) => setVehicleType(e.target.value as "BIKE")} className="input">
              <option value="BIKE">Two-wheeler</option>
              <option value="BICYCLE">Bicycle</option>
              <option value="CAR">Car</option>
            </select>
          </div>

          <div>
            <label htmlFor="vehicleNumber" className="label">Registration number</label>
            <input
              id="vehicleNumber"
              value={vehicleNumber}
              onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
              placeholder="DL 1L AB 4821"
              className="input"
              required
              aria-invalid={Boolean(error?.details?.vehicleNumber)}
              aria-describedby={error?.details?.vehicleNumber ? "vn-err" : undefined}
            />
            {error?.details?.vehicleNumber ? (
              <p id="vn-err" className="error-text">{error.details.vehicleNumber}</p>
            ) : (
              <p className="hint">As printed on your number plate, e.g. DL 1L AB 4821.</p>
            )}
          </div>

          <button type="submit" disabled={pending} className="btn-primary w-full">
            {pending ? "Saving…" : isOnboarded ? "Update vehicle" : "Finish onboarding"}
          </button>
        </form>
      </section>
    </div>
  );
}
