"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

export function ProfileView({
  name,
  email,
  phone,
  role,
}: {
  name: string;
  email: string;
  phone: string | null;
  role: string;
}) {
  const router = useRouter();
  const [form, setForm] = useState({ name, phone: phone ?? "" });
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [message, setMessage] = useState<{ tone: "success" | "error"; text: string } | null>(null);
  const [passwordMessage, setPasswordMessage] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    setMessage(null);
    const res = await api.patch("/api/profile", { name: form.name, phone: form.phone });
    setSavingProfile(false);
    if (!res.ok) {
      setMessage({ tone: "error", text: res.error.message });
      return;
    }
    setMessage({ tone: "success", text: "Profile updated." });
    router.refresh();
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setSavingPassword(true);
    setPasswordMessage(null);
    const res = await api.post("/api/profile/password", { currentPassword: current, newPassword: next });
    setSavingPassword(false);
    if (!res.ok) {
      setPasswordMessage({ tone: "error", text: res.error.message });
      return;
    }
    setPasswordMessage({
      tone: "success",
      text: "Password changed. For your safety, every session has been signed out — please sign in again.",
    });
    setCurrent("");
    setNext("");
    setTimeout(() => router.push(`/${role.toLowerCase()}/login`), 1800);
  }

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <section className="card p-5">
        <h2 className="font-bold">Your details</h2>
        <p className="mt-1 text-sm text-ink-600">
          Signed in as <span className="font-semibold uppercase text-brand-700">{role.toLowerCase()}</span>.
        </p>

        <form onSubmit={saveProfile} className="mt-4 space-y-3" noValidate>
          {message ? <Alert tone={message.tone} role="status">{message.text}</Alert> : null}

          <div>
            <label htmlFor="name" className="label">Full name</label>
            <input
              id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="input" required
            />
          </div>

          <div>
            <label htmlFor="profile-email" className="label">Email address</label>
            <input id="profile-email" value={email} disabled className="input" />
            <p className="hint">Your email is your sign-in ID and cannot be changed here.</p>
          </div>

          <div>
            <label htmlFor="phone" className="label">Mobile number</label>
            <input
              id="phone" value={form.phone} inputMode="numeric" maxLength={10}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="input" placeholder="98100 12345"
            />
          </div>

          <button type="submit" disabled={savingProfile} className="btn-primary">
            {savingProfile ? "Saving…" : "Save changes"}
          </button>
        </form>
      </section>

      <section className="card p-5">
        <h2 className="font-bold">Change password</h2>
        <p className="mt-1 text-sm text-ink-600">
          Changing your password signs out every device, including this one.
        </p>

        <form onSubmit={changePassword} className="mt-4 space-y-3" noValidate>
          {passwordMessage ? (
            <Alert tone={passwordMessage.tone} role="status">{passwordMessage.text}</Alert>
          ) : null}

          <div>
            <label htmlFor="currentPassword" className="label">Current password</label>
            <input
              id="currentPassword" type="password" autoComplete="current-password"
              value={current} onChange={(e) => setCurrent(e.target.value)}
              className="input" required
            />
          </div>

          <div>
            <label htmlFor="newPassword" className="label">New password</label>
            <input
              id="newPassword" type="password" autoComplete="new-password"
              value={next} onChange={(e) => setNext(e.target.value)}
              className="input" required
            />
            <p className="hint">At least 10 characters with upper and lower case, a number and a symbol.</p>
          </div>

          <button type="submit" disabled={savingPassword} className="btn-primary">
            {savingPassword ? "Updating…" : "Change password"}
          </button>
        </form>
      </section>
    </div>
  );
}
