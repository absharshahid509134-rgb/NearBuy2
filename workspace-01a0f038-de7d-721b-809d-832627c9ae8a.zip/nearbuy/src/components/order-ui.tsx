import type { ReactNode } from "react";
import { StatusBadge } from "./ui";

export interface TimelineEvent {
  type: string;
  actorRole: string;
  createdAt: Date | string;
  metadata?: string | null;
}

const COPY: Record<string, string> = {
  ORDER_PLACED: "Order placed",
  SELLER_ACCEPTED: "Store accepted the order",
  SELLER_PREPARING: "Store started preparing",
  SELLER_PACKED: "Order packed",
  READY_FOR_PICKUP: "Ready for pickup",
  JOB_AVAILABLE: "Delivery job opened to riders",
  JOB_ASSIGNED: "Rider assigned",
  PICKUP_VERIFIED: "Rider picked up the order",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERY_VERIFIED: "Delivered",
  ORDER_REJECTED: "Order declined by the store",
  ORDER_CANCELLED: "Order cancelled",
  PICKUP_CODE_FAILED: "Incorrect pickup code entered",
  DELIVERY_CODE_FAILED: "Incorrect delivery code entered",
};

/**
 * The order timeline. All three roles render the same persisted event list —
 * that shared source of truth is what keeps customer, seller and rider views
 * from ever disagreeing about what happened.
 */
export function OrderTimeline({ events }: { events: TimelineEvent[] }) {
  if (events.length === 0) {
    return <p className="text-sm text-ink-500">No activity recorded yet.</p>;
  }
  return (
    <ol className="space-y-0">
      {events.map((e, i) => {
        const isLast = i === events.length - 1;
        const isFailure = e.type.includes("FAILED") || e.type.includes("REJECTED") || e.type.includes("CANCELLED");
        return (
          <li key={`${e.type}-${i}`} className="flex gap-3">
            <div className="flex flex-col items-center">
              <span
                aria-hidden
                className={`mt-1 grid h-3 w-3 shrink-0 rounded-full ring-4 ${
                  isFailure
                    ? "bg-red-500 ring-red-100"
                    : "bg-brand-600 ring-brand-100"
                }`}
              />
              {!isLast ? <span aria-hidden className="w-px flex-1 bg-ink-200" /> : null}
            </div>
            <div className="pb-5">
              <p className="text-sm font-semibold leading-snug">
                {COPY[e.type] ?? e.type.replace(/_/g, " ").toLowerCase()}
              </p>
              <p className="mt-0.5 text-[13px] text-ink-500">
                {new Date(e.createdAt).toLocaleString("en-IN", {
                  day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
                })}
                {e.actorRole && e.actorRole !== "SYSTEM" ? ` · ${e.actorRole.toLowerCase()}` : ""}
              </p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

/** Compact, readable order row used on the customer/seller/rider list pages. */
export function OrderCard({
  href,
  orderNumber,
  storeName,
  status,
  fulfillmentType,
  totalPaise,
  itemSummary,
  placedAt,
  right,
}: {
  href: string;
  orderNumber: string;
  storeName: string;
  status: string;
  fulfillmentType: string;
  totalPaise: number;
  itemSummary: ReactNode;
  placedAt: Date | string;
  right?: ReactNode;
}) {
  return (
    <div className="card p-4 transition-shadow hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <a href={href} className="font-semibold hover:text-brand-700 hover:underline">
              {orderNumber}
            </a>
            <StatusBadge status={status} />
            <span className="rounded-full bg-ink-100 px-2 py-0.5 text-[11px] font-semibold text-ink-600">
              {fulfillmentType === "PICKUP" ? "Pickup" : "Delivery"}
            </span>
          </div>
          <p className="mt-1 truncate text-sm text-ink-600">{storeName}</p>
          <p className="mt-0.5 text-[13px] text-ink-500">
            {new Date(placedAt).toLocaleString("en-IN", {
              day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
            })}
          </p>
        </div>
        {right}
      </div>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-3 border-t border-ink-100 pt-3">
        <div className="min-w-0 text-sm text-ink-600">{itemSummary}</div>
        <p className="text-right text-lg font-bold tabular-nums">
          ₹{Math.round(totalPaise / 100).toLocaleString("en-IN")}
        </p>
      </div>
    </div>
  );
}
