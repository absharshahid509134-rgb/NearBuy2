"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

/**
 * Quantity + add, with the server as the authority. If the server rejects the
 * add — out of stock, store closed, session gone — we show its message rather
 * than pretending it worked, and refresh so the page reflects reality.
 */
export function AddToCartButton({ productId, compact = false }: { productId: string; compact?: boolean }) {
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState<{ tone: "error" | "success"; text: string } | null>(null);

  async function add() {
    setPending(true);
    setMessage(null);
    const res = await api.post("/api/cart/items", { productId, quantity });
    setPending(false);

    if (!res.ok) {
      setMessage({ tone: "error", text: res.error.message });
      router.refresh();
      return;
    }
    setMessage({ tone: "success", text: "Added to cart" });
    router.refresh();
    setTimeout(() => setMessage(null), 2500);
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        {!compact ? (
          <div className="flex items-center rounded-xl border border-ink-300">
            <button
              type="button"
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              disabled={quantity <= 1 || pending}
              aria-label="Decrease quantity"
              className="grid h-11 w-10 place-items-center text-ink-700 hover:bg-ink-100 disabled:opacity-40"
            >
              −
            </button>
            <label htmlFor={`qty-${productId}`} className="sr-only">Quantity</label>
            <input
              id={`qty-${productId}`}
              type="number"
              inputMode="numeric"
              min={1}
              max={99}
              value={quantity}
              onChange={(e) => setQuantity(Math.min(99, Math.max(1, Number(e.target.value) || 1)))}
              className="h-11 w-12 border-x border-ink-200 text-center text-sm font-semibold tabular-nums focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setQuantity((q) => Math.min(99, q + 1))}
              disabled={quantity >= 99 || pending}
              aria-label="Increase quantity"
              className="grid h-11 w-10 place-items-center text-ink-700 hover:bg-ink-100 disabled:opacity-40"
            >
              +
            </button>
          </div>
        ) : null}

        <button type="button" onClick={add} disabled={pending} className="btn-primary flex-1">
          {pending ? "Adding…" : "Add to cart"}
        </button>
      </div>

      {message ? (
        <Alert tone={message.tone} role="status">{message.text}</Alert>
      ) : null}
    </div>
  );
}
