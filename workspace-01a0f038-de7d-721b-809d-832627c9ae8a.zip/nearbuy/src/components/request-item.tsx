"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

/**
 * Stock check and reservation are deliberately separate actions, because they
 * mean different things: a stock check is a question, a reservation asks the
 * store to hold goods. The copy never implies stock is held before the seller
 * has actually confirmed it.
 */
export function RequestItemButton({ productId, disabled = false }: { productId: string; disabled?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"STOCK" | "RESERVATION">("STOCK");
  const [quantity, setQuantity] = useState(1);
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function submit() {
    setPending(true);
    setResult(null);
    const path = kind === "STOCK" ? "/api/stock-requests" : "/api/reservations";
    const res = await api.post(path, { productId, quantity });
    setPending(false);

    if (!res.ok) {
      setResult({ tone: "error", text: res.error.message });
      return;
    }
    setResult({
      tone: "success",
      text:
        kind === "STOCK"
          ? "Stock check sent. The store will reply from their dashboard."
          : "Reservation requested. Stock is not held until the store confirms.",
    });
    setOpen(false);
    router.refresh();
  }

  if (disabled) {
    return (
      <button type="button" disabled className="btn-secondary w-full">
        Unavailable
      </button>
    );
  }

  return (
    <div>
      {!open ? (
        <div className="flex gap-2">
          <button type="button" onClick={() => { setKind("STOCK"); setOpen(true); }} className="btn-secondary btn-sm flex-1">
            Check stock
          </button>
          <button type="button" onClick={() => { setKind("RESERVATION"); setOpen(true); }} className="btn-secondary btn-sm flex-1">
            Reserve
          </button>
        </div>
      ) : (
        <div className="rounded-xl border border-ink-200 bg-ink-50 p-3">
          <p className="text-sm font-semibold">
            {kind === "STOCK" ? "Ask if this is in stock" : "Request a reservation"}
          </p>
          <p className="mt-0.5 text-[13px] text-ink-600">
            {kind === "STOCK"
              ? "The store confirms availability. This does not hold anything."
              : "The store may hold goods for you. Nothing is held until they confirm."}
          </p>

          <div className="mt-2.5 flex items-center gap-2">
            <label htmlFor={`rq-${productId}`} className="text-[13px] font-medium text-ink-700">Quantity</label>
            <input
              id={`rq-${productId}`}
              type="number" min={1} max={99} value={quantity}
              onChange={(e) => setQuantity(Math.min(99, Math.max(1, Number(e.target.value) || 1)))}
              className="input h-9 w-20 py-0 text-center"
            />
          </div>

          <div className="mt-3 flex gap-2">
            <button type="button" onClick={submit} disabled={pending} className="btn-primary btn-sm flex-1">
              {pending ? "Sending…" : "Send request"}
            </button>
            <button type="button" onClick={() => setOpen(false)} className="btn-secondary btn-sm">
              Cancel
            </button>
          </div>
        </div>
      )}

      {result ? <div className="mt-2"><Alert tone={result.tone} role="status">{result.text}</Alert></div> : null}
    </div>
  );
}
