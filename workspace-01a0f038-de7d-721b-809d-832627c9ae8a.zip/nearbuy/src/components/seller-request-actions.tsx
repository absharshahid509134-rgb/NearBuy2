"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

/**
 * Stock check response.
 *
 * Confirming a stock check explicitly does NOT reserve anything — the copy
 * says so, because a customer who believes goods are held will not check out.
 */
export function StockRequestActions({
  requestId,
  productId,
  requestedQuantity,
  availableStock,
}: {
  requestId: string;
  productId: string;
  requestedQuantity: number;
  availableStock: number;
}) {
  const router = useRouter();
  const [note, setNote] = useState("");
  const [pending, setPending] = useState<"CONFIRMED" | "UNAVAILABLE" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canConfirm = availableStock >= requestedQuantity;

  async function respond(status: "CONFIRMED" | "UNAVAILABLE") {
    setPending(status);
    setError(null);
    const res = await api.post(`/api/stock-requests/${requestId}/respond`, {
      status,
      response: note.trim() || undefined,
    });
    setPending(null);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div className="mt-3 space-y-2">
      {error ? <Alert tone="error" role="alert">{error}</Alert> : null}
      <label htmlFor={`note-${requestId}`} className="label">
        Reply to the customer (optional)
      </label>
      <input
        id={`note-${requestId}`}
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Yes, we have it on the shelf."
        className="input"
      />
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => respond("CONFIRMED")}
          disabled={pending !== null}
          title={canConfirm ? undefined : "You do not have enough sellable stock to confirm this."}
          className="btn-primary btn-sm"
        >
          {pending === "CONFIRMED" ? "Sending…" : "Yes, in stock"}
        </button>
        <button
          type="button"
          onClick={() => respond("UNAVAILABLE")}
          disabled={pending !== null}
          className="btn-secondary btn-sm"
        >
          {pending === "UNAVAILABLE" ? "Sending…" : "Not available"}
        </button>
      </div>
      <p className="text-[13px] text-ink-500">
        Confirming answers the question only. Stock is not reserved until the customer checks out.
      </p>
    </div>
  );
}

/**
 * Reservation response.
 *
 * `holdStock` is the meaningful switch: only when the seller ticks it does
 * reservedQuantity actually increase, reducing sellable stock. The row records
 * which happened in `stockHeld`, and the customer's UI reads that.
 */
export function ReservationActions({
  reservationId,
  requestedQuantity,
  availableStock,
}: {
  reservationId: string;
  requestedQuantity: number;
  availableStock: number;
}) {
  const router = useRouter();
  const [note, setNote] = useState("");
  const [holdStock, setHoldStock] = useState(true);
  const [pending, setPending] = useState<"CONFIRMED" | "REJECTED" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canHold = availableStock >= requestedQuantity;

  async function respond(status: "CONFIRMED" | "REJECTED") {
    setPending(status);
    setError(null);
    const res = await api.post(`/api/reservations/${reservationId}/respond`, {
      status,
      response: note.trim() || undefined,
      holdStock: status === "CONFIRMED" && holdStock,
    });
    setPending(null);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div className="mt-3 space-y-2">
      {error ? <Alert tone="error" role="alert">{error}</Alert> : null}

      <label htmlFor={`rnote-${reservationId}`} className="label">Reply to the customer (optional)</label>
      <input
        id={`rnote-${reservationId}`}
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="We'll keep one aside for you."
        className="input"
      />

      <label className="flex items-start gap-2 text-sm text-ink-700">
        <input
          type="checkbox"
          checked={holdStock}
          onChange={(e) => setHoldStock(e.target.checked)}
          disabled={!canHold}
          className="mt-0.5 h-4 w-4 rounded"
        />
        <span>
          <span className="font-medium">Hold {requestedQuantity} unit{requestedQuantity === 1 ? "" : "s"} in stock</span>
          <span className="mt-0.5 block text-[13px] text-ink-500">
            {canHold
              ? "Reduces your sellable stock so nobody else can buy it. Released automatically if it expires."
              : `You only have ${availableStock} sellable — tick this off and confirm without holding.`}
          </span>
        </span>
      </label>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => respond("CONFIRMED")}
          disabled={pending !== null}
          className="btn-primary btn-sm"
        >
          {pending === "CONFIRMED" ? "Sending…" : holdStock && canHold ? "Confirm & hold" : "Confirm without holding"}
        </button>
        <button
          type="button"
          onClick={() => respond("REJECTED")}
          disabled={pending !== null}
          className="btn-secondary btn-sm"
        >
          {pending === "REJECTED" ? "Sending…" : "Decline"}
        </button>
      </div>
    </div>
  );
}
