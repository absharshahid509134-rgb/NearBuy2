"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";
import { ORDER_STATUS_LABEL, type OrderStatus } from "@/lib/enums";

/**
 * The seller order pipeline.
 *
 * Which buttons appear is a convenience only — `transitionOrder` re-derives
 * the legal moves from the state machine on the server, so a stale or
 * hand-crafted request still cannot skip a stage.
 */
const PIPELINE: Array<{ to: OrderStatus; label: string; variant?: "primary" | "secondary" | "danger" }> = [
  { to: "ACCEPTED", label: "Accept order", variant: "primary" },
  { to: "PREPARING", label: "Start preparing", variant: "primary" },
  { to: "PACKED", label: "Mark packed", variant: "primary" },
  { to: "READY_FOR_PICKUP", label: "Ready for pickup", variant: "primary" },
  { to: "DELIVERED", label: "Confirm collected", variant: "primary" },
  { to: "REJECTED", label: "Reject order", variant: "danger" },
];

export function SellerOrderActions({
  orderId,
  status,
  fulfillmentType,
  allowed,
}: {
  orderId: string;
  status: string;
  fulfillmentType: string;
  allowed: string[];
}) {
  const router = useRouter();
  const [pending, setPending] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmReject, setConfirmReject] = useState(false);

  const moves = PIPELINE.filter((m) => {
    if (m.to === "REJECTED") return allowed.includes("REJECTED");
    if (m.to === "DELIVERED") {
      // A seller can only complete a self-pickup order, never a delivery.
      return fulfillmentType === "PICKUP" && allowed.includes("DELIVERED");
    }
    return allowed.includes(m.to);
  });

  if (moves.length === 0) {
    return (
      <p className="text-sm text-ink-500">
        No action needed — this order is {ORDER_STATUS_LABEL[status as OrderStatus]?.toLowerCase() ?? status.toLowerCase()}.
      </p>
    );
  }

  async function move(to: OrderStatus) {
    setPending(to);
    setError(null);
    const res = await api.post(`/api/seller/orders/${orderId}/status`, { status: to });
    setPending(null);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    setConfirmReject(false);
    router.refresh();
  }

  const primary = moves.filter((m) => m.to !== "REJECTED");
  const canReject = moves.some((m) => m.to === "REJECTED");

  return (
    <div className="space-y-3">
      {error ? <Alert tone="error" role="alert">{error}</Alert> : null}

      <div className="flex flex-wrap gap-2">
        {primary.map((m) => (
          <button
            key={m.to}
            type="button"
            onClick={() => move(m.to)}
            disabled={pending !== null}
            className={m.variant === "primary" ? "btn-primary" : "btn-secondary"}
          >
            {pending === m.to ? "Working…" : m.label}
          </button>
        ))}

        {canReject && !confirmReject ? (
          <button type="button" onClick={() => setConfirmReject(true)} className="btn-secondary text-red-600">
            Reject
          </button>
        ) : null}
      </div>

      {confirmReject ? (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3.5">
          <p className="text-sm font-semibold text-red-900">Reject this order?</p>
          <p className="mt-1 text-[13px] text-red-800">
            The customer is notified and the items return to stock.
          </p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              onClick={() => move("REJECTED")}
              disabled={pending !== null}
              className="btn-danger btn-sm"
            >
              {pending === "REJECTED" ? "Rejecting…" : "Yes, reject it"}
            </button>
            <button type="button" onClick={() => setConfirmReject(false)} className="btn-secondary btn-sm">
              Cancel
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
