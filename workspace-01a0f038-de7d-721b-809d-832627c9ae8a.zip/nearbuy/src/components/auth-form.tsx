"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiErrorShape } from "@/lib/client";
import { Alert } from "./ui";

type Role = "CUSTOMER" | "SELLER" | "RIDER";

const COPY: Record<Role, { blurb: string; shopField: boolean; vehicle: boolean }> = {
  CUSTOMER: {
    blurb: "Shop the stores around you, keep a cart, and follow your delivery in real time.",
    shopField: false,
    vehicle: false,
  },
  SELLER: {
    blurb: "Publish your store, manage your catalogue and run your order queue.",
    shopField: true,
    vehicle: false,
  },
  RIDER: {
    blurb: "Claim deliveries near you, verify handoffs and track your earnings.",
    shopField: false,
    vehicle: true,
  },
};

export function AuthForm({ role, mode }: { role: Role; mode: "login" | "signup" }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<ApiErrorShape | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const isSignup = mode === "signup";
  const copy = COPY[role];

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    setPending(true);
    setError(null);
    setFieldErrors({});

    const payload: Record<string, unknown> = {
      role,
      email: String(form.get("email") ?? ""),
      password: String(form.get("password") ?? ""),
    };
    if (isSignup) {
      payload.name = String(form.get("name") ?? "");
      const phone = String(form.get("phone") ?? "").trim();
      if (phone) payload.phone = phone;
      if (copy.shopField) {
        const shop = String(form.get("shopName") ?? "").trim();
        if (shop) payload.shopName = shop;
      }
      if (copy.vehicle) payload.vehicleType = String(form.get("vehicleType") ?? "BIKE");
    }

    const res = isSignup
      ? await api.post<{ user: { role: string } }>("/api/auth/signup", payload)
      : await api.post<{ user: { role: string } }>("/api/auth/login", payload);

    setPending(false);

    if (!res.ok) {
      setError(res.error);
      setFieldErrors(res.error.details ?? {});
      return;
    }

    const home = `/${res.data.user.role.toLowerCase()}`;
    router.push(home);
    router.refresh();
  }

  const inputError = (name: string) => fieldErrors[name];

  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      {error ? (
        <Alert tone="error" role="alert">
          {error.message}
        </Alert>
      ) : null}

      {isSignup ? (
        <div>
          <label htmlFor="name" className="label">Full name</label>
          <input
            id="name" name="name" type="text" autoComplete="name" required
            aria-invalid={Boolean(inputError("name"))}
            aria-describedby={inputError("name") ? "name-err" : undefined}
            className="input" placeholder="Aarav Sharma"
          />
          {inputError("name") ? <p id="name-err" className="error-text">{inputError("name")}</p> : null}
        </div>
      ) : null}

      <div>
        <label htmlFor="email" className="label">Email address</label>
        <input
          id="email" name="email" type="email" inputMode="email" autoComplete="email" required
          aria-invalid={Boolean(inputError("email"))}
          aria-describedby={inputError("email") ? "email-err" : undefined}
          className="input" placeholder="you@example.com"
        />
        {inputError("email") ? <p id="email-err" className="error-text">{inputError("email")}</p> : null}
      </div>

      {isSignup ? (
        <div>
          <label htmlFor="phone" className="label">
            Mobile number <span className="font-normal text-ink-500">(optional)</span>
          </label>
          <input
            id="phone" name="phone" type="tel" inputMode="numeric" autoComplete="tel"
            className="input" placeholder="98100 12345" maxLength={10}
          />
          {inputError("phone") ? <p className="error-text">{inputError("phone")}</p> : null}
        </div>
      ) : null}

      {isSignup && copy.shopField ? (
        <div>
          <label htmlFor="shopName" className="label">
            Shop name <span className="font-normal text-ink-500">(you can change this later)</span>
          </label>
          <input id="shopName" name="shopName" type="text" className="input" placeholder="Sharma General Store" />
        </div>
      ) : null}

      {isSignup && copy.vehicle ? (
        <div>
          <label htmlFor="vehicleType" className="label">Vehicle type</label>
          <select id="vehicleType" name="vehicleType" className="input" defaultValue="BIKE">
            <option value="BIKE">Two-wheeler</option>
            <option value="BICYCLE">Bicycle</option>
            <option value="CAR">Car</option>
          </select>
        </div>
      ) : null}

      <div>
        <label htmlFor="password" className="label">Password</label>
        <input
          id="password" name="password" type="password" required
          autoComplete={isSignup ? "new-password" : "current-password"}
          aria-invalid={Boolean(inputError("password"))}
          aria-describedby={isSignup ? "password-hint" : inputError("password") ? "password-err" : undefined}
          className="input"
        />
        {inputError("password") ? (
          <p id="password-err" className="error-text">{inputError("password")}</p>
        ) : isSignup ? (
          <p id="password-hint" className="hint">
            At least 10 characters with upper and lower case, a number and a symbol.
          </p>
        ) : null}
      </div>

      <button type="submit" disabled={pending} className="btn-primary-lg w-full">
        {pending ? "Please wait…" : isSignup ? "Create account" : "Sign in"}
      </button>

      <p className="text-center text-sm text-ink-600">
        {isSignup ? "Already have an account? " : "New to NearBuy? "}
        <Link
          href={`/${role.toLowerCase()}/${isSignup ? "login" : "signup"}`}
          className="font-semibold text-brand-700 underline underline-offset-2"
        >
          {isSignup ? "Sign in" : "Create an account"}
        </Link>
      </p>

      <p className="text-center text-sm text-ink-500">{copy.blurb}</p>
    </form>
  );
}
