"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiErrorShape } from "@/lib/client";
import { Alert } from "./ui";

export interface AddressRow {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  line1: string;
  line2: string | null;
  landmark: string | null;
  city: string;
  state: string;
  pincode: string;
  latitude: number;
  longitude: number;
  isDefault: boolean;
}

const EMPTY = {
  label: "Home", fullName: "", phone: "", line1: "", line2: "", landmark: "",
  city: "New Delhi", state: "Delhi", pincode: "",
  latitude: 28.5921, longitude: 77.046, isDefault: false,
};

export function AddressManager({ addresses }: { addresses: AddressRow[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState<AddressRow | null>(null);
  const [adding, setAdding] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<ApiErrorShape | null>(null);
  const [form, setForm] = useState(EMPTY);

  function startAdd() {
    setForm({ ...EMPTY, fullName: "", phone: "", isDefault: addresses.length === 0 });
    setAdding(true);
    setEditing(null);
    setError(null);
  }

  function startEdit(a: AddressRow) {
    setForm({
      label: a.label, fullName: a.fullName, phone: a.phone, line1: a.line1,
      line2: a.line2 ?? "", landmark: a.landmark ?? "", city: a.city, state: a.state,
      pincode: a.pincode, latitude: a.latitude, longitude: a.longitude, isDefault: a.isDefault,
    });
    setEditing(a);
    setAdding(false);
    setError(null);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);
    const payload = {
      ...form,
      line2: form.line2 || undefined,
      landmark: form.landmark || undefined,
      // Coerce to number; the API validates the bounds.
      latitude: Number(form.latitude),
      longitude: Number(form.longitude),
    };
    const res = editing
      ? await api.patch(`/api/addresses/${editing.id}`, payload)
      : await api.post("/api/addresses", payload);
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setAdding(false);
    setEditing(null);
    router.refresh();
  }

  async function remove(id: string) {
    setPending(true);
    setError(null);
    const res = await api.del(`/api/addresses/${id}`);
    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    router.refresh();
  }

  const fieldErrors = error?.details ?? {};
  const busy = adding || editing;

  return (
    <div className="space-y-4">
      {error && !error.details ? <Alert tone="error" role="alert">{error.message}</Alert> : null}

      {addresses.length === 0 ? (
        <Alert tone="info">You have no saved addresses yet. Add one to check out with delivery.</Alert>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {addresses.map((a) => (
            <li key={a.id} className={`card p-4 ${a.isDefault ? "ring-2 ring-brand-500" : ""}`}>
              <div className="flex items-start justify-between gap-2">
                <p className="font-semibold">
                  {a.label}
                  {a.isDefault ? (
                    <span className="ml-2 rounded-full bg-brand-100 px-2 py-0.5 text-[11px] font-semibold text-brand-800">
                      Default
                    </span>
                  ) : null}
                </p>
                <div className="flex gap-1">
                  <button type="button" onClick={() => startEdit(a)} className="btn-ghost">Edit</button>
                  <button
                    type="button"
                    onClick={() => remove(a.id)}
                    disabled={pending}
                    className="btn-ghost text-red-600"
                  >
                    Delete
                  </button>
                </div>
              </div>
              <address className="mt-1.5 text-sm not-italic text-ink-600">
                <span className="block font-medium text-ink-800">{a.fullName} · {a.phone}</span>
                <span className="block">{a.line1}{a.line2 ? `, ${a.line2}` : ""}</span>
                {a.landmark ? <span className="block">Near {a.landmark}</span> : null}
                <span className="block">{a.city}, {a.state} {a.pincode}</span>
              </address>
            </li>
          ))}
        </ul>
      )}

      {!busy ? (
        <button type="button" onClick={startAdd} className="btn-secondary">Add an address</button>
      ) : (
        <form onSubmit={save} className="card p-5" noValidate>
          <h2 className="font-bold">{editing ? "Edit address" : "New address"}</h2>
          {error?.details ? (
            <div className="mt-3"><Alert tone="error" role="alert">{error.message}</Alert></div>
          ) : null}

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field id="label" label="Label" value={form.label} onChange={(v) => setForm({ ...form, label: v })} />
            <Field id="fullName" label="Recipient name" value={form.fullName} error={fieldErrors.fullName} onChange={(v) => setForm({ ...form, fullName: v })} />
            <Field id="phone" label="Mobile number" value={form.phone} inputMode="numeric" maxLength={10} error={fieldErrors.phone} onChange={(v) => setForm({ ...form, phone: v })} />
            <Field id="pincode" label="PIN code" value={form.pincode} inputMode="numeric" maxLength={6} error={fieldErrors.pincode} onChange={(v) => setForm({ ...form, pincode: v })} />
          </div>

          <div className="mt-3">
            <Field id="line1" label="Flat, house number and street" value={form.line1} error={fieldErrors.line1} onChange={(v) => setForm({ ...form, line1: v })} />
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field id="line2" label="Area or building (optional)" value={form.line2} onChange={(v) => setForm({ ...form, line2: v })} />
            <Field id="landmark" label="Landmark (optional)" value={form.landmark} onChange={(v) => setForm({ ...form, landmark: v })} />
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field id="city" label="City" value={form.city} onChange={(v) => setForm({ ...form, city: v })} />
            <Field id="state" label="State" value={form.state} onChange={(v) => setForm({ ...form, state: v })} />
          </div>

          <details className="mt-3 rounded-xl border border-ink-200 bg-ink-50 p-3">
            <summary className="cursor-pointer text-sm font-medium text-ink-700">
              Map position (used to estimate delivery distance)
            </summary>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field id="latitude" label="Latitude" value={String(form.latitude)} onChange={(v) => setForm({ ...form, latitude: Number(v) })} />
              <Field id="longitude" label="Longitude" value={String(form.longitude)} onChange={(v) => setForm({ ...form, longitude: Number(v) })} />
            </div>
          </details>

          <label className="mt-4 flex items-center gap-2 text-sm font-medium text-ink-700">
            <input
              type="checkbox"
              checked={form.isDefault}
              onChange={(e) => setForm({ ...form, isDefault: e.target.checked })}
              className="h-4 w-4 rounded"
            />
            Make this my default delivery address
          </label>

          <div className="mt-5 flex gap-2">
            <button type="submit" disabled={pending} className="btn-primary">
              {pending ? "Saving…" : editing ? "Save changes" : "Add address"}
            </button>
            <button
              type="button"
              onClick={() => { setAdding(false); setEditing(null); }}
              className="btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

function Field({
  id, label, value, onChange, error, inputMode, maxLength,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  inputMode?: "text" | "numeric";
  maxLength?: number;
}) {
  return (
    <div>
      <label htmlFor={id} className="label">{label}</label>
      <input
        id={id}
        name={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        inputMode={inputMode}
        maxLength={maxLength}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-err` : undefined}
        className="input"
      />
      {error ? <p id={`${id}-err`} className="error-text">{error}</p> : null}
    </div>
  );
}
