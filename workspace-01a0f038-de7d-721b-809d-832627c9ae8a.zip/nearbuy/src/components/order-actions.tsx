"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

/** Customer-initiated cancellation. The server decides whether it is allowed. */
export function CancelOrderButton({ orderId }: { orderId: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function cancel() {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/orders/${orderId}/status`, { status: "CANCELLED" });
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    setOpen(false);
    router.refresh();
  }

  return (
    <div>
      {!open ? (
        <button type="button" onClick={() => setOpen(true)} className="btn-secondary btn-sm">
          Cancel order
        </button>
      ) : (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3.5">
          <p className="text-sm font-semibold text-red-900">Cancel this order?</p>
          <p className="mt-1 text-[13px] text-red-800">
            The store is notified and the items go back into stock. This cannot be undone.
          </p>
          {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
          <div className="mt-3 flex gap-2">
            <button type="button" onClick={cancel} disabled={pending} className="btn-danger btn-sm">
              {pending ? "Cancelling…" : "Yes, cancel it"}
            </button>
            <button type="button" onClick={() => setOpen(false)} className="btn-secondary btn-sm">
              Keep order
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
