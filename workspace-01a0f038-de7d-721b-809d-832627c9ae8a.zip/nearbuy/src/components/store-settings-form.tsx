"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, type ApiErrorShape } from "@/lib/client";
import { Alert } from "./ui";

const DAYS = [
  ["MON", "Mon"], ["TUE", "Tue"], ["WED", "Wed"], ["THU", "Thu"],
  ["FRI", "Fri"], ["SAT", "Sat"], ["SUN", "Sun"],
] as const;

export interface StoreDraft {
  id?: string;
  name: string;
  description: string;
  category: string;
  addressLine1: string;
  city: string;
  state: string;
  pincode: string;
  latitude: number;
  longitude: number;
  phone: string;
  openingTime: string;
  closingTime: string;
  operatingDays: string[];
  supportsDelivery: boolean;
  supportsPickup: boolean;
  deliveryEtaMinutes: number;
  isOpen: boolean;
  status: string;
  imageUrl?: string | null;
}

const BLANK: StoreDraft = {
  name: "", description: "", category: "Grocery",
  addressLine1: "", city: "New Delhi", state: "Delhi", pincode: "",
  latitude: 28.5921, longitude: 77.046, phone: "",
  openingTime: "08:00", closingTime: "21:00",
  operatingDays: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
  supportsDelivery: true, supportsPickup: true, deliveryEtaMinutes: 35,
  isOpen: true, status: "DRAFT",
};

export function StoreSettingsForm({ store, categories }: { store: StoreDraft | null; categories: string[] }) {
  const router = useRouter();
  const [form, setForm] = useState<StoreDraft>(store ?? BLANK);
  const [image, setImage] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(store?.imageUrl ?? null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<ApiErrorShape | null>(null);
  const [saved, setSaved] = useState(false);

  const fieldErrors = error?.details ?? {};
  const set = <K extends keyof StoreDraft>(k: K, v: StoreDraft[K]) => {
    setForm((f) => ({ ...f, [k]: v }));
    setSaved(false);
  };

  function toggleDay(day: string) {
    set("operatingDays", form.operatingDays.includes(day)
      ? form.operatingDays.filter((d) => d !== day)
      : [...form.operatingDays, day]);
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    setError(null);

    // The image is uploaded first so the store row can reference its URL.
    let finalImageUrl = imageUrl;
    if (image) {
      const body = new FormData();
      body.set("file", image);
      body.set("kind", "store");
      const up = await fetch("/api/seller/upload", { method: "POST", body }).then((r) => r.json());
      if (up?.data?.url) {
        finalImageUrl = up.data.url;
      } else {
        setPending(false);
        setError({ code: "UPLOAD", message: up?.error?.message ?? "We couldn't upload that image." });
        return;
      }
    }

    const res = form.id
      ? await api.put("/api/stores/mine", { ...form, imageUrl: finalImageUrl })
      : await api.post("/api/stores/mine", { ...form, imageUrl: finalImageUrl });

    setPending(false);
    if (!res.ok) {
      setError(res.error);
      return;
    }
    setSaved(true);
    router.refresh();
  }

  return (
    <form onSubmit={save} className="grid gap-5 lg:grid-cols-[1fr_320px] lg:items-start" noValidate>
      <div className="space-y-5">
        {error ? <Alert tone={error.details ? "error" : "error"} role="alert">{error.message}</Alert> : null}
        {saved ? <Alert tone="success" role="status">Store saved.</Alert> : null}

        <section className="card p-5">
          <h2 className="font-bold">Store details</h2>
          <div className="mt-4 space-y-3">
            <div>
              <label htmlFor="s-name" className="label">Store name</label>
              <input id="s-name" value={form.name} onChange={(e) => set("name", e.target.value)} className="input" required />
              {fieldErrors.name ? <p className="error-text">{fieldErrors.name}</p> : null}
            </div>

            <div>
              <label htmlFor="s-desc" className="label">Description</label>
              <textarea id="s-desc" rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} className="input" required />
              {fieldErrors.description ? <p className="error-text">{fieldErrors.description}</p> : null}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="s-cat" className="label">Category</label>
                <select id="s-cat" value={form.category} onChange={(e) => set("category", e.target.value)} className="input">
                  {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label htmlFor="s-phone" className="label">Contact number</label>
                <input id="s-phone" value={form.phone} onChange={(e) => set("phone", e.target.value)} className="input" required />
                {fieldErrors.phone ? <p className="error-text">{fieldErrors.phone}</p> : null}
              </div>
            </div>

            <div>
              <label htmlFor="s-img" className="label">Store photo</label>
              <input id="s-img" type="file" accept="image/*" onChange={(e) => setImage(e.target.files?.[0] ?? null)} className="input py-1.5" />
              {imageUrl ? <p className="hint">Current: {imageUrl}</p> : null}
            </div>
          </div>
        </section>

        <section className="card p-5">
          <h2 className="font-bold">Location</h2>
          <div className="mt-4 space-y-3">
            <div>
              <label htmlFor="s-addr" className="label">Street address</label>
              <input id="s-addr" value={form.addressLine1} onChange={(e) => set("addressLine1", e.target.value)} className="input" required />
              {fieldErrors.addressLine1 ? <p className="error-text">{fieldErrors.addressLine1}</p> : null}
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <div>
                <label htmlFor="s-city" className="label">City</label>
                <input id="s-city" value={form.city} onChange={(e) => set("city", e.target.value)} className="input" required />
              </div>
              <div>
                <label htmlFor="s-state" className="label">State</label>
                <input id="s-state" value={form.state} onChange={(e) => set("state", e.target.value)} className="input" required />
              </div>
              <div>
                <label htmlFor="s-pin" className="label">PIN code</label>
                <input id="s-pin" inputMode="numeric" maxLength={6} value={form.pincode} onChange={(e) => set("pincode", e.target.value)} className="input" required />
                {fieldErrors.pincode ? <p className="error-text">{fieldErrors.pincode}</p> : null}
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="s-lat" className="label">Latitude</label>
                <input id="s-lat" type="number" step="any" value={form.latitude} onChange={(e) => set("latitude", Number(e.target.value))} className="input" required />
                {fieldErrors.latitude ? <p className="error-text">{fieldErrors.latitude}</p> : null}
              </div>
              <div>
                <label htmlFor="s-lng" className="label">Longitude</label>
                <input id="s-lng" type="number" step="any" value={form.longitude} onChange={(e) => set("longitude", Number(e.target.value))} className="input" required />
                {fieldErrors.longitude ? <p className="error-text">{fieldErrors.longitude}</p> : null}
              </div>
            </div>
            <p className="hint">Used to estimate delivery distance and fees. Never shown as an exact customer address.</p>
          </div>
        </section>

        <section className="card p-5">
          <h2 className="font-bold">Opening hours</h2>
          <div className="mt-4 space-y-3">
            <fieldset>
              <legend className="label">Operating days</legend>
              <div className="flex flex-wrap gap-2">
                {DAYS.map(([code, label]) => (
                  <label
                    key={code}
                    className={`flex cursor-pointer items-center gap-1.5 rounded-lg border px-3 py-2 text-sm font-medium ${
                      form.operatingDays.includes(code) ? "border-brand-500 bg-brand-50 text-brand-800" : "border-ink-300 text-ink-600"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={form.operatingDays.includes(code)}
                      onChange={() => toggleDay(code)}
                      className="h-3.5 w-3.5 rounded"
                    />
                    {label}
                  </label>
                ))}
              </div>
            </fieldset>

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="s-open" className="label">Opens at</label>
                <input id="s-open" type="time" value={form.openingTime} onChange={(e) => set("openingTime", e.target.value)} className="input" required />
              </div>
              <div>
                <label htmlFor="s-close" className="label">Closes at</label>
                <input id="s-close" type="time" value={form.closingTime} onChange={(e) => set("closingTime", e.target.value)} className="input" required />
                {fieldErrors.closingTime ? <p className="error-text">{fieldErrors.closingTime}</p> : null}
              </div>
            </div>
          </div>
        </section>
      </div>

      <aside className="card sticky top-20 space-y-4 p-5">
        <h2 className="font-bold">Visibility &amp; fulfilment</h2>

        <div>
          <label htmlFor="s-status" className="label">Publication</label>
          <select id="s-status" value={form.status} onChange={(e) => set("status", e.target.value)} className="input">
            <option value="DRAFT">Draft — hidden from customers</option>
            <option value="PUBLISHED">Published — discoverable in search</option>
            <option value="SUSPENDED">Suspended</option>
          </select>
          <p className="hint">Only published stores appear in customer search.</p>
        </div>

        <label className="flex items-center gap-2 text-sm font-medium text-ink-700">
          <input type="checkbox" checked={form.isOpen} onChange={(e) => set("isOpen", e.target.checked)} className="h-4 w-4 rounded" />
          Open for orders right now
        </label>

        <div className="space-y-2 border-t border-ink-200 pt-4">
          <label className="flex items-center gap-2 text-sm font-medium text-ink-700">
            <input type="checkbox" checked={form.supportsDelivery} onChange={(e) => set("supportsDelivery", e.target.checked)} className="h-4 w-4 rounded" />
            Offer delivery
          </label>
          <label className="flex items-center gap-2 text-sm font-medium text-ink-700">
            <input type="checkbox" checked={form.supportsPickup} onChange={(e) => set("supportsPickup", e.target.checked)} className="h-4 w-4 rounded" />
            Offer pickup
          </label>
          {fieldErrors.supportsDelivery ? <p className="error-text">{fieldErrors.supportsDelivery}</p> : null}
        </div>

        <div>
          <label htmlFor="s-eta" className="label">Typical delivery time (minutes)</label>
          <input id="s-eta" type="number" min={10} max={240} value={form.deliveryEtaMinutes} onChange={(e) => set("deliveryEtaMinutes", Number(e.target.value))} className="input" />
        </div>

        <button type="submit" disabled={pending} className="btn-primary-lg w-full">
          {pending ? "Saving…" : form.id ? "Save store" : "Create store"}
        </button>
        <p className="text-[13px] text-ink-500">
          Changes take effect immediately for customers.
        </p>
      </aside>
    </form>
  );
}
