"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";

export function CancelReservationButton({ reservationId }: { reservationId: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  async function cancel() {
    setPending(true);
    setError(null);
    const res = await api.del(`/api/reservations/${reservationId}`);
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    setDone(true);
    router.refresh();
  }

  if (done) return <p className="text-sm font-medium text-brand-700">Reservation cancelled.</p>;

  return (
    <div>
      <button type="button" onClick={cancel} disabled={pending} className="btn-secondary btn-sm">
        {pending ? "Cancelling…" : "Cancel reservation"}
      </button>
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}
