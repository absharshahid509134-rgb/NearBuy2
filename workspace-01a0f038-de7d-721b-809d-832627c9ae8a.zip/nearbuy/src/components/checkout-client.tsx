"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { api } from "@/lib/client";
import { formatINR } from "@/lib/money";
import { Alert } from "./ui";
import type { CheckoutPreview } from "@/lib/checkout-types";

/**
 * Checkout.
 *
 * The idempotency key is generated once, on mount, and reused for every
 * submission attempt. If the request times out and the customer presses
 * "Pay" again, the server recognises the key and returns the original order
 * instead of creating a second one. The button is also disabled while a
 * request is in flight, so a double-click cannot race.
 *
 * Every figure below is a server-computed preview. The server recomputes all
 * of it authoritatively at submit time — this is display, not authority.
 */
export function CheckoutClient({ preview }: { preview: CheckoutPreview }) {
  const router = useRouter();
  const idempotencyKey = useRef(crypto.randomUUID());
  const [fulfillment, setFulfillment] = useState<"DELIVERY" | "PICKUP">(
    preview.fulfillmentAvailable.DELIVERY ? "DELIVERY" : "PICKUP",
  );
  const [addressId, setAddressId] = useState<string>(
    preview.addresses.find((a) => a.isDefault)?.id ?? preview.addresses[0]?.id ?? "",
  );
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canDeliver = preview.fulfillmentAvailable.DELIVERY;
  const canPickup = preview.fulfillmentAvailable.PICKUP;
  const needsAddress = fulfillment === "DELIVERY";
  const blocked =
    preview.hasBlockingIssues ||
    !fulfillment ||
    (needsAddress && !addressId) ||
    (!canDeliver && !canPickup);

  async function placeOrder() {
    setPending(true);
    setError(null);
    const res = await api.post<{ orders: Array<{ id: string }>; idempotentReplay: boolean }>(
      "/api/checkout",
      {
        fulfillmentType: fulfillment,
        addressId: needsAddress ? addressId : null,
        idempotencyKey: idempotencyKey.current,
      },
    );
    setPending(false);

    if (!res.ok) {
      setError(res.error.message);
      // A rejected checkout leaves stock untouched; refresh so the cart shows
      // the server's current view rather than a stale local guess.
      router.refresh();
      return;
    }
    router.push(`/customer/orders?placed=${res.data.orders[0]?.id ?? ""}`);
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_340px] lg:items-start">
      <div className="space-y-4">
        {error ? <Alert tone="error" role="alert">{error}</Alert> : null}

        {preview.hasBlockingIssues ? (
          <Alert tone="warning" role="alert">
            Your cart has an issue: {preview.issues[0]}.{" "}
            <Link href="/customer/cart" className="font-semibold underline">Fix your cart</Link>
          </Alert>
        ) : null}

        {/* ------------------------------------------------- fulfilment */}
        <section className="card p-5">
          <h2 className="font-bold">How would you like to get it?</h2>
          <p className="mt-1 text-sm text-ink-600">
            We only show options every store in your cart supports.
          </p>

          <div className="mt-4 grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label="Fulfilment method">
            {([
              { key: "DELIVERY", label: "Delivery", desc: "A rider brings it to your address", ok: canDeliver },
              { key: "PICKUP", label: "Pickup", desc: "Collect it from the store yourself", ok: canPickup },
            ] as const).map((opt) => (
              <label
                key={opt.key}
                className={`flex cursor-pointer items-start gap-3 rounded-xl border-2 p-4 transition-colors ${
                  fulfillment === opt.key
                    ? "border-brand-500 bg-brand-50"
                    : "border-ink-200 hover:border-ink-300"
                } ${opt.ok ? "" : "cursor-not-allowed opacity-50"}`}
              >
                <input
                  type="radio"
                  name="fulfillment"
                  value={opt.key}
                  checked={fulfillment === opt.key}
                  disabled={!opt.ok}
                  onChange={() => setFulfillment(opt.key)}
                  className="mt-0.5 h-4 w-4 accent-brand-600"
                />
                <span>
                  <span className="block font-semibold">{opt.label}</span>
                  <span className="mt-0.5 block text-[13px] text-ink-600">
                    {opt.ok ? opt.desc : "Not available for every store in your cart"}
                  </span>
                </span>
              </label>
            ))}
          </div>
        </section>

        {/* --------------------------------------------------- addresses */}
        {needsAddress ? (
          <section className="card p-5">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-bold">Deliver to</h2>
              <Link href="/customer/addresses" className="text-sm font-semibold text-brand-700 hover:underline">
                Manage addresses
              </Link>
            </div>

            {preview.addresses.length === 0 ? (
              <Alert tone="warning">
                You need a delivery address.{" "}
                <Link href="/customer/addresses" className="font-semibold underline">Add one</Link>
              </Alert>
            ) : (
              <div className="mt-4 space-y-2.5" role="radiogroup" aria-label="Delivery address">
                {preview.addresses.map((a) => (
                  <label
                    key={a.id}
                    className={`flex cursor-pointer items-start gap-3 rounded-xl border-2 p-4 ${
                      addressId === a.id ? "border-brand-500 bg-brand-50" : "border-ink-200 hover:border-ink-300"
                    }`}
                  >
                    <input
                      type="radio"
                      name="address"
                      checked={addressId === a.id}
                      onChange={() => setAddressId(a.id)}
                      className="mt-0.5 h-4 w-4 accent-brand-600"
                    />
                    <span className="min-w-0 text-sm">
                      <span className="block font-semibold">
                        {a.label}
                        {a.isDefault ? (
                          <span className="ml-2 rounded-full bg-brand-100 px-2 py-0.5 text-[11px] font-semibold text-brand-800">
                            Default
                          </span>
                        ) : null}
                      </span>
                      <span className="mt-0.5 block text-ink-600">
                        {a.fullName} · {a.phone}
                      </span>
                      <span className="mt-0.5 block text-ink-600">
                        {a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city} {a.pincode}
                      </span>
                    </span>
                  </label>
                ))}
              </div>
            )}
          </section>
        ) : null}

        {/* ------------------------------------------------ store orders */}
        <section className="card overflow-hidden">
          <h2 className="border-b border-ink-200 px-5 py-4 font-bold">
            {preview.groups.length} order{preview.groups.length === 1 ? "" : "s"} at checkout
          </h2>
          <p className="px-5 pt-3 text-[13px] text-ink-600">
            Each store runs its own order, with its own delivery fee and its own preparation status.
          </p>

          <ul className="divide-y divide-ink-100">
            {preview.groups.map((g) => (
              <li key={g.storeId} className="px-5 py-4">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <Link href={`/stores/${g.storeSlug}`} className="font-semibold hover:text-brand-700 hover:underline">
                    {g.storeName}
                  </Link>
                  <p className="text-sm font-semibold tabular-nums">
                    {formatINR(g.subtotalPaise)} + {formatINR(g.deliveryFeePaise)} delivery
                  </p>
                </div>
                <ul className="mt-2 space-y-1 text-sm text-ink-600">
                  {g.items.map((i) => (
                    <li key={i.id} className="flex justify-between gap-3">
                      <span className="min-w-0 truncate">{i.name} × {i.quantity}</span>
                      <span className="shrink-0 tabular-nums">{formatINR(i.lineTotalPaise)}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 border-t border-ink-100 pt-2 text-right text-sm font-bold">
                  Store total {formatINR(g.subtotalPaise + g.deliveryFeePaise)}
                </p>
              </li>
            ))}
          </ul>
        </section>
      </div>

      {/* -------------------------------------------------- summary rail */}
      <aside className="card sticky top-20 p-5">
        <h2 className="font-bold">Payment</h2>

        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3.5">
          <p className="text-sm font-semibold text-amber-900">Cash on delivery</p>
          <p className="mt-1 text-[13px] text-amber-800">
            No online payment gateway is connected to this deployment. Pay the rider in cash when
            your order arrives. We never mark a payment as completed until a real confirmation.
          </p>
        </div>

        <dl className="mt-4 space-y-2.5 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-600">Subtotal</dt>
            <dd className="font-semibold tabular-nums">{formatINR(preview.subtotalPaise)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600">Delivery ({preview.groups.length})</dt>
            <dd className="font-semibold tabular-nums">{formatINR(preview.deliveryFeePaise)}</dd>
          </div>
          <div className="flex justify-between border-t border-ink-200 pt-2.5 text-base">
            <dt className="font-bold">Total</dt>
            <dd className="font-bold tabular-nums">{formatINR(preview.grandTotalPaise)}</dd>
          </div>
        </dl>

        <button
          type="button"
          onClick={placeOrder}
          disabled={pending || blocked}
          className="btn-primary-lg mt-5 w-full"
        >
          {pending ? "Placing your order…" : `Place order · ${formatINR(preview.grandTotalPaise)}`}
        </button>

        {blocked && !preview.hasBlockingIssues ? (
          <p className="mt-2 text-[13px] text-ink-500">
            {needsAddress && !addressId ? "Choose a delivery address to continue." : "Choose a fulfilment option."}
          </p>
        ) : null}

        <Link href="/customer/cart" className="btn-ghost mt-1 w-full">Back to cart</Link>
      </aside>
    </div>
  );
}
