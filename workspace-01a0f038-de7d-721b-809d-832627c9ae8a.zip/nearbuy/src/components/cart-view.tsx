"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { api } from "@/lib/client";
import { formatINR } from "@/lib/money";
import { Alert, Thumb } from "./ui";
import type { CartView } from "@/lib/cart-types";

/**
 * The cart is rendered entirely from server data. Quantity buttons re-fetch
 * from the server rather than optimistically editing a local copy, so what the
 * shopper sees is always what the server believes about stock and price.
 */
export function CartViewClient({ cart }: { cart: CartView }) {
  const router = useRouter();
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  async function change(itemId: string, quantity: number) {
    setPendingId(itemId);
    setError(null);
    const res = await api.patch<CartView>("/api/cart/items", { quantity });
    setPendingId(null);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    startTransition(() => router.refresh());
  }

  async function remove(itemId: string) {
    setPendingId(itemId);
    setError(null);
    const res = await api.del<CartView>(`/api/cart/items/${itemId}`);
    setPendingId(null);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    startTransition(() => router.refresh());
  }

  if (cart.groups.length === 0) {
    return (
      <div className="card px-6 py-16 text-center">
        <span aria-hidden className="text-4xl">🛒</span>
        <h2 className="mt-3 text-lg font-semibold">Your cart is empty</h2>
        <p className="mx-auto mt-1.5 max-w-sm text-ink-600">
          Browse the stores around you and add the things you need.
        </p>
        <Link href="/stores" className="btn-primary mt-5">Browse stores</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_320px] lg:items-start">
      <div className="space-y-4">
        {error ? <Alert tone="error" role="alert">{error}</Alert> : null}
        {cart.hasBlockingIssues ? (
          <Alert tone="warning" role="alert">
            Some items need attention before you can check out.{" "}
            {cart.issues[0]}
          </Alert>
        ) : null}

        {cart.groups.map((g) => (
          <section key={g.store.id} className="card overflow-hidden">
            <header className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-200 bg-ink-50 px-4 py-3">
              <div className="min-w-0">
                <Link href={`/stores/${g.store.slug}`} className="font-semibold hover:text-brand-700 hover:underline">
                  {g.store.name}
                </Link>
                <p className="text-[13px] text-ink-500">
                  {g.items.length} item{g.items.length === 1 ? "" : "s"} · Separate order at checkout
                </p>
              </div>
              <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${
                g.store.isOpen ? "bg-brand-50 text-brand-700 ring-brand-200" : "bg-ink-100 text-ink-600 ring-ink-200"
              }`}>
                {g.store.isOpen ? "Open" : "Closed"}
              </span>
            </header>

            <ul className="divide-y divide-ink-100">
              {g.items.map((item) => (
                <li key={item.id} className="flex gap-3 p-4">
                  <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-ink-100">
                    <Thumb src={item.imageUrl} alt={item.name} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="font-semibold leading-snug">{item.name}</p>
                    <p className="mt-0.5 text-[13px] text-ink-500">
                      {formatINR(item.pricePaise)} · {item.unit}
                    </p>

                    {item.note ? (
                      <p className="mt-1 text-[13px] font-medium text-amber-700">{item.note}</p>
                    ) : null}

                    <div className="mt-2.5 flex flex-wrap items-center gap-2">
                      <div className="flex items-center rounded-lg border border-ink-300">
                        <button
                          type="button"
                          onClick={() => change(item.id, item.quantity - 1)}
                          disabled={pendingId === item.id}
                          aria-label={`Decrease quantity of ${item.name}`}
                          className="grid h-9 w-9 place-items-center hover:bg-ink-100 disabled:opacity-40"
                        >
                          −
                        </button>
                        <span className="w-9 text-center text-sm font-semibold tabular-nums" aria-live="polite">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => change(item.id, item.quantity + 1)}
                          disabled={pendingId === item.id || item.quantity >= item.availableStock}
                          aria-label={`Increase quantity of ${item.name}`}
                          className="grid h-9 w-9 place-items-center hover:bg-ink-100 disabled:opacity-40"
                        >
                          +
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => remove(item.id)}
                        disabled={pendingId === item.id}
                        className="text-[13px] font-medium text-ink-500 underline underline-offset-2 hover:text-red-600"
                      >
                        Remove
                      </button>
                    </div>
                  </div>

                  <p className="shrink-0 text-right font-bold tabular-nums">
                    {formatINR(item.lineTotalPaise)}
                  </p>
                </li>
              ))}
            </ul>

            <footer className="flex items-center justify-between border-t border-ink-200 bg-ink-50 px-4 py-3 text-sm">
              <span className="font-medium text-ink-600">Store subtotal</span>
              <span className="font-bold tabular-nums">{formatINR(g.subtotalPaise)}</span>
            </footer>
          </section>
        ))}
      </div>

      {/* ------------------------------------------------------- summary */}
      <aside className="card sticky top-20 p-5">
        <h2 className="font-bold">Order summary</h2>

        <dl className="mt-4 space-y-2.5 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-600">Subtotal</dt>
            <dd className="font-semibold tabular-nums">{formatINR(cart.subtotalPaise)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600">Delivery</dt>
            <dd className="text-[13px] text-ink-500">Calculated at checkout</dd>
          </div>
          <div className="flex justify-between border-t border-ink-200 pt-2.5 text-base">
            <dt className="font-bold">Estimated total</dt>
            <dd className="font-bold tabular-nums">{formatINR(cart.subtotalPaise)}+</dd>
          </div>
        </dl>

        <p className="mt-3 text-[13px] text-ink-500">
          {cart.storeCount > 1
            ? `Your cart spans ${cart.storeCount} stores. Each store becomes its own order with its own delivery fee.`
            : "One store — your order will be a single order."}
        </p>

        {cart.hasBlockingIssues ? (
          <button type="button" disabled className="btn-primary-lg mt-4 w-full">
            Fix items to continue
          </button>
        ) : (
          <Link href="/customer/checkout" className="btn-primary-lg mt-4 w-full">
            Go to checkout
          </Link>
        )}

        <Link href="/stores" className="btn-ghost mt-2 w-full">Continue shopping</Link>
      </aside>
    </div>
  );
}
