"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api } from "@/lib/client";
import { Alert } from "./ui";
import { formatINR } from "@/lib/money";

/**
 * The rider's operational surface.
 *
 * Two code gates, both verified server-side:
 *   - pickup   — the SELLER's code, entered at the store;
 *   - delivery — the CUSTOMER's code, entered at the door.
 * A rider never receives either code; they can only submit one and be told
 * yes or no. Under contention, `claimJob` returns a 409 with a message
 * written for another human, and we show it verbatim.
 */
export function ClaimButton({ jobId, disabled = false }: { jobId: string; disabled?: boolean }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function claim() {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/rider/jobs/${jobId}/claim`);
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      // Someone else won the job — refresh so the pool reflects reality.
      router.refresh();
      return;
    }
    router.refresh();
  }

  return (
    <div>
      <button type="button" onClick={claim} disabled={pending || disabled} className="btn-primary w-full">
        {pending ? "Claiming…" : "Claim job"}
      </button>
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}

export function ReleaseButton({ jobId }: { jobId: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function release() {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/rider/jobs/${jobId}/release`);
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div>
      <button type="button" onClick={release} disabled={pending} className="btn-secondary w-full">
        {pending ? "Releasing…" : "Release job"}
      </button>
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}

/** Six single-character inputs, with paste support and a strict numeric filter. */
function CodeInput({
  id,
  onComplete,
}: {
  id: string;
  onComplete: (code: string) => void;
}) {
  const [digits, setDigits] = useState<string[]>(Array(6).fill(""));

  function setDigit(index: number, value: string) {
    const cleaned = value.replace(/\D/g, "").slice(-1);
    setDigits((d) => {
      const next = [...d];
      next[index] = cleaned;
      return next;
    });
    if (cleaned && index < 5) {
      document.getElementById(`${id}-${index + 1}`)?.focus();
    }
    const joined = digits.map((d, i) => (i === index ? cleaned : d)).join("");
    if (joined.length === 6 && !joined.includes("")) onComplete(joined);
  }

  function onPaste(e: React.ClipboardEvent) {
    e.preventDefault();
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    if (!text) return;
    const next = Array(6).fill("");
    for (let i = 0; i < text.length; i++) next[i] = text[i];
    setDigits(next);
    document.getElementById(`${id}-${Math.min(5, text.length)}`)?.focus();
    if (text.length === 6) onComplete(text);
  }

  return (
    <div className="flex gap-1.5" onPaste={onPaste}>
      {digits.map((d, i) => (
        <input
          key={i}
          id={`${id}-${i}`}
          value={d}
          onChange={(e) => setDigit(i, e.target.value)}
          // Backspace steps back instead of trapping focus on an empty box.
          onKeyDown={(e) => {
            if (e.key === "Backspace" && !digits[i] && i > 0) {
              document.getElementById(`${id}-${i - 1}`)?.focus();
            }
          }}
          inputMode="numeric"
          autoComplete={i === 0 ? "one-time-code" : "off"}
          maxLength={1}
          aria-label={`Digit ${i + 1} of 6`}
          className="input h-12 w-full p-0 text-center font-mono text-lg font-bold"
        />
      ))}
    </div>
  );
}

export function VerifyPickupForm({ jobId, storeName }: { jobId: string; storeName: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(code: string) {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/rider/jobs/${jobId}/pickup`, { code });
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div className="rounded-xl border border-brand-200 bg-brand-50 p-4">
      <h3 className="font-bold text-brand-900">Verify pickup</h3>
      <p className="mt-1 text-[13px] text-brand-800">
        Ask {storeName} for the 6-digit pickup handoff code, then enter it below.
      </p>
      <div className="mt-3">
        <CodeInput id="pickup" onComplete={submit} />
      </div>
      {pending ? <p className="mt-2 text-[13px] text-brand-800" role="status">Checking the code…</p> : null}
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}

export function VerifyDeliveryForm({ jobId }: { jobId: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(code: string) {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/rider/jobs/${jobId}/complete`, { code });
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div className="rounded-xl border border-blue-200 bg-blue-50 p-4">
      <h3 className="font-bold text-blue-900">Verify delivery</h3>
      <p className="mt-1 text-[13px] text-blue-800">
        Ask the customer for the 6-digit delivery code on their order, then enter it here.
      </p>
      <div className="mt-3">
        <CodeInput id="delivery" onComplete={submit} />
      </div>
      {pending ? <p className="mt-2 text-[13px] text-blue-800" role="status">Checking the code…</p> : null}
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}

export function StartDeliveryButton({ jobId }: { jobId: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function start() {
    setPending(true);
    setError(null);
    const res = await api.post(`/api/rider/jobs/${jobId}/delivery`);
    setPending(false);
    if (!res.ok) {
      setError(res.error.message);
      return;
    }
    router.refresh();
  }

  return (
    <div>
      <button type="button" onClick={start} disabled={pending} className="btn-primary w-full">
        {pending ? "Starting…" : "Start delivery"}
      </button>
      {error ? <div className="mt-2"><Alert tone="error" role="alert">{error}</Alert></div> : null}
    </div>
  );
}

/** Compact available-job card used on the rider dashboard and jobs list. */
export function AvailableJobCard({ job }: { job: AvailableJob }) {
  return (
    <li className="card p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold">Pick up from {job.storeName}</p>
          <p className="mt-0.5 text-[13px] text-ink-600">{job.storeAddress}</p>
        </div>
        <p className="shrink-0 text-lg font-bold tabular-nums text-brand-700">
          {formatINR(job.earningsPaise)}
        </p>
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-2 text-[13px]">
        <div>
          <dt className="text-ink-500">Order</dt>
          <dd className="font-medium">{job.orderNumber}</dd>
        </div>
        <div>
          <dt className="text-ink-500">Items</dt>
          <dd className="font-medium">{job.itemCount}</dd>
        </div>
        <div>
          <dt className="text-ink-500">Deliver to</dt>
          <dd className="font-medium">{job.dropArea}</dd>
        </div>
        <div>
          <dt className="text-ink-500">PIN code</dt>
          <dd className="font-medium tabular-nums">{job.dropPincode}</dd>
        </div>
      </dl>

      <p className="mt-2 text-[13px] text-ink-500">
        The customer&apos;s full address and phone unlock after you claim the job.
      </p>

      <div className="mt-3">
        <ClaimButton jobId={job.id} />
      </div>
    </li>
  );
}

export interface AvailableJob {
  id: string;
  orderId: string;
  orderNumber: string;
  status: string;
  earningsPaise: number;
  itemCount: number;
  storeName: string;
  storeAddress: string;
  dropArea: string;
  dropPincode: string;
  placedAt: string;
}

export function ActiveJobCard({ job }: { job: ActiveJobData }) {
  const stage = job.status as "ASSIGNED" | "PICKED_UP" | "OUT_FOR_DELIVERY";
  return (
    <li className="card overflow-hidden">
      <header className="border-b border-ink-200 bg-ink-50 px-4 py-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="font-semibold">
            {stage === "ASSIGNED" && "Collect from the store"}
            {stage === "PICKED_UP" && "Start your delivery"}
            {stage === "OUT_FOR_DELIVERY" && "Complete the delivery"}
          </p>
          <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
            {formatINR(job.earningsPaise)}
          </span>
        </div>
        <p className="text-[13px] text-ink-600">{job.order.orderNumber}</p>
      </header>

      <div className="grid gap-4 p-4 sm:grid-cols-2">
        <div>
          <h3 className="text-[13px] font-bold uppercase tracking-wide text-ink-500">Pickup</h3>
          <p className="mt-1 font-semibold">{job.order.store.name}</p>
          <p className="text-sm text-ink-600">{job.order.store.addressLine1}, {job.order.store.city}</p>
          <p className="text-sm text-ink-600 tabular-nums">{job.order.store.phone}</p>
        </div>
        <div>
          <h3 className="text-[13px] font-bold uppercase tracking-wide text-ink-500">Drop off</h3>
          <p className="mt-1 font-semibold">{job.order.shipFullName}</p>
          <p className="text-sm text-ink-600">
            {job.order.shipLine1}{job.order.shipLine2 ? `, ${job.order.shipLine2}` : ""}
          </p>
          {job.order.shipLandmark ? <p className="text-sm text-ink-500">Near {job.order.shipLandmark}</p> : null}
          <p className="text-sm text-ink-600">
            {job.order.shipCity}, {job.order.shipState} {job.order.shipPincode}
          </p>
          <p className="text-sm text-ink-600 tabular-nums">{job.order.shipPhone}</p>
        </div>
      </div>

      <div className="border-t border-ink-200 px-4 py-3">
        <p className="text-[13px] font-bold uppercase tracking-wide text-ink-500">
          {job.order.items.length} item{job.order.items.length === 1 ? "" : "s"}
        </p>
        <ul className="mt-1.5 space-y-0.5 text-sm text-ink-600">
          {job.order.items.map((i) => (
            <li key={i.id}>{i.nameSnapshot} × {i.quantity}</li>
          ))}
        </ul>
      </div>

      <div className="space-y-3 border-t border-ink-200 bg-ink-50 p-4">
        {stage === "ASSIGNED" ? (
          <>
            <VerifyPickupForm jobId={job.id} storeName={job.order.store.name} />
            <ReleaseButton jobId={job.id} />
          </>
        ) : null}
        {stage === "PICKED_UP" ? <StartDeliveryButton jobId={job.id} /> : null}
        {stage === "OUT_FOR_DELIVERY" ? <VerifyDeliveryForm jobId={job.id} /> : null}
        <Link href={`/rider/jobs/${job.orderId}`} className="btn-ghost w-full">
          View full order
        </Link>
      </div>
    </li>
  );
}

export interface ActiveJobData {
  id: string;
  orderId: string;
  status: string;
  earningsPaise: number;
  order: {
    orderNumber: string;
    shipFullName: string;
    shipPhone: string;
    shipLine1: string;
    shipLine2: string | null;
    shipLandmark: string | null;
    shipCity: string;
    shipState: string;
    shipPincode: string;
    items: Array<{ id: string; nameSnapshot: string; quantity: number }>;
    store: { name: string; addressLine1: string; city: string; phone: string };
  };
}
