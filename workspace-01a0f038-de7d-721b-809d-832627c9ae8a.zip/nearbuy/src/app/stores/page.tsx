import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, Thumb } from "@/components/ui";
import { searchStores, CATEGORIES } from "@/server/services/discovery";
import { storeSearchSchema } from "@/lib/validation";

export const metadata: Metadata = { title: "Browse stores" };
export const dynamic = "force-dynamic";

export default async function StoresPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const one = (k: string) => (Array.isArray(sp[k]) ? sp[k][0] : sp[k]);

  const input = storeSearchSchema.parse({
    q: one("q") ?? "",
    category: one("category"),
    open: one("open"),
    sort: one("sort") ?? "newest",
    page: one("page") ?? "1",
  });

  const result = await searchStores(input);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Stores near you</h1>
        <p className="mt-1.5 text-ink-600">
          {result.total} published {result.total === 1 ? "store" : "stores"} accepting orders right now.
        </p>

        <form method="get" className="card mt-6 flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
          <div className="flex-1">
            <label htmlFor="q" className="label">Search stores</label>
            <input
              id="q" name="q" type="search" defaultValue={input.q}
              placeholder="Try &quot;pharmacy&quot; or &quot;stationery&quot;" className="input"
            />
          </div>
          <div className="sm:w-52">
            <label htmlFor="category" className="label">Category</label>
            <select id="category" name="category" defaultValue={input.category ?? ""} className="input">
              <option value="">All categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-2">
            <label className="flex items-center gap-2 text-sm font-medium text-ink-700">
              <input type="checkbox" name="open" value="true" defaultChecked={input.open === true} className="h-4 w-4 rounded" />
              Open now
            </label>
            <button type="submit" className="btn-primary">Apply</button>
          </div>
        </form>

        {result.items.length === 0 ? (
          <div className="mt-6">
            <EmptyState
              title="No nearby stores found"
              description="Try a different category, or clear the search to see everything published."
              action={<Link href="/stores" className="btn-secondary">Clear filters</Link>}
            />
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {result.items.map((s) => (
              <Link
                key={s.id}
                href={`/stores/${s.slug}`}
                className="card group overflow-hidden transition-shadow hover:shadow-md"
              >
                <div className="relative aspect-[16/9] w-full bg-ink-100">
                  <Thumb src={s.imageUrl} alt={s.name} category={s.category} sizes="(max-width: 640px) 100vw, 33vw" />
                  <span
                    className={`absolute left-2.5 top-2.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${
                      s.isOpen ? "bg-white/95 text-brand-700 ring-brand-200" : "bg-white/95 text-ink-600 ring-ink-200"
                    }`}
                  >
                    {s.isOpen ? "Open now" : "Closed"}
                  </span>
                </div>
                <div className="p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">{s.category}</p>
                  <h2 className="mt-1 truncate font-bold group-hover:text-brand-700">{s.name}</h2>
                  <p className="mt-1 line-clamp-2 text-sm text-ink-600">{s.description}</p>
                  <p className="mt-2.5 text-[13px] text-ink-500">
                    {s.addressLine1}, {s.city} · {s.productCount} product{s.productCount === 1 ? "" : "s"}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
