import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Thumb } from "@/components/ui";
import { getStoreBySlug } from "@/server/services/discovery";
import { currentUser } from "@/server/session";
import { formatINR } from "@/lib/money";
import { AddToCartButton } from "@/components/add-to-cart";
import { RequestItemButton } from "@/components/request-item";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const store = await getStoreBySlug(slug);
  return { title: store ? `${store.name} · NearBuy` : "Store not found" };
}

export default async function StoreDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const store = await getStoreBySlug(slug);
  if (!store) notFound();

  const user = await currentUser();
  const isCustomer = user?.role === "CUSTOMER";

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <nav aria-label="Breadcrumb" className="mb-4 text-sm text-ink-500">
          <Link href="/stores" className="hover:text-brand-700 hover:underline">Stores</Link>
          <span aria-hidden className="px-1.5">/</span>
          <span className="text-ink-700">{store.name}</span>
        </nav>

        <div className="card overflow-hidden">
          <div className="relative aspect-[21/9] w-full bg-ink-100">
            <Thumb src={store.imageUrl} alt={store.name} category={store.category} sizes="100vw" priority />
          </div>
          <div className="p-5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
                {store.category}
              </span>
              <span
                className={`rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${
                  store.isOpen ? "bg-brand-50 text-brand-700 ring-brand-200" : "bg-ink-100 text-ink-600 ring-ink-200"
                }`}
              >
                {store.isOpen ? "Open now" : "Closed"}
              </span>
            </div>

            <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">{store.name}</h1>
            <p className="mt-2 max-w-3xl text-ink-600">{store.description}</p>

            <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <dt className="text-ink-500">Address</dt>
                <dd className="mt-0.5 font-medium">{store.addressLine1}, {store.city}</dd>
              </div>
              <div>
                <dt className="text-ink-500">Open today</dt>
                <dd className="mt-0.5 font-medium">{store.openingTime} – {store.closingTime}</dd>
              </div>
              <div>
                <dt className="text-ink-500">Fulfilment</dt>
                <dd className="mt-0.5 font-medium">
                  {store.supportsDelivery ? "Delivery" : "Pickup only"}
                  {store.supportsPickup && store.supportsDelivery ? " & pickup" : ""}
                </dd>
              </div>
              <div>
                <dt className="text-ink-500">Typical delivery</dt>
                <dd className="mt-0.5 font-medium">About {store.deliveryEtaMinutes} minutes</dd>
              </div>
            </dl>
          </div>
        </div>

        <h2 className="mt-8 text-xl font-bold tracking-tight">
          {store.products.length} product{store.products.length === 1 ? "" : "s"}
        </h2>

        {store.products.length === 0 ? (
          <p className="card mt-4 px-6 py-12 text-center text-ink-600">
            This store has not listed any products yet.
          </p>
        ) : (
          <ul className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {store.products.map((p) => (
              <li key={p.id} className="card flex flex-col overflow-hidden">
                <div className="relative aspect-[4/3] w-full bg-ink-100">
                  <Thumb src={p.imageUrl} alt={p.name} category={p.category} />
                  {!p.inStock ? (
                    <span className="absolute inset-0 grid place-items-center bg-white/70 text-sm font-semibold text-ink-700">
                      Out of stock
                    </span>
                  ) : null}
                </div>

                <div className="flex flex-1 flex-col p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">{p.category}</p>
                  <h3 className="mt-1 font-semibold leading-snug">{p.name}</h3>
                  <p className="mt-1.5 line-clamp-2 flex-1 text-sm text-ink-600">{p.description}</p>

                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="text-lg font-bold text-ink-900">{formatINR(p.pricePaise)}</span>
                    <span className="text-[13px] text-ink-500">per {p.unit}</span>
                  </div>

                  <p className="mt-1.5 text-[13px]">
                    {p.stockQuantity > 0 ? (
                      <span className={p.stockQuantity <= 5 ? "font-semibold text-amber-700" : "text-ink-600"}>
                        {p.stockQuantity <= 5
                          ? `Only ${p.stockQuantity} left`
                          : `${p.stockQuantity} in stock`}
                      </span>
                    ) : (
                      <span className="text-ink-500">Currently unavailable</span>
                    )}
                  </p>

                  {isCustomer ? (
                    <div className="mt-3.5 flex flex-col gap-2">
                      {p.inStock ? (
                        <AddToCartButton productId={p.id} />
                      ) : null}
                      <RequestItemButton productId={p.id} disabled={!p.inStock} />
                    </div>
                  ) : !user ? (
                    <Link href="/customer/login" className="btn-secondary mt-3.5 w-full">
                      Sign in to order
                    </Link>
                  ) : (
                    <p className="mt-3.5 text-[13px] text-ink-500">
                      Only customers can add items to a cart.
                    </p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
