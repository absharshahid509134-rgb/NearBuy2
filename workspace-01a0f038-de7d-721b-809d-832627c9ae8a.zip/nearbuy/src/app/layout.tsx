import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "NearBuy — What You Need, Already Nearby",
    template: "%s · NearBuy",
  },
  description:
    "NearBuy connects you to trusted neighbourhood stores for groceries, pharmacy, stationery and more. Order from the shops around you and get it delivered fast.",
  applicationName: "NearBuy",
  openGraph: {
    title: "NearBuy — What You Need, Already Nearby",
    description: "Groceries, essentials and more from stores in your neighbourhood.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#16a34a",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <body className="min-h-dvh flex flex-col">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3
                     focus:rounded-lg focus:bg-brand-600 focus:px-4 focus:py-2 focus:text-white"
        >
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  );
}
