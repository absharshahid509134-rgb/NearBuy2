import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, EmptyState, PageHeader, Stat, StatusBadge } from "@/components/ui";
import { riderEarnings } from "@/server/services/rider";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Earnings" };
export const dynamic = "force-dynamic";

export default async function RiderEarningsPage() {
  const rider = await requireWorkspace("RIDER", "/rider", "/rider/login");
  const earnings = await riderEarnings(rider.id);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader title="Earnings" description="Computed from your completed deliveries." />

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
          <Stat label="Earned today" value={formatINR(earnings.todayPaise)} tone="accent" />
          <Stat label="Lifetime earnings" value={formatINR(earnings.totalPaise)} tone="accent" />
          <Stat label="Deliveries completed" value={earnings.completedCount} />
        </div>

        <div className="mt-5">
          <Alert tone="info">
            Earnings accrue when a delivery is marked complete after the customer&apos;s delivery code
            is verified. No payment gateway is connected — settlements are handled offline.
          </Alert>
        </div>

        <section className="mt-6">
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Delivery history</h2>
          {earnings.history.length === 0 ? (
            <EmptyState
              title="No completed deliveries yet"
              description="Your finished jobs will appear here with the amount you earned."
              icon="💸"
            />
          ) : (
            <ul className="space-y-2">
              {earnings.history.map((h) => (
                <li key={h.jobId} className="card flex flex-wrap items-center justify-between gap-2 p-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{h.orderNumber}</p>
                      <StatusBadge status="COMPLETED" />
                    </div>
                    <p className="mt-0.5 text-[13px] text-ink-500">
                      {h.area} ·{" "}
                      {h.completedAt
                        ? new Date(h.completedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })
                        : ""}
                    </p>
                  </div>
                  <p className="text-lg font-bold tabular-nums text-brand-700">{formatINR(h.earningsPaise)}</p>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}
