import type { ReactNode } from "react";
import { requireWorkspace } from "@/server/guard";

export const dynamic = "force-dynamic";

export default async function RiderLayout({ children }: { children: ReactNode }) {
  await requireWorkspace("RIDER", "/rider", "/rider/login");
  return <>{children}</>;
}
