import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { RiderOnboarding } from "@/components/rider-onboarding";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";

export const metadata: Metadata = { title: "Rider onboarding" };
export const dynamic = "force-dynamic";

export default async function RiderOnboardingPage() {
  const rider = await requireWorkspace("RIDER", "/rider", "/rider/login");
  const profile = await prisma.riderProfile.findUnique({ where: { userId: rider.id } });

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader title="Rider onboarding" description="Tell us how you deliver, then start taking jobs." />
        <RiderOnboarding
          currentVehicleType={profile?.vehicleType ?? "BIKE"}
          currentVehicleNumber={profile?.vehicleNumber ?? null}
          isOnboarded={profile?.isOnboarded ?? false}
        />
      </main>
    </div>
  );
}
