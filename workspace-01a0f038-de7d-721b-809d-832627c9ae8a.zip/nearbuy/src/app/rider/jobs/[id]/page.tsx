import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader, StatusBadge } from "@/components/ui";
import { OrderTimeline } from "@/components/order-ui";
import { ActiveJobCard, type ActiveJobData } from "@/components/rider-actions";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Job details" };

export default async function RiderJobPage({ params }: { params: Promise<{ id: string }> }) {
  const rider = await requireWorkspace("RIDER", "/rider", "/rider/login");
  const { id } = await params;

  // The riderId filter is the authorisation: a rider cannot deep-link to
  // another rider's job, they get a 404 with nothing leaked.
  const job = await prisma.deliveryJob.findFirst({
    where: { id, riderId: rider.id },
    include: {
      order: {
        include: {
          items: true,
          handoffEvents: { orderBy: { createdAt: "asc" } },
          store: {
            select: { name: true, addressLine1: true, city: true, phone: true, latitude: true, longitude: true },
          },
        },
      },
    },
  });
  if (!job) notFound();

  const data = {
    id: job.id,
    orderId: job.orderId,
    status: job.status,
    earningsPaise: job.earningsPaise,
    order: {
      orderNumber: job.order.orderNumber,
      shipFullName: job.order.shipFullName,
      shipPhone: job.order.shipPhone,
      shipLine1: job.order.shipLine1,
      shipLine2: job.order.shipLine2,
      shipLandmark: job.order.shipLandmark,
      shipCity: job.order.shipCity,
      shipState: job.order.shipState,
      shipPincode: job.order.shipPincode,
      items: job.order.items.map((i) => ({ id: i.id, nameSnapshot: i.nameSnapshot, quantity: i.quantity })),
      store: {
        name: job.order.store.name,
        addressLine1: job.order.store.addressLine1,
        city: job.order.store.city,
        phone: job.order.store.phone,
      },
    },
  } as unknown as ActiveJobData;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <Link href="/rider/jobs" className="text-sm font-medium text-ink-600 hover:text-brand-700">
          ← All jobs
        </Link>

        <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{job.order.orderNumber}</h1>
            <p className="mt-1 text-ink-600">Pickup from {job.order.store.name}</p>
          </div>
          <StatusBadge status={job.status} />
        </div>

        <div className="mt-6 space-y-5">
          {["ASSIGNED", "PICKED_UP", "OUT_FOR_DELIVERY"].includes(job.status) ? (
            <ActiveJobCard job={data} />
          ) : (
            <div className="card p-5">
              <h2 className="font-bold">
                {job.status === "COMPLETED" ? "Delivery completed" : "This job is closed"}
              </h2>
              <p className="mt-1.5 text-sm text-ink-600">
                {job.completedAt
                  ? `Completed ${new Date(job.completedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}.`
                  : "This job is no longer active."}
              </p>
            </div>
          )}

          <section className="card p-5">
            <h2 className="font-bold">Progress</h2>
            <div className="mt-3">
              <OrderTimeline events={job.order.handoffEvents} />
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
