import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader } from "@/components/ui";
import { ActiveJobCard, AvailableJobCard, type ActiveJobData, type AvailableJob } from "@/components/rider-actions";
import { listAvailableJobs, listRiderJobs } from "@/server/services/rider";
import { requireWorkspace } from "@/server/guard";

export const metadata: Metadata = { title: "Delivery jobs" };
export const dynamic = "force-dynamic";

export default async function RiderJobsPage() {
  const rider = await requireWorkspace("RIDER", "/rider", "/rider/login");
  const [{ active }, available] = await Promise.all([
    listRiderJobs(rider.id),
    listAvailableJobs(rider.id, 50),
  ]);

  const activeJobs = active as unknown as ActiveJobData[];
  const jobs = available as unknown as AvailableJob[];

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <PageHeader
          title="Delivery jobs"
          description="Available jobs are shared — the first rider to claim one gets it."
        />

        {activeJobs.length > 0 ? (
          <section className="mb-8">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Your active jobs</h2>
            <ul className="space-y-4">
              {activeJobs.map((j) => <ActiveJobCard key={j.id} job={j} />)}
            </ul>
          </section>
        ) : null}

        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">
            Available ({jobs.length})
          </h2>
          {jobs.length === 0 ? (
            <EmptyState
              title="No jobs available"
              description="Jobs appear here as soon as a store marks an order ready for pickup. Check back shortly."
              icon="📭"
            />
          ) : (
            <ul className="grid gap-3 md:grid-cols-2">
              {jobs.map((j) => <AvailableJobCard key={j.id} job={j} />)}
            </ul>
          )}
        </section>
      </main>
    </div>
  );
}
