import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, EmptyState, PageHeader, Stat } from "@/components/ui";
import { ActiveJobCard, AvailableJobCard, type ActiveJobData, type AvailableJob } from "@/components/rider-actions";
import { listAvailableJobs, listRiderJobs, riderEarnings } from "@/server/services/rider";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Rider dashboard" };
export const dynamic = "force-dynamic";

export default async function RiderDashboardPage() {
  const rider = await requireWorkspace("RIDER", "/rider", "/rider/login");
  const [{ active, completed }, available, earnings, profile] = await Promise.all([
    listRiderJobs(rider.id),
    listAvailableJobs(rider.id, 20),
    riderEarnings(rider.id),
    prisma.riderProfile.findUnique({ where: { userId: rider.id } }),
  ]);

  const activeJobs = active as unknown as ActiveJobData[];
  const jobs = available as unknown as AvailableJob[];

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <PageHeader
          title={`Hello, ${rider.name.split(" ")[0]}`}
          description="Claim a delivery, verify the handoff, and get paid in cash."
        />

        {!profile?.isOnboarded ? (
          <div className="mb-5">
            <Alert tone="warning">
              Finish your rider profile before you start taking jobs.{" "}
              <Link href="/rider/onboarding" className="font-semibold underline">Complete onboarding</Link>
            </Alert>
          </div>
        ) : null}

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Active jobs" value={activeJobs.length} tone={activeJobs.length ? "accent" : "default"} />
          <Stat label="Available now" value={jobs.length} />
          <Stat label="Completed" value={earnings.completedCount} />
          <Stat label="Earned today" value={formatINR(earnings.todayPaise)} tone="accent" />
        </div>

        <section className="mt-6">
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Current delivery</h2>
          {activeJobs.length === 0 ? (
            <EmptyState
              title="No active delivery"
              description="Claim a job from the available list to get started."
              icon="🛵"
              action={<Link href="/rider/jobs" className="btn-primary">Browse jobs</Link>}
            />
          ) : (
            <ul className="space-y-4">
              {activeJobs.map((j) => <ActiveJobCard key={j.id} job={j} />)}
            </ul>
          )}
        </section>

        <section className="mt-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wide text-ink-500">
              Available jobs ({jobs.length})
            </h2>
            <Link href="/rider/jobs" className="text-sm font-semibold text-brand-700 hover:underline">
              See all →
            </Link>
          </div>

          {jobs.length === 0 ? (
            <div className="card px-6 py-10 text-center text-ink-600">
              No jobs are ready for pickup right now. A job appears here once the store marks the
              order <strong>Ready for pickup</strong>.
            </div>
          ) : (
            <ul className="grid gap-3 md:grid-cols-2">
              {jobs.slice(0, 4).map((j) => <AvailableJobCard key={j.id} job={j} />)}
            </ul>
          )}
        </section>

        {completed.length > 0 ? (
          <section className="mt-8">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Recently completed</h2>
            <ul className="space-y-2">
              {completed.slice(0, 5).map((j) => (
                <li key={j.id} className="card flex flex-wrap items-center justify-between gap-2 p-3.5">
                  <div>
                    <p className="font-semibold">{j.order.orderNumber}</p>
                    <p className="text-[13px] text-ink-500">
                      {j.order.shipCity} ·{" "}
                      {j.completedAt
                        ? new Date(j.completedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })
                        : ""}
                    </p>
                  </div>
                  <p className="font-bold tabular-nums text-brand-700">{formatINR(j.earningsPaise)}</p>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </main>
    </div>
  );
}
