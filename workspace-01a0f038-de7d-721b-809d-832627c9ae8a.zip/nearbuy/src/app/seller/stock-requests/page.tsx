import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { StockRequestActions } from "@/components/seller-request-actions";
import { listSellerStockRequests } from "@/server/services/requests";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Stock checks" };
export const dynamic = "force-dynamic";

export default async function SellerStockRequestsPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const requests = await listSellerStockRequests(seller.id);
  const pending = requests.filter((r) => r.status === "PENDING");

  const inventory = await prisma.inventory.findMany({
    where: { productId: { in: requests.map((r) => r.productId) } },
  });
  const sellable = new Map(
    inventory.map((i) => [i.productId, Math.max(0, i.stockQuantity - i.reservedQuantity)]),
  );

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Stock checks"
          description="Customers asking whether an item is on the shelf. Answering never reserves stock."
        />

        {requests.length === 0 ? (
          <EmptyState
            title="No stock checks"
            description="When a customer asks whether something is available, it shows up here."
            icon="🔍"
            action={<Link href="/seller/inbox" className="btn-secondary">Go to inbox</Link>}
          />
        ) : (
          <ul className="space-y-3">
            {requests.map((r) => (
              <li key={r.id} className="card p-4">
                <div className="flex gap-3">
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                    <Thumb src={r.product.imageUrl} alt={r.product.name} sizes="56px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{r.product.name}</p>
                      <StatusBadge status={r.status} />
                    </div>
                    <p className="mt-0.5 text-sm text-ink-600">
                      {r.customer.name} asked about {r.requestedQuantity} × {formatINR(r.product.pricePaise)}
                    </p>
                    <p className="text-[13px] text-ink-500">
                      {new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                    </p>
                    {r.sellerResponse ? (
                      <p className="mt-1.5 text-sm text-ink-700">
                        <span className="font-semibold">Your reply:</span> {r.sellerResponse}
                      </p>
                    ) : null}
                    {r.status === "PENDING" ? (
                      <StockRequestActions
                        requestId={r.id}
                        productId={r.productId}
                        requestedQuantity={r.requestedQuantity}
                        availableStock={sellable.get(r.productId) ?? 0}
                      />
                    ) : null}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}

        {pending.length > 0 ? (
          <p className="mt-4 text-sm text-ink-600">
            {pending.length} awaiting your reply.{" "}
            <Link href="/seller/inbox" className="font-semibold text-brand-700 hover:underline">Open inbox</Link>
          </p>
        ) : null}
      </main>
    </div>
  );
}
