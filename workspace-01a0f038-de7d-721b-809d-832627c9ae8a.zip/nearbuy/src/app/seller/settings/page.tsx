import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { StoreSettingsForm } from "@/components/store-settings-form";
import { getSellerStore } from "@/server/services/seller";
import { requireWorkspace } from "@/server/guard";
import { CATEGORIES } from "@/server/services/discovery";

export const metadata: Metadata = { title: "Store settings" };
export const dynamic = "force-dynamic";

export default async function SellerSettingsPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const store = await getSellerStore(seller.id);

  const draft = store
    ? {
        id: store.id,
        name: store.name,
        description: store.description,
        category: store.category,
        addressLine1: store.addressLine1,
        city: store.city,
        state: store.state,
        pincode: store.pincode,
        latitude: store.latitude,
        longitude: store.longitude,
        phone: store.phone,
        openingTime: store.openingTime,
        closingTime: store.closingTime,
        operatingDays: store.operatingDays.split(","),
        supportsDelivery: store.supportsDelivery,
        supportsPickup: store.supportsPickup,
        deliveryEtaMinutes: store.deliveryEtaMinutes,
        isOpen: store.isOpen,
        status: store.status,
        imageUrl: store.imageUrl,
      }
    : null;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title="Store settings"
          description="Publishing makes your store discoverable to customers. Only then can they order from you."
        />
        <StoreSettingsForm store={draft} categories={[...CATEGORIES]} />
      </main>
    </div>
  );
}
