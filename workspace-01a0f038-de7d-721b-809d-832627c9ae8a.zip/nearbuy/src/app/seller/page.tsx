import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, PageHeader, Stat, StatusBadge, Thumb } from "@/components/ui";
import { sellerDashboard } from "@/server/services/seller";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Seller dashboard" };
export const dynamic = "force-dynamic";

export default async function SellerDashboardPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const data = await sellerDashboard(seller.id);

  if (!data.store) {
    return (
      <div className="flex min-h-dvh flex-col">
        <SiteHeader />
        <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-10">
          <div className="card px-6 py-14 text-center">
            <span aria-hidden className="text-4xl">🏪</span>
            <h1 className="mt-3 text-xl font-bold">Set up your store</h1>
            <p className="mx-auto mt-2 max-w-md text-ink-600">
              You don&apos;t have a storefront yet. Create it, add your products and publish —
              customers can then find you in search.
            </p>
            <Link href="/seller/settings" className="btn-primary mt-5">Create my store</Link>
          </div>
        </main>
      </div>
    );
  }

  const c = data.counts!;
  const needsAttention = c.newOrders + c.pendingStockRequests + c.pendingReservations;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title={data.store.name}
          description={`${data.store.status === "PUBLISHED" ? "Published" : "Not published yet"} · ${data.store.isOpen ? "Open for orders" : "Closed"}`}
          action={<Link href="/seller/settings" className="btn-secondary">Store settings</Link>}
        />

        {data.store.status !== "PUBLISHED" ? (
          <div className="mb-5">
            <Alert tone="warning">
              Your store is not published, so customers cannot find or order from you.{" "}
              <Link href="/seller/settings" className="font-semibold underline">Publish your store</Link>
            </Alert>
          </div>
        ) : null}

        {needsAttention > 0 ? (
          <section className="mb-6">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Action required</h2>
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <Stat label="New orders" value={c.newOrders} tone={c.newOrders ? "accent" : "default"} href="/seller/orders?status=PLACED" />
              <Stat label="Stock checks" value={c.pendingStockRequests} tone={c.pendingStockRequests ? "warn" : "default"} href="/seller/stock-requests" />
              <Stat label="Reservations" value={c.pendingReservations} tone={c.pendingReservations ? "warn" : "default"} href="/seller/reservations" />
              <Stat label="Low-stock items" value={data.lowStock.length} tone={data.lowStock.length ? "danger" : "default"} href="/seller/inventory" />
            </div>
          </section>
        ) : (
          <div className="mb-6">
            <Alert tone="success">Nothing needs your attention right now.</Alert>
          </div>
        )}

        <section className="mb-6">
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">Current operations</h2>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Preparing & packed" value={c.preparing} href="/seller/orders?status=PREPARING" />
            <Stat label="Ready for pickup" value={c.readyForPickup} href="/seller/orders?status=READY_FOR_PICKUP" />
            <Stat label="Live products" value={c.totalProducts} href="/seller/products" />
            <Stat label="In stock" value={c.inStockCount} href="/seller/inventory" />
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1fr_320px] lg:items-start">
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wide text-ink-500">Recent orders</h2>
              <Link href="/seller/orders" className="text-sm font-semibold text-brand-700 hover:underline">
                View all →
              </Link>
            </div>

            {data.recentOrders.length === 0 ? (
              <div className="card px-6 py-12 text-center text-ink-600">No orders yet.</div>
            ) : (
              <ul className="space-y-2">
                {data.recentOrders.map((o) => (
                  <li key={o.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <Link href={`/seller/orders/${o.id}`} className="font-semibold hover:text-brand-700 hover:underline">
                          {o.orderNumber}
                        </Link>
                        <StatusBadge status={o.status} />
                      </div>
                      <p className="mt-0.5 text-[13px] text-ink-500">
                        {o.customerName} · {o.itemCount} item{o.itemCount === 1 ? "" : "s"} ·{" "}
                        {new Date(o.placedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                    <p className="font-bold tabular-nums">{formatINR(o.totalPaise)}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <aside className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">Delivered revenue</h2>
              <p className="mt-3 text-3xl font-bold tabular-nums text-brand-700">
                {formatINR(data.revenue.totalPaise)}
              </p>
              <p className="mt-1 text-[13px] text-ink-500">From {data.revenue.orderCount} delivered orders</p>
              <dl className="mt-4 space-y-2 border-t border-ink-200 pt-3 text-sm">
                <div className="flex justify-between">
                  <dt className="text-ink-600">Today</dt>
                  <dd className="font-semibold tabular-nums">{formatINR(data.revenue.todayPaise)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-600">Last 7 days</dt>
                  <dd className="font-semibold tabular-nums">{formatINR(data.revenue.last7DaysPaise)}</dd>
                </div>
              </dl>
              <Link href="/seller/performance" className="btn-secondary mt-4 w-full">Performance</Link>
            </section>

            {data.lowStock.length > 0 ? (
              <section className="card p-5">
                <h2 className="font-bold">Running low</h2>
                <ul className="mt-3 space-y-2.5">
                  {data.lowStock.map((p) => (
                    <li key={p.id} className="flex items-center gap-2.5">
                      <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                        <Thumb src={p.imageUrl} alt={p.name} sizes="40px" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{p.name}</p>
                        <p className="text-[13px] text-red-600">{p.stockQuantity} left</p>
                      </div>
                    </li>
                  ))}
                </ul>
                <Link href="/seller/inventory" className="btn-secondary mt-4 w-full">Manage inventory</Link>
              </section>
            ) : null}
          </aside>
        </div>
      </main>
    </div>
  );
}
