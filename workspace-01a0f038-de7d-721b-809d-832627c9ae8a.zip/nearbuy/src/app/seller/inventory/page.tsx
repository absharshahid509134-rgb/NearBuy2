import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { listSellerProducts } from "@/server/services/seller";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Inventory" };
export const dynamic = "force-dynamic";

export default async function SellerInventoryPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const products = await listSellerProducts(seller.id);

  const rows = products.map((p) => {
    const stock = p.inventory?.stockQuantity ?? 0;
    const reserved = p.inventory?.reservedQuantity ?? 0;
    return { p, stock, reserved, sellable: Math.max(0, stock - reserved) };
  });

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title="Inventory"
          description="Sellable stock is what customers can buy. Held stock is reserved against confirmed reservations."
        />

        {rows.length === 0 ? (
          <EmptyState
            title="No products yet"
            description="Add products to track their stock levels here."
            icon="📦"
            action={<Link href="/seller/products" className="btn-primary">Add products</Link>}
          />
        ) : (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <caption className="sr-only">Product stock levels</caption>
                <thead className="border-b border-ink-200 bg-ink-50 text-left">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-semibold">Product</th>
                    <th scope="col" className="px-4 py-3 font-semibold">Price</th>
                    <th scope="col" className="px-4 py-3 text-right font-semibold">In stock</th>
                    <th scope="col" className="px-4 py-3 text-right font-semibold">Held</th>
                    <th scope="col" className="px-4 py-3 text-right font-semibold">Sellable</th>
                    <th scope="col" className="px-4 py-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {rows.map(({ p, stock, reserved, sellable }) => (
                    <tr key={p.id}>
                      <th scope="row" className="px-4 py-3 text-left font-medium">
                        <div className="flex items-center gap-2.5">
                          <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                            <Thumb src={p.imageUrl} alt={p.name} category={p.category} sizes="40px" />
                          </div>
                          <div className="min-w-0">
                            <p className="truncate">{p.name}</p>
                            <p className="text-[13px] text-ink-500">{p.category}</p>
                          </div>
                        </div>
                      </th>
                      <td className="px-4 py-3 tabular-nums">{formatINR(p.pricePaise)}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{stock}</td>
                      <td className="px-4 py-3 text-right tabular-nums text-amber-700">{reserved}</td>
                      <td className="px-4 py-3 text-right font-semibold tabular-nums">{sellable}</td>
                      <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <p className="mt-4 text-sm text-ink-600">
          Edit quantities from <Link href="/seller/products" className="font-semibold text-brand-700 hover:underline">Products</Link>.
        </p>
      </main>
    </div>
  );
}
