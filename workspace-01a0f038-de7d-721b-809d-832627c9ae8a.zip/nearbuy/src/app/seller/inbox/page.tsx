import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { StockRequestActions, ReservationActions } from "@/components/seller-request-actions";
import { listActionItems } from "@/server/services/seller";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Inbox" };
export const dynamic = "force-dynamic";

export default async function SellerInboxPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const { stockRequests, reservations } = await listActionItems(seller.id);

  // Sellable stock is needed to decide whether "hold" is even possible.
  const productIds = [
    ...stockRequests.map((r) => r.productId),
    ...reservations.map((r) => r.productId),
  ];
  const inventory = await prisma.inventory.findMany({ where: { productId: { in: productIds } } });
  const sellable = new Map(
    inventory.map((i) => [i.productId, Math.max(0, i.stockQuantity - i.reservedQuantity)]),
  );

  const total = stockRequests.length + reservations.length;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Inbox"
          description={total > 0 ? `${total} request${total === 1 ? "" : "s"} waiting for you` : "Nothing waiting"}
        />

        {total === 0 ? (
          <EmptyState
            title="Nothing to answer"
            description="Stock checks and reservations from customers land here."
            icon="📥"
          />
        ) : (
          <div className="space-y-8">
            {stockRequests.length > 0 ? (
              <section>
                <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">
                  Stock checks ({stockRequests.length})
                </h2>
                <ul className="space-y-3">
                  {stockRequests.map((r) => (
                    <li key={r.id} className="card p-4">
                      <div className="flex gap-3">
                        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                          <Thumb src={r.product.imageUrl} alt={r.product.name} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold">{r.product.name}</p>
                          <p className="mt-0.5 text-sm text-ink-600">
                            <span className="font-medium text-ink-800">{r.customer.name}</span> asked: is{" "}
                            <strong>{r.requestedQuantity} × {formatINR(r.product.pricePaise)}</strong> available?
                          </p>
                          <p className="mt-0.5 text-[13px] text-ink-500">
                            {r.customer.phone} · {new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                          </p>
                          <StockRequestActions
                            requestId={r.id}
                            productId={r.productId}
                            requestedQuantity={r.requestedQuantity}
                            availableStock={sellable.get(r.productId) ?? 0}
                          />
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </section>
            ) : null}

            {reservations.length > 0 ? (
              <section>
                <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">
                  Reservations ({reservations.length})
                </h2>
                <ul className="space-y-3">
                  {reservations.map((r) => (
                    <li key={r.id} className="card p-4">
                      <div className="flex gap-3">
                        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                          <Thumb src={r.product.imageUrl} alt={r.product.name} />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold">{r.product.name}</p>
                          <p className="mt-0.5 text-sm text-ink-600">
                            <span className="font-medium text-ink-800">{r.customer.name}</span> asked to reserve{" "}
                            <strong>{r.requestedQuantity}</strong> unit{r.requestedQuantity === 1 ? "" : "s"}.
                          </p>
                          <p className="mt-0.5 text-[13px] text-ink-500">
                            {r.customer.phone} · {new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                          </p>
                          <ReservationActions
                            reservationId={r.id}
                            requestedQuantity={r.requestedQuantity}
                            availableStock={sellable.get(r.productId) ?? 0}
                          />
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </section>
            ) : null}
          </div>
        )}

        <p className="mt-6 text-sm text-ink-600">
          Full history: <Link href="/seller/stock-requests" className="font-semibold text-brand-700 hover:underline">stock checks</Link>{" "}
          · <Link href="/seller/reservations" className="font-semibold text-brand-700 hover:underline">reservations</Link>
        </p>
      </main>
    </div>
  );
}
