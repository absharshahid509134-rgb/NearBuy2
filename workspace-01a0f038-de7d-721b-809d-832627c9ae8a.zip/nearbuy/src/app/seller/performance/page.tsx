import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, Stat } from "@/components/ui";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Performance" };
export const dynamic = "force-dynamic";

const DAY = 24 * 60 * 60 * 1000;

export default async function SellerPerformancePage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const store = await prisma.store.findFirst({ where: { sellerId: seller.id } });
  if (!store) {
    return (
      <div className="flex min-h-dvh flex-col">
        <SiteHeader />
        <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
          <PageHeader title="Performance" />
          <EmptyState title="No store yet" description="Create your store to see performance here." />
        </main>
      </div>
    );
  }

  const now = Date.now();
  const [totals, delivered, topProducts, byDay] = await Promise.all([
    prisma.order.aggregate({
      where: { storeId: store.id },
      _count: { _all: true },
      _sum: { totalPaise: true, subtotalPaise: true, deliveryFeePaise: true },
    }),
    prisma.order.count({ where: { storeId: store.id, status: "DELIVERED" } }),
    prisma.orderItem.groupBy({
      by: ["productId", "nameSnapshot"],
      where: { order: { storeId: store.id } },
      _sum: { quantity: true, lineTotalPaise: true },
      orderBy: { _sum: { quantity: "desc" } },
      take: 8,
    }),
    prisma.order.findMany({
      where: { storeId: store.id, placedAt: { gte: new Date(now - 7 * DAY) } },
      select: { placedAt: true, totalPaise: true, status: true },
    }),
  ]);

  // Seven day buckets, oldest first, so the bars read left to right.
  const days = Array.from({ length: 7 }, (_, i) => {
    const start = new Date(now - (6 - i) * DAY);
    start.setHours(0, 0, 0, 0);
    const end = new Date(start.getTime() + DAY);
    const inDay = byDay.filter((o) => o.placedAt >= start && o.placedAt < end);
    return {
      label: start.toLocaleDateString("en-IN", { weekday: "short" }),
      orders: inDay.length,
      revenuePaise: inDay.reduce((s, o) => s + o.totalPaise, 0),
    };
  });
  const peak = Math.max(1, ...days.map((d) => d.revenuePaise));

  const cancelled = await prisma.order.count({ where: { storeId: store.id, status: { in: ["CANCELLED", "REJECTED"] } } });
  const completionRate = totals._count._all > 0 ? Math.round((delivered / totals._count._all) * 100) : 0;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <PageHeader
          title="Performance"
          description="Every figure is an aggregate over your real delivered orders. Nothing here is estimated."
        />

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Orders received" value={totals._count._all} />
          <Stat label="Delivered" value={delivered} tone="accent" />
          <Stat label="Completion rate" value={`${completionRate}%`} />
          <Stat label="Cancelled / declined" value={cancelled} tone={cancelled ? "warn" : "default"} />
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Gross order value" value={formatINR(totals._sum.totalPaise ?? 0)} />
          <Stat label="Product subtotal" value={formatINR(totals._sum.subtotalPaise ?? 0)} />
          <Stat label="Delivery collected" value={formatINR(totals._sum.deliveryFeePaise ?? 0)} />
          <Stat
            label="Average order"
            value={formatINR(
              totals._count._all > 0 ? Math.round((totals._sum.totalPaise ?? 0) / totals._count._all) : 0,
            )}
          />
        </div>

        <section className="card mt-6 p-5">
          <h2 className="font-bold">Last 7 days</h2>
          <p className="mt-1 text-sm text-ink-600">Order value placed each day.</p>
          <div className="mt-5 flex h-40 items-end gap-2">
            {days.map((d) => (
              <div key={d.label + d.orders} className="flex flex-1 flex-col items-center gap-1.5">
                <span className="text-[11px] font-semibold tabular-nums text-ink-600">
                  {d.revenuePaise > 0 ? `₹${Math.round(d.revenuePaise / 100)}` : "—"}
                </span>
                <div
                  className="w-full rounded-t-md bg-brand-500"
                  style={{ height: `${Math.max(3, (d.revenuePaise / peak) * 110)}px` }}
                  role="img"
                  aria-label={`${d.label}: ${d.orders} orders, ${formatINR(d.revenuePaise)}`}
                />
                <span className="text-[11px] text-ink-500">{d.label}</span>
                <span className="text-[11px] tabular-nums text-ink-400">{d.orders} ord</span>
              </div>
            ))}
          </div>
        </section>

        <section className="card mt-5 overflow-hidden">
          <h2 className="border-b border-ink-200 px-5 py-4 font-bold">Best sellers by units</h2>
          {topProducts.length === 0 ? (
            <p className="px-5 py-10 text-center text-ink-600">No sales yet.</p>
          ) : (
            <ul className="divide-y divide-ink-100">
              {topProducts.map((p) => (
                <li key={p.productId} className="flex items-center justify-between gap-3 px-5 py-3.5">
                  <span className="min-w-0 truncate font-medium">{p.nameSnapshot}</span>
                  <span className="shrink-0 text-sm text-ink-600">
                    {p._sum.quantity} units ·{" "}
                    <span className="font-semibold tabular-nums text-ink-900">
                      {formatINR(p._sum.lineTotalPaise ?? 0)}
                    </span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <p className="mt-4 text-sm text-ink-600">
          Back to <Link href="/seller" className="font-semibold text-brand-700 hover:underline">your dashboard</Link>.
        </p>
      </main>
    </div>
  );
}
