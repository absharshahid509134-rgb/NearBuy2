import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, StatusBadge } from "@/components/ui";
import { listSellerOrders } from "@/server/services/seller";
import { orderView } from "@/server/services/orders";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Orders" };
export const dynamic = "force-dynamic";

const TABS = [
  { key: "ALL", label: "All" },
  { key: "PLACED", label: "New" },
  { key: "ACCEPTED", label: "Accepted" },
  { key: "PREPARING", label: "Preparing" },
  { key: "PACKED", label: "Packed" },
  { key: "READY_FOR_PICKUP", label: "Ready" },
  { key: "DELIVERED", label: "Delivered" },
];

export default async function SellerOrdersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const sp = await searchParams;
  const status = (Array.isArray(sp.status) ? sp.status[0] : sp.status) ?? "ALL";

  const orders = await listSellerOrders(seller.id, status === "ALL" ? undefined : status);
  const views = orders.map((o) => orderView(o, seller));

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <PageHeader title="Orders" description={`${orders.length} order${orders.length === 1 ? "" : "s"}`} />

        <div className="mb-5 flex flex-wrap gap-2">
          {TABS.map((t) => (
            <Link
              key={t.key}
              href={`/seller/orders?status=${t.key}`}
              aria-current={status === t.key ? "page" : undefined}
              className={`btn btn-sm ${status === t.key ? "bg-brand-600 text-white" : "bg-white text-ink-700 border border-ink-300 hover:bg-ink-100"}`}
            >
              {t.label}
            </Link>
          ))}
        </div>

        {views.length === 0 ? (
          <EmptyState
            title={status === "ALL" ? "No orders yet" : "No orders with that status"}
            description="When a customer checks out, their order appears here immediately."
            action={<Link href="/seller" className="btn-secondary">Back to dashboard</Link>}
          />
        ) : (
          <ul className="space-y-3">
            {views.map((o) => (
              <li key={o.id} className="card p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link href={`/seller/orders/${o.id}`} className="font-semibold hover:text-brand-700 hover:underline">
                        {o.orderNumber}
                      </Link>
                      <StatusBadge status={o.status} />
                      <span className="rounded-full bg-ink-100 px-2 py-0.5 text-[11px] font-semibold text-ink-600">
                        {o.fulfillmentType === "PICKUP" ? "Pickup" : "Delivery"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-ink-600">
                      {(o as { customer?: { name: string } }).customer?.name} ·{" "}
                      {new Date(o.placedAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <p className="font-bold tabular-nums">{formatINR(o.totalPaise)}</p>
                </div>

                <p className="mt-2.5 line-clamp-1 text-sm text-ink-600">
                  {o.items.map((i) => `${i.nameSnapshot} × ${i.quantity}`).join(", ")}
                </p>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
