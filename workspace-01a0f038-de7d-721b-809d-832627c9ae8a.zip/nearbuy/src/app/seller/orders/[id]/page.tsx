import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, HandoffCode, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { OrderTimeline } from "@/components/order-ui";
import { SellerOrderActions } from "@/components/seller-order-actions";
import { loadOrderForActor, orderView } from "@/server/services/orders";
import { requireWorkspace } from "@/server/guard";
import { nextTransitions, ORDER_STATUS_LABEL, type OrderStatus } from "@/lib/enums";
import { formatINR } from "@/lib/money";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order details" };

export default async function SellerOrderPage({ params }: { params: Promise<{ id: string }> }) {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const { id } = await params;

  // 404 for another seller's order — ownership is part of the query.
  const raw = await loadOrderForActor(id, seller);
  const order = orderView(raw, seller);
  const allowed = nextTransitions(order.status as OrderStatus, "SELLER").map((t) => t.to);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <Link href="/seller/orders" className="text-sm font-medium text-ink-600 hover:text-brand-700">
          ← All orders
        </Link>

        <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{order.orderNumber}</h1>
            <p className="mt-1 text-ink-600">
              {order.customer.name} · {order.customer.phone} ·{" "}
              {new Date(order.placedAt).toLocaleString("en-IN", {
                day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
              })}
            </p>
          </div>
          <StatusBadge status={order.status} />
        </div>

        <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_320px] lg:items-start">
          <div className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">
                {ORDER_STATUS_LABEL[order.status as OrderStatus]} ·{" "}
                {order.fulfillmentType === "PICKUP" ? "Customer pickup" : "Home delivery"}
              </h2>
              <div className="mt-4">
                <SellerOrderActions
                  orderId={order.id}
                  status={order.status}
                  fulfillmentType={order.fulfillmentType}
                  allowed={allowed}
                />
              </div>
            </section>

            {/* The pickup code appears only once the order is packed and waiting
                for a rider — and only for this store's own seller. */}
            {order.pickupCode ? (
              <HandoffCode
                code={order.pickupCode}
                label="Pickup handoff code"
                hint="Read this out to the rider when they collect this order. Never share it with the customer."
              />
            ) : order.status === "READY_FOR_PICKUP" ||
              order.status === "PICKED_UP" ||
              order.status === "OUT_FOR_DELIVERY" ? null : (
              <Alert tone="info">
                The pickup code unlocks once you mark this order <strong>Ready for pickup</strong>.
              </Alert>
            )}

            <section className="card overflow-hidden">
              <h2 className="border-b border-ink-200 px-5 py-4 font-bold">Items to pack</h2>
              <ul className="divide-y divide-ink-100">
                {order.items.map((i) => (
                  <li key={i.id} className="flex items-center gap-3 p-4">
                    <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                      <Thumb src={i.imageUrlSnapshot} alt={i.nameSnapshot} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold leading-snug">{i.nameSnapshot}</p>
                      <p className="text-[13px] text-ink-500">
                        {i.quantity} × {formatINR(i.unitPricePaise)}
                        {i.unitSnapshot ? ` · ${i.unitSnapshot}` : ""}
                      </p>
                    </div>
                    <p className="font-bold tabular-nums">{formatINR(i.lineTotalPaise)}</p>
                  </li>
                ))}
              </ul>
              <dl className="space-y-2 border-t border-ink-200 bg-ink-50 px-5 py-4 text-sm">
                <div className="flex justify-between">
                  <dt className="text-ink-600">Subtotal</dt>
                  <dd className="font-semibold tabular-nums">{formatINR(order.subtotalPaise)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-600">Delivery fee</dt>
                  <dd className="font-semibold tabular-nums">
                    {order.deliveryFeePaise === 0 ? "—" : formatINR(order.deliveryFeePaise)}
                  </dd>
                </div>
                <div className="flex justify-between border-t border-ink-200 pt-2 text-base">
                  <dt className="font-bold">Order total</dt>
                  <dd className="font-bold tabular-nums">{formatINR(order.totalPaise)}</dd>
                </div>
              </dl>
            </section>
          </div>

          <aside className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">
                {order.fulfillmentType === "PICKUP" ? "Customer collects from" : "Deliver to"}
              </h2>
              <address className="mt-2 text-sm not-italic text-ink-700">
                <span className="block font-semibold">{order.shipFullName}</span>
                <span className="block">{order.shipPhone}</span>
                <span className="mt-1 block">{order.shipLine1}</span>
                {order.shipLine2 ? <span className="block">{order.shipLine2}</span> : null}
                {order.shipLandmark ? <span className="block text-ink-500">Near {order.shipLandmark}</span> : null}
                <span className="block">{order.shipCity}, {order.shipState} {order.shipPincode}</span>
              </address>
            </section>

            {order.rider ? (
              <section className="card p-5">
                <h2 className="font-bold">Assigned rider</h2>
                <p className="mt-2 font-semibold">{order.rider.name}</p>
                <p className="text-sm text-ink-600">{order.rider.phone}</p>
              </section>
            ) : null}

            <section className="card p-5">
              <h2 className="font-bold">Progress</h2>
              <div className="mt-3">
                <OrderTimeline events={order.handoffEvents} />
              </div>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
}
