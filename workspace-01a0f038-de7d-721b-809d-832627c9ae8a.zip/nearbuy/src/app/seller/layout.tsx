import type { ReactNode } from "react";
import { requireWorkspace } from "@/server/guard";

export const dynamic = "force-dynamic";

export default async function SellerLayout({ children }: { children: ReactNode }) {
  await requireWorkspace("SELLER", "/seller", "/seller/login");
  return <>{children}</>;
}
