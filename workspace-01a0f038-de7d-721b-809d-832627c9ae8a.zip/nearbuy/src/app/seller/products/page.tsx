import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { ProductManager } from "@/components/product-manager";
import { listSellerProducts, getSellerStore } from "@/server/services/seller";
import { requireWorkspace } from "@/server/guard";
import { CATEGORIES } from "@/server/services/discovery";

export const metadata: Metadata = { title: "Products" };
export const dynamic = "force-dynamic";

export default async function SellerProductsPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const [products, store] = await Promise.all([listSellerProducts(seller.id), getSellerStore(seller.id)]);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title="Products"
          description={
            store
              ? "Publish a product to make it searchable and orderable by customers."
              : "Create your store first, then add products."
          }
        />
        <ProductManager products={products} categories={[...CATEGORIES]} />
      </main>
    </div>
  );
}
