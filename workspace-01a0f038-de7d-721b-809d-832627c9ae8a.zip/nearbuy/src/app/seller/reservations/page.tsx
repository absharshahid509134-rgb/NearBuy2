import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { ReservationActions } from "@/components/seller-request-actions";
import { listSellerReservations } from "@/server/services/requests";
import { requireWorkspace } from "@/server/guard";
import { prisma } from "@/server/db";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Reservations" };
export const dynamic = "force-dynamic";

export default async function SellerReservationsPage() {
  const seller = await requireWorkspace("SELLER", "/seller", "/seller/login");
  const reservations = await listSellerReservations(seller.id);

  const inventory = await prisma.inventory.findMany({
    where: { productId: { in: reservations.map((r) => r.productId) } },
  });
  const sellable = new Map(
    inventory.map((i) => [i.productId, Math.max(0, i.stockQuantity - i.reservedQuantity)]),
  );

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Reservations"
          description="Requests to hold items. Stock is only actually held when you tick “hold stock”."
        />

        {reservations.length === 0 ? (
          <EmptyState
            title="No reservations"
            description="Reservation requests from customers appear here."
            icon="🔖"
            action={<Link href="/seller/inbox" className="btn-secondary">Go to inbox</Link>}
          />
        ) : (
          <ul className="space-y-3">
            {reservations.map((r) => (
              <li key={r.id} className="card p-4">
                <div className="flex gap-3">
                  <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                    <Thumb src={r.product.imageUrl} alt={r.product.name} sizes="56px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{r.product.name}</p>
                      <StatusBadge status={r.status} />
                      {r.status === "CONFIRMED" ? (
                        <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${
                          r.stockHeld ? "bg-brand-100 text-brand-800" : "bg-amber-100 text-amber-800"
                        }`}>
                          {r.stockHeld ? "Stock held" : "Not held"}
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-0.5 text-sm text-ink-600">
                      {r.customer.name} · {r.requestedQuantity} × {formatINR(r.product.pricePaise)}
                    </p>
                    <p className="text-[13px] text-ink-500">
                      {new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                      {r.expiresAt && r.status === "CONFIRMED"
                        ? ` · held until ${new Date(r.expiresAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}`
                        : ""}
                    </p>
                    {r.sellerResponse ? (
                      <p className="mt-1.5 text-sm text-ink-700">
                        <span className="font-semibold">Your reply:</span> {r.sellerResponse}
                      </p>
                    ) : null}

                    {r.status === "PENDING" ? (
                      <ReservationActions
                        reservationId={r.id}
                        requestedQuantity={r.requestedQuantity}
                        availableStock={sellable.get(r.productId) ?? 0}
                      />
                    ) : null}

                    {r.status === "CONFIRMED" && !r.stockHeld ? (
                      <div className="mt-2">
                        <Alert tone="warning">
                          Confirmed without holding. This item can still sell to another shopper.
                        </Alert>
                      </div>
                    ) : null}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
