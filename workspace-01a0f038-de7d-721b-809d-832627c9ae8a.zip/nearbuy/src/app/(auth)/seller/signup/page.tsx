import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { SiteHeader } from "@/components/site-header";
import { currentUser } from "@/server/session";

export const metadata: Metadata = { title: "Seller sign up · NearBuy" };
export const dynamic = "force-dynamic";

export default async function Page() {
  // Already signed in as this role? Skip straight to that workspace.
  const user = await currentUser();
  if (user && user.role === "SELLER") redirect("/seller");

  const isSignup = true;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-md flex-1 px-4 py-10 sm:py-16">
        <div className="mb-6 text-center">
          <span aria-hidden className="text-3xl">🏪</span>
          <h1 className="mt-2 text-2xl font-bold tracking-tight">
            {isSignup ? "Create your" : "Welcome back"}{" "}
            <span className="text-brand-700">seller</span> {isSignup ? "account" : ""}
          </h1>
          <p className="mt-1.5 text-ink-600">Run your store on NearBuy</p>
        </div>

        <div className="card p-5 sm:p-6">
          <AuthForm role="SELLER" mode="signup" />
        </div>

        <p className="mt-6 text-center text-sm text-ink-500">
          Not a seller?{" "}
          <Link href="/#roles" className="font-semibold text-brand-700 underline underline-offset-2">
            See all NearBuy roles
          </Link>
        </p>
      </main>
    </div>
  );
}
