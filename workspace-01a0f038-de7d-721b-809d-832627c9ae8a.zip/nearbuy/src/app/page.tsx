import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Thumb } from "@/components/ui";
import { currentUser } from "@/server/session";
import { getCategoriesWithCounts, searchProducts, searchStores } from "@/server/services/discovery";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = {
  title: "NearBuy — What You Need, Already Nearby",
  description:
    "Groceries, dairy, pharmacy, stationery and household essentials from the stores already on your street. Delivered in under 40 minutes.",
};

export const dynamic = "force-dynamic";

const STEPS = [
  { n: "1", t: "Find a store near you", d: "Browse real neighbourhood shops with live prices and stock." },
  { n: "2", t: "Fill your cart", d: "Mix items from several stores — we split them into separate orders automatically." },
  { n: "3", t: "Track it to your door", d: "Follow the seller preparing your order and the rider bringing it to you." },
];

export default async function LandingPage() {
  const user = await currentUser();
  const [stores, products, categories] = await Promise.all([
    searchStores({ q: "", open: false, page: 1, pageSize: 6, sort: "newest" }),
    searchProducts({ q: "", page: 1, pageSize: 8, inStock: true, sort: "newest" }),
    getCategoriesWithCounts(),
  ]);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main id="main" className="flex-1">
        {/* ---------------------------------------------------------- hero */}
        <section className="border-b border-ink-200 bg-gradient-to-b from-brand-50 to-white">
          <div className="mx-auto max-w-6xl px-4 py-12 sm:py-20">
            <div className="max-w-2xl">
              <p className="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-[13px] font-semibold text-brand-700 ring-1 ring-brand-200">
                <span aria-hidden>●</span> Live in Dwarka &amp; nearby sectors
              </p>
              <h1 className="mt-4 text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
                What you need,
                <br />
                <span className="text-brand-700">already nearby.</span>
              </h1>
              <p className="mt-5 max-w-xl text-lg text-ink-600">
                NearBuy connects you to the shops already on your street — groceries, dairy,
                pharmacy and stationery — with real stock, honest prices and delivery you can
                actually track.
              </p>

              <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                {user ? (
                  <Link href={`/${user.role.toLowerCase()}`} className="btn-primary-lg">
                    Go to your workspace
                  </Link>
                ) : (
                  <>
                    <Link href="/stores" className="btn-primary-lg">
                      Browse nearby stores
                    </Link>
                    <Link href="/customer/login" className="btn-secondary btn-lg">
                      Sign in
                    </Link>
                  </>
                )}
              </div>

              <dl className="mt-9 grid max-w-lg grid-cols-3 gap-4">
                {[
                  ["Stores live", stores.total],
                  ["Products in stock", products.total],
                  ["Avg. delivery", "35 min"],
                ].map(([label, value]) => (
                  <div key={String(label)}>
                    <dt className="text-[13px] text-ink-500">{label}</dt>
                    <dd className="text-2xl font-bold tabular-nums text-ink-900">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </section>

        {/* ------------------------------------------------------ categories */}
        {categories.length > 0 ? (
          <section className="mx-auto max-w-6xl px-4 py-10">
            <h2 className="text-xl font-bold tracking-tight sm:text-2xl">Shop by category</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {categories.slice(0, 10).map((c) => (
                <Link
                  key={c.category}
                  href={`/stores?category=${encodeURIComponent(c.category)}`}
                  className="btn-secondary btn-sm"
                >
                  {c.category}
                  <span className="text-ink-400">{c.count}</span>
                </Link>
              ))}
            </div>
          </section>
        ) : null}

        {/* ---------------------------------------------------------- stores */}
        <section className="mx-auto max-w-6xl px-4 py-6">
          <div className="mb-4 flex items-end justify-between gap-4">
            <h2 className="text-xl font-bold tracking-tight sm:text-2xl">Stores near you</h2>
            <Link href="/stores" className="text-sm font-semibold text-brand-700 hover:underline">
              See all →
            </Link>
          </div>

          {stores.items.length === 0 ? (
            <div className="card px-6 py-12 text-center text-ink-600">
              No stores are published yet. Sign up as a seller to publish the first one.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {stores.items.map((s) => (
                <Link
                  key={s.id}
                  href={`/stores/${s.slug}`}
                  className="card group overflow-hidden transition-shadow hover:shadow-md"
                >
                  <div className="relative aspect-[16/9] w-full overflow-hidden bg-ink-100">
                    <Thumb src={s.imageUrl} alt={s.name} category={s.category} sizes="(max-width: 640px) 100vw, 33vw" />
                    <span
                      className={`absolute left-2.5 top-2.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset ${
                        s.isOpen ? "bg-white/95 text-brand-700 ring-brand-200" : "bg-white/95 text-ink-600 ring-ink-200"
                      }`}
                    >
                      {s.isOpen ? "Open now" : "Closed"}
                    </span>
                  </div>
                  <div className="p-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">
                      {s.category}
                    </p>
                    <h3 className="mt-1 truncate font-bold group-hover:text-brand-700">{s.name}</h3>
                    <p className="mt-1 line-clamp-2 text-sm text-ink-600">{s.description}</p>
                    <p className="mt-2.5 text-[13px] text-ink-500">
                      {s.addressLine1}, {s.city} · {s.productCount} product{s.productCount === 1 ? "" : "s"}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>

        {/* -------------------------------------------------------- products */}
        {products.items.length > 0 ? (
          <section className="mx-auto max-w-6xl px-4 py-6">
            <h2 className="text-xl font-bold tracking-tight sm:text-2xl">Popular near you</h2>
            <div className="mt-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
              {products.items.slice(0, 8).map((p) => (
                <Link
                  key={p.id}
                  href={`/stores/${p.store.slug}`}
                  className="card overflow-hidden transition-shadow hover:shadow-md"
                >
                  <div className="relative aspect-[4/3] w-full bg-ink-100">
                    <Thumb src={p.imageUrl} alt={p.name} category={p.category} />
                  </div>
                  <div className="p-3">
                    <p className="line-clamp-2 text-sm font-semibold leading-snug">{p.name}</p>
                    <p className="mt-0.5 truncate text-xs text-ink-500">{p.store.name}</p>
                    <p className="mt-1.5 font-bold text-brand-700">{formatINR(p.pricePaise)}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ) : null}

        {/* ---------------------------------------------------------- roles */}
        <section id="roles" className="border-t border-ink-200 bg-white py-12">
          <div className="mx-auto max-w-6xl px-4">
            <h2 className="text-center text-2xl font-bold tracking-tight">One platform, three roles</h2>
            <p className="mx-auto mt-2 max-w-xl text-center text-ink-600">
              Every role has its own workspace, its own sign-in and its own permissions.
            </p>

            <div className="mt-8 grid gap-4 md:grid-cols-3">
              {[
                { role: "Customer", icon: "🛒", to: "/customer/login", points: ["Shop nearby stores", "Split multi-store checkouts", "Track orders live", "Reserve or stock-check items"] },
                { role: "Seller", icon: "🏪", to: "/seller/login", points: ["Publish a storefront", "Manage catalogue & stock", "Run the order queue", "See real revenue"] },
                { role: "Rider", icon: "🛵", to: "/rider/login", points: ["Claim nearby jobs", "Verify pickup with a code", "Deliver against a code", "Track earnings"] },
              ].map((c) => (
                <div key={c.role} className="card flex flex-col p-5">
                  <span aria-hidden className="text-2xl">{c.icon}</span>
                  <h3 className="mt-2 font-bold">{c.role}</h3>
                  <ul className="mt-3 flex-1 space-y-1.5 text-sm text-ink-600">
                    {c.points.map((p) => (
                      <li key={p} className="flex gap-2">
                        <span aria-hidden className="text-brand-600">✓</span>
                        {p}
                      </li>
                    ))}
                  </ul>
                  <Link href={c.to} className="btn-secondary mt-4 w-full">
                    Sign in as {c.role.toLowerCase()}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ---------------------------------------------------------- how it works */}
        <section className="mx-auto max-w-6xl px-4 py-12">
          <h2 className="text-2xl font-bold tracking-tight">How NearBuy works</h2>
          <ol className="mt-6 grid gap-4 md:grid-cols-3">
            {STEPS.map((s) => (
              <li key={s.n} className="card p-5">
                <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-100 font-bold text-brand-800">
                  {s.n}
                </span>
                <h3 className="mt-3 font-bold">{s.t}</h3>
                <p className="mt-1.5 text-sm text-ink-600">{s.d}</p>
              </li>
            ))}
          </ol>
        </section>
      </main>

      <footer className="border-t border-ink-200 bg-white py-8">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 text-sm text-ink-500 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} NearBuy. What You Need, Already Nearby.</p>
          <p>Cash on delivery · No online payment is processed by this demo.</p>
        </div>
      </footer>
    </div>
  );
}
