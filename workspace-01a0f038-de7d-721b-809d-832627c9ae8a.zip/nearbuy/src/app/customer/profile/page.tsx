import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { ProfileView } from "@/components/profile-view";
import { requireWorkspace } from "@/server/guard";

export const metadata: Metadata = { title: "Profile" };
export const dynamic = "force-dynamic";

const ROLE = "CUSTOMER";

export default async function ProfilePage() {
  const user = await requireWorkspace(ROLE, "/customer", "/ROLE/login");
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader title="Profile" description="Your account details and sign-in security." />
        <ProfileView name={user.name} email={user.email} phone={user.phone} role={user.role} />
      </main>
    </div>
  );
}
