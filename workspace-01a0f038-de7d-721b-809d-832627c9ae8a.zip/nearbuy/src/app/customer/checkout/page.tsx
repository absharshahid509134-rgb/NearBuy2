import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader, EmptyState } from "@/components/ui";
import { CheckoutClient } from "@/components/checkout-client";
import { getCartView } from "@/server/services/cart";
import { prisma } from "@/server/db";
import { deliveryFeePaise, haversineKm } from "@/lib/geo";
import { env } from "@/lib/env";
import type { CheckoutPreview } from "@/lib/checkout-types";
import Link from "next/link";

export const metadata: Metadata = { title: "Checkout" };
export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const { requireWorkspace } = await import("@/server/guard");
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");

  const [cart, addresses] = await Promise.all([
    getCartView(user.id),
    prisma.address.findMany({
      where: { customerId: user.id },
      orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
    }),
  ]);

  if (cart.groups.length === 0) {
    return (
      <div className="flex min-h-dvh flex-col">
        <SiteHeader />
        <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
          <PageHeader title="Checkout" />
          <EmptyState
            title="Nothing to check out"
            description="Your cart is empty. Add something from a store near you first."
            action={<Link href="/stores" className="btn-primary">Browse stores</Link>}
          />
        </main>
      </div>
    );
  }

  // Preview pricing uses the same code the checkout transaction will run, so
  // the number on screen and the number on the order come from one place.
  const e = env();
  const defaultAddress = addresses.find((a) => a.isDefault) ?? addresses[0] ?? null;

  const groups = await Promise.all(
    cart.groups.map(async (g) => {
      const store = await prisma.store.findUnique({
        where: { id: g.store.id },
        select: {
          id: true, name: true, slug: true, latitude: true, longitude: true,
          supportsDelivery: true, supportsPickup: true,
        },
      });
      const delivery =
        store && defaultAddress && store.supportsDelivery
          ? deliveryFeePaise(
              haversineKm(
                { lat: store.latitude, lng: store.longitude },
                { lat: defaultAddress.latitude, lng: defaultAddress.longitude },
              ),
              {
                basePaise: e.DELIVERY_BASE_PAISE,
                perKmPaise: e.DELIVERY_PER_KM_PAISE,
                minPaise: e.DELIVERY_MIN_PAISE,
                maxPaise: e.DELIVERY_MAX_PAISE,
              },
            )
          : 0;

      return {
        storeId: g.store.id,
        storeName: g.store.name,
        storeSlug: g.store.slug,
        subtotalPaise: g.subtotalPaise,
        deliveryFeePaise: delivery,
        items: g.items.map((i) => ({
          id: i.id,
          name: i.name,
          quantity: i.quantity,
          lineTotalPaise: i.lineTotalPaise,
        })),
        supportsDelivery: store?.supportsDelivery ?? false,
        supportsPickup: store?.supportsPickup ?? false,
      };
    }),
  );

  const preview: CheckoutPreview = {
    groups: groups.map(({ supportsDelivery: _d, supportsPickup: _p, ...rest }) => rest),
    addresses: addresses.map((a) => ({
      id: a.id, label: a.label, fullName: a.fullName, phone: a.phone,
      line1: a.line1, line2: a.line2, city: a.city, pincode: a.pincode, isDefault: a.isDefault,
    })),
    // An option is offered only if EVERY store in the cart can honour it.
    fulfillmentAvailable: {
      DELIVERY: groups.every((g) => g.supportsDelivery),
      PICKUP: groups.every((g) => g.supportsPickup),
    },
    subtotalPaise: cart.subtotalPaise,
    deliveryFeePaise: groups.reduce((s, g) => s + g.deliveryFeePaise, 0),
    grandTotalPaise: cart.subtotalPaise + groups.reduce((s, g) => s + g.deliveryFeePaise, 0),
    issues: cart.issues,
    hasBlockingIssues: cart.hasBlockingIssues,
  };

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader title="Checkout" description="Review your orders and choose how to receive them." />
        <CheckoutClient preview={preview} />
      </main>
    </div>
  );
}
