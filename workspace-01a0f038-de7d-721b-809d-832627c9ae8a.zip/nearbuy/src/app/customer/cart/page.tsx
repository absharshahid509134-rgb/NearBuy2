import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { CartViewClient } from "@/components/cart-view";
import { getCartView } from "@/server/services/cart";
import { requireWorkspace } from "@/server/guard";

export const metadata: Metadata = { title: "Your cart" };
export const dynamic = "force-dynamic";

export default async function CartPage() {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const cart = await getCartView(user.id);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title="Your cart"
          description={
            cart.itemCount > 0
              ? `${cart.itemCount} item${cart.itemCount === 1 ? "" : "s"} from ${cart.storeCount} store${cart.storeCount === 1 ? "" : "s"}.`
              : "Nothing here yet."
          }
        />
        <CartViewClient cart={cart} />
      </main>
    </div>
  );
}
