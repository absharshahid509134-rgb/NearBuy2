import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { listCustomerStockRequests } from "@/server/services/requests";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Stock checks" };
export const dynamic = "force-dynamic";

export default async function StockRequestsPage() {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const requests = await listCustomerStockRequests(user.id);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Stock checks"
          description="Ask a store whether an item is on the shelf. A stock check never holds anything."
        />

        {requests.length === 0 ? (
          <EmptyState
            title="No stock checks yet"
            description="Use “Check stock” on any product page to ask the store directly."
            icon="🔍"
            action={<Link href="/stores" className="btn-primary">Browse stores</Link>}
          />
        ) : (
          <ul className="space-y-3">
            {requests.map((r) => (
              <li key={r.id} className="card flex gap-3 p-4">
                <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                  <Thumb src={r.product.imageUrl} alt={r.product.name} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-semibold">{r.product.name}</p>
                    <StatusBadge status={r.status} />
                  </div>
                  <p className="mt-0.5 text-[13px] text-ink-500">
                    {r.store.name} · asked for {r.requestedQuantity} × {formatINR(r.product.pricePaise)} ·{" "}
                    {new Date(r.createdAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                  </p>
                  {r.sellerResponse ? (
                    <p className="mt-2 text-sm text-ink-700">
                      <span className="font-semibold">{r.store.name}:</span> {r.sellerResponse}
                    </p>
                  ) : (
                    <p className="mt-2 text-sm text-ink-600">Waiting for the store to respond.</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
