import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, Thumb } from "@/components/ui";
import { AddToCartButton } from "@/components/add-to-cart";
import { searchProducts } from "@/server/services/discovery";
import { searchQuerySchema } from "@/lib/validation";
import { formatINR } from "@/lib/money";
import { currentUser } from "@/server/session";

export const metadata: Metadata = { title: "Search products" };
export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const one = (k: string) => (Array.isArray(sp[k]) ? sp[k][0] : sp[k]);

  const input = searchQuerySchema.parse({
    q: one("q") ?? "",
    category: one("category"),
    minPrice: one("minPrice"),
    maxPrice: one("maxPrice"),
    inStock: one("inStock"),
    sort: one("sort") ?? "relevance",
    page: one("page") ?? "1",
  });

  const result = await searchProducts(input);
  const user = await currentUser();
  const isCustomer = user?.role === "CUSTOMER";

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader title="Search products" description="Live results straight from store inventory." />

        <form method="get" className="card flex flex-col gap-3 p-4 lg:flex-row lg:items-end">
          <div className="flex-1">
            <label htmlFor="q" className="label">Search</label>
            <input id="q" name="q" type="search" defaultValue={input.q} placeholder="Amul Taaza" className="input" />
          </div>
          <div className="lg:w-44">
            <label htmlFor="category" className="label">Category</label>
            <input id="category" name="category" defaultValue={input.category ?? ""} placeholder="Any" className="input" />
          </div>
          <div className="flex gap-2 lg:w-56">
            <div className="flex-1">
              <label htmlFor="minPrice" className="label">Min ₹</label>
              <input id="minPrice" name="minPrice" type="number" min={0} defaultValue={input.minPrice} className="input" />
            </div>
            <div className="flex-1">
              <label htmlFor="maxPrice" className="label">Max ₹</label>
              <input id="maxPrice" name="maxPrice" type="number" min={0} defaultValue={input.maxPrice} className="input" />
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 text-sm font-medium text-ink-700">
              <input type="checkbox" name="inStock" value="true" defaultChecked={input.inStock} className="h-4 w-4 rounded" />
              In stock only
            </label>
            <button type="submit" className="btn-primary">Search</button>
          </div>
        </form>

        <p className="mt-5 text-sm text-ink-600" aria-live="polite">
          {result.total} {result.total === 1 ? "result" : "results"}
          {input.q ? <> for “<strong className="text-ink-900">{input.q}</strong>”</> : null}
        </p>

        {result.items.length === 0 ? (
          <div className="mt-4">
            <EmptyState
              title="No products found"
              description="Try a different spelling, a wider price range, or browse stores instead."
              icon="🔍"
              action={<Link href="/stores" className="btn-secondary">Browse stores</Link>}
            />
          </div>
        ) : (
          <ul className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {result.items.map((p) => (
              <li key={p.id} className="card flex flex-col overflow-hidden">
                <Link href={`/stores/${p.store.slug}`} className="relative aspect-[4/3] w-full bg-ink-100">
                  <Thumb src={p.imageUrl} alt={p.name} category={p.category} />
                  {!p.inStock ? (
                    <span className="absolute inset-0 grid place-items-center bg-white/70 text-sm font-semibold text-ink-700">
                      Out of stock
                    </span>
                  ) : null}
                </Link>
                <div className="flex flex-1 flex-col p-4">
                  <Link href={`/stores/${p.store.slug}`} className="text-xs font-semibold uppercase tracking-wide text-brand-700 hover:underline">
                    {p.store.name}
                  </Link>
                  <h2 className="mt-1 font-semibold leading-snug">{p.name}</h2>
                  <p className="mt-1.5 line-clamp-2 flex-1 text-sm text-ink-600">{p.description}</p>
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="text-lg font-bold">{formatINR(p.pricePaise)}</span>
                    <span className="text-[13px] text-ink-500">per {p.unit}</span>
                  </div>
                  <p className="mt-1 text-[13px] text-ink-600">
                    {p.inStock ? `${p.stockQuantity} in stock` : "Currently unavailable"}
                  </p>
                  {isCustomer ? (
                    <div className="mt-3">
                      <AddToCartButton productId={p.id} compact />
                    </div>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
