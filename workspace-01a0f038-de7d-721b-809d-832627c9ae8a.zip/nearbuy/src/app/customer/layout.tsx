import type { ReactNode } from "react";
import { requireWorkspace } from "@/server/guard";

export const dynamic = "force-dynamic";

export default async function CustomerLayout({ children }: { children: ReactNode }) {
  await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  return <>{children}</>;
}
