import { redirect } from "next/navigation";

/** Store discovery is public; signed-in customers simply land on the same page. */
export default function CustomerStoresPage() {
  redirect("/stores");
}
