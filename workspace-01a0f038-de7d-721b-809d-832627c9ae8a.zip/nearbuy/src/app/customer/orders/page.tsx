import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { EmptyState, PageHeader, Alert } from "@/components/ui";
import { OrderCard } from "@/components/order-ui";
import { prisma } from "@/server/db";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";

export const metadata: Metadata = { title: "Your orders" };
export const dynamic = "force-dynamic";

const FILTERS = [
  { key: "ALL", label: "All" },
  { key: "PLACED", label: "New" },
  { key: "PREPARING", label: "Preparing" },
  { key: "OUT_FOR_DELIVERY", label: "On the way" },
  { key: "DELIVERED", label: "Delivered" },
];

export default async function CustomerOrdersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const sp = await searchParams;
  const one = (k: string) => (Array.isArray(sp[k]) ? sp[k][0] : sp[k]);
  const status = one("status") ?? "ALL";
  const justPlaced = one("placed");

  const orders = await prisma.order.findMany({
    where: {
      customerId: user.id,
      ...(status !== "ALL" ? { status } : {}),
    },
    include: {
      items: true,
      store: { select: { name: true } },
      deliveryJob: { select: { status: true } },
    },
    orderBy: { placedAt: "desc" },
    take: 60,
  });

  const active = orders.filter((o) => !["DELIVERED", "REJECTED", "CANCELLED"].includes(o.status));

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader title="Your orders" description={`${orders.length} order${orders.length === 1 ? "" : "s"}`} />

        {justPlaced ? (
          <div className="mb-4">
            <Alert tone="success">Order placed successfully. We’ll keep this page updated as it moves.</Alert>
          </div>
        ) : null}

        {active.length > 0 && status === "ALL" ? (
          <section className="mb-6">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-ink-500">On the way</h2>
            <div className="space-y-3">
              {active.map((o) => (
                <OrderCard
                  key={o.id}
                  href={`/customer/orders/${o.id}`}
                  orderNumber={o.orderNumber}
                  storeName={o.store.name}
                  status={o.status}
                  fulfillmentType={o.fulfillmentType}
                  totalPaise={o.totalPaise}
                  placedAt={o.placedAt}
                  itemSummary={
                    <span>
                      {o.items.map((i) => `${i.nameSnapshot} × ${i.quantity}`).join(", ")}
                    </span>
                  }
                />
              ))}
            </div>
          </section>
        ) : null}

        <div className="mb-4 flex flex-wrap gap-2">
          {FILTERS.map((f) => (
            <Link
              key={f.key}
              href={`/customer/orders?status=${f.key}`}
              aria-current={status === f.key ? "page" : undefined}
              className={`btn btn-sm ${status === f.key ? "bg-brand-600 text-white" : "bg-white text-ink-700 border border-ink-300 hover:bg-ink-100"}`}
            >
              {f.label}
            </Link>
          ))}
        </div>

        {orders.length === 0 ? (
          <EmptyState
            title={status === "ALL" ? "No orders yet" : "No orders with that status"}
            description={
              status === "ALL"
                ? "Once you place an order it will appear here, and you can follow it every step of the way."
                : "Try a different filter to see your other orders."
            }
            action={<Link href="/stores" className="btn-primary">Start shopping</Link>}
          />
        ) : (
          <div className="space-y-3">
            {orders.map((o) => (
              <OrderCard
                key={o.id}
                href={`/customer/orders/${o.id}`}
                orderNumber={o.orderNumber}
                storeName={o.store.name}
                status={o.status}
                fulfillmentType={o.fulfillmentType}
                totalPaise={o.totalPaise}
                placedAt={o.placedAt}
                itemSummary={<span>{o.items.map((i) => `${i.nameSnapshot} × ${i.quantity}`).join(", ")}</span>}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
