import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, HandoffCode, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { OrderTimeline } from "@/components/order-ui";
import { CancelOrderButton } from "@/components/order-actions";
import { loadOrderForActor, orderView } from "@/server/services/orders";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";
import { customerFacingStatus } from "@/lib/enums";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Order details" };

export default async function CustomerOrderPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const { id } = await params;

  // 404s (rather than 403) if the order belongs to somebody else.
  const raw = await loadOrderForActor(id, user);
  const order = orderView(raw, user);
  const canCancel = ["PLACED", "ACCEPTED", "PREPARING", "PACKED"].includes(order.status);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <Link href="/customer/orders" className="text-sm font-medium text-ink-600 hover:text-brand-700">
          ← All orders
        </Link>

        <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{order.orderNumber}</h1>
            <p className="mt-1 text-ink-600">
              {order.store.name} · placed{" "}
              {new Date(order.placedAt).toLocaleString("en-IN", {
                day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
              })}
            </p>
          </div>
          <StatusBadge status={order.status} />
        </div>

        <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_320px] lg:items-start">
          <div className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">
                {order.status === "DELIVERED"
                  ? "Delivered"
                  : `Status: ${customerFacingStatus(order.status as never)}`}
              </h2>
              <p className="mt-1.5 text-sm text-ink-600">
                {order.status === "PLACED" && "The store has your order and will accept it shortly."}
                {order.status === "ACCEPTED" && "The store accepted your order and will start preparing it."}
                {order.status === "PREPARING" && "The store is picking and packing your items."}
                {order.status === "PACKED" && "Your order is packed and nearly ready."}
                {order.status === "READY_FOR_PICKUP" && "Your order is ready. A rider will collect it shortly."}
                {order.status === "PICKED_UP" && "Your rider has collected the order and is on the way."}
                {order.status === "OUT_FOR_DELIVERY" && "Your rider is delivering right now."}
                {order.status === "DELIVERED" && `Completed. Payment of ${formatINR(order.totalPaise)} collected in cash.`}
                {order.status === "CANCELLED" && "This order was cancelled."}
                {order.status === "REJECTED" && "The store could not fulfil this order."}
              </p>

              {order.rider ? (
                <div className="mt-4 rounded-xl bg-ink-50 p-3.5">
                  <p className="text-[13px] text-ink-600">Your rider</p>
                  <p className="font-semibold">{order.rider.name}</p>
                </div>
              ) : null}

              {canCancel ? (
                <div className="mt-4">
                  <CancelOrderButton orderId={order.id} />
                </div>
              ) : null}
            </section>

            {/* The delivery code appears only once a rider actually has the
                order. The server enforces this; hiding it in the UI is a
                courtesy, not the control. */}
            {order.deliveryCode ? (
              <HandoffCode
                code={order.deliveryCode}
                label="Your delivery code"
                hint="Read this out to the rider when they hand over your order. Do not share it beforehand."
              />
            ) : order.status === "PICKED_UP" || order.status === "OUT_FOR_DELIVERY" ? (
              <Alert tone="info">Your delivery code appears here once your rider picks up the order.</Alert>
            ) : null}

            <section className="card overflow-hidden">
              <h2 className="border-b border-ink-200 px-5 py-4 font-bold">Items</h2>
              <ul className="divide-y divide-ink-100">
                {order.items.map((i) => (
                  <li key={i.id} className="flex items-center gap-3 p-4">
                    <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                      <Thumb src={i.imageUrlSnapshot} alt={i.nameSnapshot} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold leading-snug">{i.nameSnapshot}</p>
                      <p className="text-[13px] text-ink-500">
                        {formatINR(i.unitPricePaise)} × {i.quantity}
                      </p>
                    </div>
                    <p className="font-bold tabular-nums">{formatINR(i.lineTotalPaise)}</p>
                  </li>
                ))}
              </ul>
              <dl className="space-y-2 border-t border-ink-200 bg-ink-50 px-5 py-4 text-sm">
                <div className="flex justify-between">
                  <dt className="text-ink-600">Subtotal</dt>
                  <dd className="font-semibold tabular-nums">{formatINR(order.subtotalPaise)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-ink-600">Delivery</dt>
                  <dd className="font-semibold tabular-nums">
                    {order.deliveryFeePaise === 0 ? "Free (pickup)" : formatINR(order.deliveryFeePaise)}
                  </dd>
                </div>
                <div className="flex justify-between border-t border-ink-200 pt-2 text-base">
                  <dt className="font-bold">Total</dt>
                  <dd className="font-bold tabular-nums">{formatINR(order.totalPaise)}</dd>
                </div>
              </dl>
            </section>
          </div>

          <aside className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">
                {order.fulfillmentType === "PICKUP" ? "Collect from" : "Delivering to"}
              </h2>
              <address className="mt-2 text-sm not-italic text-ink-700">
                <span className="block font-semibold">{order.shipFullName}</span>
                <span className="block">{order.shipPhone}</span>
                <span className="mt-1 block">{order.shipLine1}</span>
                {order.shipLine2 ? <span className="block">{order.shipLine2}</span> : null}
                {order.shipLandmark ? <span className="block text-ink-500">Near {order.shipLandmark}</span> : null}
                <span className="block">{order.shipCity}, {order.shipState} {order.shipPincode}</span>
              </address>
              {order.fulfillmentType === "PICKUP" ? (
                <p className="mt-3 text-[13px] text-ink-600">
                  {order.store.addressLine1}, {order.store.city}
                </p>
              ) : null}
            </section>

            <section className="card p-5">
              <h2 className="font-bold">Payment</h2>
              <p className="mt-2 text-sm text-ink-700">
                Cash on delivery — {formatINR(order.totalPaise)}
              </p>
              <p className="mt-1 text-[13px] text-ink-500">
                {order.paymentStatus === "COLLECTED"
                  ? "Collected in cash."
                  : "Pay when your order arrives."}
              </p>
            </section>

            <section className="card p-5">
              <h2 className="font-bold">Progress</h2>
              <div className="mt-3">
                <OrderTimeline events={order.handoffEvents} />
              </div>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
}
