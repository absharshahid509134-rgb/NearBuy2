import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { PageHeader } from "@/components/ui";
import { AddressManager } from "@/components/address-manager";
import { prisma } from "@/server/db";
import { requireWorkspace } from "@/server/guard";

export const metadata: Metadata = { title: "Delivery addresses" };
export const dynamic = "force-dynamic";

export default async function AddressesPage() {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const addresses = await prisma.address.findMany({
    where: { customerId: user.id },
    orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
  });

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Delivery addresses"
          description="Used to estimate delivery distance and fee at checkout."
        />
        <AddressManager addresses={addresses} />
      </main>
    </div>
  );
}
