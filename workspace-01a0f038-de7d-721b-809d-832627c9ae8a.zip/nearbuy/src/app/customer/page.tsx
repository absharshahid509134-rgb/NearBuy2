import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, PageHeader, Stat, StatusBadge, Thumb } from "@/components/ui";
import { prisma } from "@/server/db";
import { requireWorkspace } from "@/server/guard";
import { getCartView } from "@/server/services/cart";
import { formatINR } from "@/lib/money";
import type { OrderStatus } from "@/lib/enums";

/** Order states that still need the customer or a rider to act. */
const ACTIVE_ORDER_STATUSES: OrderStatus[] = [
  "PLACED",
  "PREPARING",
  "READY_FOR_PICKUP",
  "OUT_FOR_DELIVERY",
];

export const metadata: Metadata = { title: "Your NearBuy home" };
export const dynamic = "force-dynamic";

const fmt = (iso: Date | string) =>
  new Date(iso).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

export default async function CustomerHomePage() {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");

  // Everything below is read straight from the database, so the home page
  // reflects the real persisted state after any refresh or re-login.
  const [cart, activeOrders, recentOrders, addressCount, savedProducts] = await Promise.all([
    getCartView(user.id),
    prisma.order.count({
      where: { customerId: user.id, status: { in: ACTIVE_ORDER_STATUSES } },
    }),
    prisma.order.findMany({
      where: { customerId: user.id },
      include: { items: true, store: { select: { name: true } }, deliveryJob: { select: { status: true } } },
      orderBy: { placedAt: "desc" },
      take: 5,
    }),
    prisma.address.count({ where: { customerId: user.id } }),
    prisma.product.count({ where: { status: "PUBLISHED", isAvailable: true, inventory: { stockQuantity: { gt: 0 } } } }),
  ]);

  const cartCount = cart.groups.reduce((n, g) => n + g.items.length, 0);
  const cartTotal = cart.subtotalPaise;

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        <PageHeader
          title={`Namaste, ${user.name.split(" ")[0]}`}
          description="Your neighbourhood shops, orders and cart — all saved to your account."
          action={
            <Link href="/customer/search" className="btn-primary">
              Browse shops
            </Link>
          }
        />

        <section className="mb-6">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Active orders" value={activeOrders} tone={activeOrders ? "accent" : "default"} href="/customer/orders" />
            <Stat label="In your cart" value={cartCount} href="/customer/cart" />
            <Stat label="Saved addresses" value={addressCount} tone={addressCount ? "default" : "warn"} href="/customer/addresses" />
            <Stat label="Products nearby" value={savedProducts} href="/customer/search" />
          </div>
        </section>

        {addressCount === 0 ? (
          <div className="mb-6">
            <Alert tone="warning">
              You have no delivery address saved yet, so delivery checkout will be blocked.{" "}
              <Link href="/customer/addresses" className="font-semibold underline">
                Add an address
              </Link>
            </Alert>
          </div>
        ) : null}

        <div className="grid gap-5 lg:grid-cols-[1fr_320px] lg:items-start">
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wide text-ink-500">Recent orders</h2>
              <Link href="/customer/orders" className="text-sm font-semibold text-brand-700 hover:underline">
                View all →
              </Link>
            </div>

            {recentOrders.length === 0 ? (
              <div className="card px-6 py-12 text-center">
                <p className="font-semibold">No orders yet</p>
                <p className="mx-auto mt-1 max-w-sm text-ink-600">
                  Add something to your cart from a nearby store and it will show up here.
                </p>
                <Link href="/customer/search" className="btn-primary mt-5">
                  Start shopping
                </Link>
              </div>
            ) : (
              <ul className="space-y-2">
                {recentOrders.map((o) => (
                  <li key={o.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <Link href={`/customer/orders/${o.id}`} className="font-semibold hover:text-brand-700 hover:underline">
                          {o.orderNumber}
                        </Link>
                        <StatusBadge status={o.status} />
                      </div>
                      <p className="mt-0.5 text-[13px] text-ink-500">
                        {o.store.name} · {o.items.length} item{o.items.length === 1 ? "" : "s"} · {fmt(o.placedAt)}
                      </p>
                    </div>
                    <p className="font-bold tabular-nums">{formatINR(o.totalPaise)}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <aside className="space-y-5">
            <section className="card p-5">
              <h2 className="font-bold">Your cart</h2>
              {cartCount === 0 ? (
                <>
                  <p className="mt-2 text-ink-600">Your cart is empty.</p>
                  <Link href="/customer/search" className="btn-secondary mt-4 w-full">
                    Browse shops
                  </Link>
                </>
              ) : (
                <>
                  <p className="mt-3 text-3xl font-bold tabular-nums text-brand-700">{formatINR(cartTotal)}</p>
                  <p className="mt-1 text-[13px] text-ink-500">
                    {cartCount} item{cartCount === 1 ? "" : "s"} across {cart.groups.length} store
                    {cart.groups.length === 1 ? "" : "s"}
                  </p>
                  <ul className="mt-4 space-y-2 border-t border-ink-200 pt-3">
                    {cart.groups.map((g) => (
                      <li key={g.store.id} className="flex items-center gap-2.5">
                        <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                          <Thumb src={g.items[0]?.imageUrl ?? null} alt={g.store.name} sizes="40px" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">{g.store.name}</p>
                          <p className="text-[13px] text-ink-500">
                            {g.items.length} item{g.items.length === 1 ? "" : "s"}
                          </p>
                        </div>
                        <p className="text-sm font-semibold tabular-nums">{formatINR(g.subtotalPaise)}</p>
                      </li>
                    ))}
                  </ul>
                  <Link href="/customer/cart" className="btn-primary mt-4 w-full">
                    Review cart
                  </Link>
                </>
              )}
            </section>

            <section className="card p-5">
              <h2 className="font-bold">Shortcuts</h2>
              <ul className="mt-3 space-y-1.5 text-sm">
                {[
                  { href: "/customer/orders", label: "Track my orders" },
                  { href: "/customer/addresses", label: "Saved addresses" },
                  { href: "/customer/reservations", label: "My reservations" },
                  { href: "/customer/stock-requests", label: "Stock requests" },
                  { href: "/customer/profile", label: "Profile & password" },
                ].map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-brand-700 hover:underline">
                      {l.label} →
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
}
