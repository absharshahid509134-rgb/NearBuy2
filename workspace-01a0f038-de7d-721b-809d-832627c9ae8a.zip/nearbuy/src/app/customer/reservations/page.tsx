import Link from "next/link";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/site-header";
import { Alert, EmptyState, PageHeader, StatusBadge, Thumb } from "@/components/ui";
import { CancelReservationButton } from "@/components/reservation-actions";
import { listCustomerReservations } from "@/server/services/requests";
import { requireWorkspace } from "@/server/guard";
import { formatINR } from "@/lib/money";
import { RESERVATION_STATUS_LABEL } from "@/lib/enums";

export const metadata: Metadata = { title: "Your reservations" };
export const dynamic = "force-dynamic";

export default async function ReservationsPage() {
  const user = await requireWorkspace("CUSTOMER", "/customer", "/customer/login");
  const reservations = await listCustomerReservations(user.id);

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main id="main" className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">
        <PageHeader
          title="Reservations"
          description="Ask a store to hold an item for you. Stock is only held once the store confirms and ticks “hold stock”."
        />

        {reservations.length === 0 ? (
          <EmptyState
            title="No reservations yet"
            description="Open a store and use “Reserve” on any item to ask them to keep it aside for you."
            icon="🔖"
            action={<Link href="/stores" className="btn-primary">Browse stores</Link>}
          />
        ) : (
          <ul className="space-y-3">
            {reservations.map((r) => (
              <li key={r.id} className="card p-4">
                <div className="flex gap-3">
                  <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-ink-100">
                    <Thumb src={r.product.imageUrl} alt={r.product.name} category={r.product.category} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold">{r.product.name}</p>
                      <StatusBadge status={r.status} />
                    </div>
                    <p className="mt-0.5 text-[13px] text-ink-500">
                      {r.store.name} · {r.requestedQuantity} × {formatINR(r.product.pricePaise)} ·{" "}
                      {new Date(r.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}
                    </p>

                    {r.sellerResponse ? (
                      <p className="mt-2 text-sm text-ink-700">
                        <span className="font-semibold">
                          {r.store.name} ({RESERVATION_STATUS_LABEL[r.status as never] ?? r.status}):
                        </span>{" "}
                        {r.sellerResponse}
                      </p>
                    ) : (
                      <p className="mt-2 text-sm text-ink-600">Waiting for the store to respond.</p>
                    )}

                    {/* Say plainly whether goods are actually being held. */}
                    {r.status === "CONFIRMED" ? (
                      <div className="mt-2">
                        {r.stockHeld ? (
                          <Alert tone="success">
                            Stock is genuinely held for you
                            {r.expiresAt
                              ? ` until ${new Date(r.expiresAt).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}`
                              : ""}
                            . It will not sell out.
                          </Alert>
                        ) : (
                          <Alert tone="warning">
                            The store confirmed but is not holding stock. Another shopper could buy it
                            first — consider checking out soon.
                          </Alert>
                        )}
                      </div>
                    ) : null}

                    {["PENDING", "CONFIRMED"].includes(r.status) ? (
                      <div className="mt-3">
                        <CancelReservationButton reservationId={r.id} />
                      </div>
                    ) : null}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
