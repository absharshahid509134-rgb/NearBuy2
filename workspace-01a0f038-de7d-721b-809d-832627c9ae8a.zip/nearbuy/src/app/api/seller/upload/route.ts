import { ok, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { badRequest } from "@/lib/errors";
import { storeImage } from "@/server/storage";
import { rateLimit } from "@/server/rate-limit";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const seller = await requireSeller();
  const limit = rateLimit(`upload:${seller.id}`, 120, 60 * 60 * 1000);
  if (!limit.ok) {
    return Response.json({ error: { code: "RATE_LIMITED", message: "Too many uploads. Please try again later." } }, { status: 429 });
  }
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) throw badRequest("Choose an image to upload.");
  const kind = form.get("kind") === "store" ? "store" : "products";
  const stored = await storeImage(file, `${kind}/${seller.id}`);
  return ok({ url: stored.url, key: stored.key }, { status: 201 });
}, "seller.upload");
