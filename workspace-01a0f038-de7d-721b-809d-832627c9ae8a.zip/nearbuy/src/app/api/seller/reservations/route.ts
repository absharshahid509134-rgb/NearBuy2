import { ok, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { listSellerReservations } from "@/server/services/requests";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (req: Request) => {
  const seller = await requireSeller();
  const status = new URL(req.url).searchParams.get("status") ?? undefined;
  return ok({ reservations: await listSellerReservations(seller.id, status) });
}, "seller.reservations.list");
