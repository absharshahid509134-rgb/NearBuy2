import { ok, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { listSellerStockRequests } from "@/server/services/requests";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (req: Request) => {
  const seller = await requireSeller();
  const status = new URL(req.url).searchParams.get("status") ?? undefined;
  return ok({ stockRequests: await listSellerStockRequests(seller.id, status) });
}, "seller.stockRequests.list");
