import { z } from "zod";
import { orderStatusSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { assertValidTransitionTarget, orderView, transitionOrder } from "@/server/services/orders";

export const runtime = "nodejs";

const sellerPatch = z.object({ status: orderStatusSchema.shape.status, reason: z.string().max(300).optional() });

/**
 * Seller-side order pipeline. Ownership and the state machine are re-checked
 * server-side, so a seller cannot touch another seller's order or skip ahead to
 * a status they are not allowed to set.
 */
export const POST = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  const { status, reason } = await parseJson(req, sellerPatch);
  const order = await transitionOrder(id, seller, assertValidTransitionTarget(status), { reason });
  return ok({ order: orderView(order, seller) });
}, "seller.orders.transition");
