import { ok, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { listActionItems, listSellerOrders } from "@/server/services/seller";
import { orderView } from "@/server/services/orders";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (req: Request) => {
  const seller = await requireSeller();
  const url = new URL(req.url);
  const view = url.searchParams.get("view");

  if (view === "action") {
    return ok(await listActionItems(seller.id));
  }

  const orders = await listSellerOrders(seller.id, url.searchParams.get("status") ?? undefined);
  return ok({ orders: orders.map((o) => orderView(o, seller)) });
}, "seller.orders.list");
