import { ok, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { sellerDashboard } from "@/server/services/seller";
import { expireStaleReservations } from "@/server/services/requests";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const seller = await requireSeller();
  // Opportunistic housekeeping: expired holds are released here so sellable
  // stock does not stay artificially low. A cron should also call this.
  await expireStaleReservations().catch(() => 0);
  return ok(await sellerDashboard(seller.id));
}, "seller.dashboard");
