import { productSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { createProduct, listSellerProducts } from "@/server/services/seller";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const seller = await requireSeller();
  return ok({ products: await listSellerProducts(seller.id) });
}, "seller.products.list");

/**
 * Accepts multipart (when a photo is included) or plain JSON. Two content
 * types because the browser form always has a file input, while scripts and
 * importers create products without one.
 */
export const POST = route(async (req: Request) => {
  const seller = await requireSeller();
  const contentType = req.headers.get("content-type") ?? "";

  let input: ReturnType<typeof productSchema.parse>;
  let imageUrl: string | null = null;

  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    const raw = Object.fromEntries(
      Array.from(form.entries()).filter(([, v]) => typeof v === "string") as Array<[string, string]>,
    );
    input = productSchema.parse(raw);
    const file = form.get("image");
    if (file instanceof File && file.size > 0) {
      const { storeImage } = await import("@/server/storage");
      imageUrl = (await storeImage(file, `products/${seller.id}`)).url;
    }
  } else {
    input = await parseJson(req, productSchema);
  }

  const product = await createProduct(seller.id, input, imageUrl);
  return ok({ product }, { status: 201 });
}, "seller.products.create");
