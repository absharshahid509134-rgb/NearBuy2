import { z } from "zod";
import { productPatchSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { archiveProduct, getSellerProduct, updateProduct } from "@/server/services/seller";

export const runtime = "nodejs";

export const GET = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  return ok({ product: await getSellerProduct(seller.id, id) });
}, "seller.products.get");

export const PATCH = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  const contentType = req.headers.get("content-type") ?? "";

  let input: z.infer<typeof productPatchSchema>;
  let imageUrl: string | undefined;

  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData();
    const raw = Object.fromEntries(
      Array.from(form.entries()).filter(([, v]) => typeof v === "string") as Array<[string, string]>,
    );
    input = productPatchSchema.parse(raw);
    const file = form.get("image");
    if (file instanceof File && file.size > 0) {
      const { storeImage } = await import("@/server/storage");
      imageUrl = (await storeImage(file, `products/${seller.id}`)).url;
    }
  } else {
    input = await parseJson(req, productPatchSchema);
  }

  const product = await updateProduct(seller.id, id, input, imageUrl);
  return ok({ product });
}, "seller.products.update");

/** Products are archived rather than deleted: order history references them. */
export const DELETE = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  return ok({ product: await archiveProduct(seller.id, id) });
}, "seller.products.archive");
