import { NextResponse } from "next/server";
import { prisma } from "@/server/db";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Liveness/readiness probe.
 *
 * Reports whether the process is alive and whether the database answers, but
 * never leaks connection strings, hostnames or versions. `ok` is what a load
 * balancer should poll.
 */
export async function GET() {
  const startedAt = Date.now();
  let database: "up" | "down" = "down";
  try {
    await prisma.$queryRaw`SELECT 1`;
    database = "up";
  } catch {
    database = "down";
  }

  const healthy = database === "up";
  return NextResponse.json(
    {
      status: healthy ? "ok" : "degraded",
      service: "nearbuy",
      version: process.env.npm_package_version ?? "1.0.0",
      environment: env().NODE_ENV,
      checks: {
        application: "up",
        database,
        storage: env().STORAGE_DRIVER === "s3" ? "configured" : "local",
      },
      latencyMs: Date.now() - startedAt,
      timestamp: new Date().toISOString(),
    },
    { status: healthy ? 200 : 503, headers: { "Cache-Control": "no-store" } },
  );
}
