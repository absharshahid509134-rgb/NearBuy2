import { ok, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { riderEarnings } from "@/server/services/rider";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const rider = await requireRider();
  return ok(await riderEarnings(rider.id));
}, "rider.earnings");
