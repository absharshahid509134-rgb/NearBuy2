import { riderProfileSchema, profileSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { prisma } from "@/server/db";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const rider = await requireRider();
  return ok({ profile: await prisma.riderProfile.findUnique({ where: { userId: rider.id } }) });
}, "rider.profile.get");

/** Completing onboarding flips isOnboarded once every required field is set. */
export const PATCH = route(async (req: Request) => {
  const rider = await requireRider();
  const input = await parseJson(req, riderProfileSchema);
  const profile = await prisma.riderProfile.upsert({
    where: { userId: rider.id },
    create: {
      userId: rider.id,
      vehicleType: input.vehicleType,
      vehicleNumber: input.vehicleNumber,
      onboardingStep: input.onboardingStep,
      isOnboarded: Boolean(input.vehicleNumber),
    },
    update: {
      vehicleType: input.vehicleType,
      vehicleNumber: input.vehicleNumber,
      onboardingStep: input.onboardingStep,
      isOnboarded: true,
    },
  });
  return ok({ profile });
}, "rider.profile.update");
