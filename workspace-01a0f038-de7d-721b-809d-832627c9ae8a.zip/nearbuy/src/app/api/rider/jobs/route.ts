import { ok, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { listAvailableJobs, listRiderJobs } from "@/server/services/rider";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** The rider's whole world: the shared pool, plus their own active + done jobs. */
export const GET = route(async (req: Request) => {
  const rider = await requireRider();
  const url = new URL(req.url);
  const view = url.searchParams.get("view");

  if (view === "available") {
    return ok({ jobs: await listAvailableJobs(rider.id, 50) });
  }
  const { active, completed } = await listRiderJobs(rider.id);
  return ok({ active, completed, jobs: await listAvailableJobs(rider.id, 50) });
}, "rider.jobs.list");
