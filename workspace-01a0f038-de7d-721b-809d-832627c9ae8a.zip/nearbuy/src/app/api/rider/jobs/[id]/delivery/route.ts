import { ok, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { startDelivery } from "@/server/services/rider";

export const runtime = "nodejs";

export const POST = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const rider = await requireRider();
  const { id } = await ctx.params;
  return ok({ order: await startDelivery(id, rider.id) });
}, "rider.jobs.startDelivery");
