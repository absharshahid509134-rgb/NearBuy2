import { jobActionSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { verifyDelivery } from "@/server/services/rider";

export const runtime = "nodejs";

/** The customer reads out their delivery code; the rider submits it here. */
export const POST = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const rider = await requireRider();
  const { id } = await ctx.params;
  const { code } = await parseJson(req, jobActionSchema);
  if (!code) {
    return Response.json(
      { error: { code: "VALIDATION", message: "Enter the 6-digit delivery code the customer gives you." } },
      { status: 400 },
    );
  }
  return ok({ order: await verifyDelivery(id, rider.id, code) });
}, "rider.jobs.complete");
