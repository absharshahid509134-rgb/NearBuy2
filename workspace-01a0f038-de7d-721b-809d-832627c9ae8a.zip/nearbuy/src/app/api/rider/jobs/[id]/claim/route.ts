import { ok, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { claimJob } from "@/server/services/rider";

export const runtime = "nodejs";

export const POST = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const rider = await requireRider();
  const { id } = await ctx.params;
  // The atomic compare-and-swap lives in the service; a lost race surfaces as
  // a 409 with a message written for a human rider.
  return ok({ job: await claimJob(id, rider.id) });
}, "rider.jobs.claim");
