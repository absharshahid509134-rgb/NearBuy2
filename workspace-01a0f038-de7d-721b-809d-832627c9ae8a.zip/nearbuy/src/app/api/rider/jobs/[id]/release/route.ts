import { ok, route } from "@/server/api";
import { requireRider } from "@/server/auth";
import { releaseJob } from "@/server/services/rider";

export const runtime = "nodejs";

export const POST = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const rider = await requireRider();
  const { id } = await ctx.params;
  return ok(await releaseJob(id, rider.id));
}, "rider.jobs.release");
