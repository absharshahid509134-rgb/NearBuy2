import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { env } from "@/lib/env";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CONTENT_TYPES: Record<string, string> = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png",
  webp: "image/webp", avif: "image/avif", gif: "image/gif",
};

/**
 * Serves locally-stored uploads in development. In production STORAGE_DRIVER
 * is forced to s3 and this route is never used.
 *
 * The key is resolved and then re-checked against the uploads root, so a
 * traversal attempt like `../../.env` cannot escape it.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ key: string[] }> }) {
  if (env().STORAGE_DRIVER === "s3") {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Not found." } }, { status: 404 });
  }
  const { key } = await ctx.params;
  const root = path.resolve(process.cwd(), ".uploads");
  const target = path.resolve(root, key.join(path.sep));

  if (!target.startsWith(root + path.sep)) {
    return NextResponse.json({ error: { code: "FORBIDDEN", message: "Invalid path." } }, { status: 403 });
  }

  try {
    const data = await readFile(target);
    const ext = path.extname(target).slice(1).toLowerCase();
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "Content-Type": CONTENT_TYPES[ext] ?? "application/octet-stream",
        "Cache-Control": "public, max-age=31536000, immutable",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Not found." } }, { status: 404 });
  }
}
