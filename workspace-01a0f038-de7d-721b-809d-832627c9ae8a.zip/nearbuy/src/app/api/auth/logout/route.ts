import { cookies } from "next/headers";
import { ok, route } from "@/server/api";
import {
  clearedCookieOptions,
  destroySession,
  readTokenFromCookieHeader,
  SESSION_COOKIE,
} from "@/server/session";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const token = readTokenFromCookieHeader(req.headers.get("cookie"));
  // Deleting the server-side row is what makes logout real; clearing the
  // cookie alone would leave a valid token in the attacker's hands.
  if (token) await destroySession(token);
  (await cookies()).set(SESSION_COOKIE, "", clearedCookieOptions());
  return ok({ signedOut: true });
}, "auth.logout");
