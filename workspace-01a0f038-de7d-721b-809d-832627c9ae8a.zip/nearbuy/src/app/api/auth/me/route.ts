import { ok, route } from "@/server/api";
import { currentUser } from "@/server/session";
import { prisma } from "@/server/db";
import { handleError } from "@/server/api";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const user = await currentUser();
    if (!user) return ok({ user: null });

    const [store, riderProfile, cartCount] = await Promise.all([
      user.role === "SELLER"
        ? prisma.store.findUnique({
            where: { sellerId: user.id },
            select: { id: true, name: true, status: true, slug: true, isOpen: true },
          })
        : null,
      user.role === "RIDER"
        ? prisma.riderProfile.findUnique({ where: { userId: user.id } })
        : null,
      user.role === "CUSTOMER"
        ? prisma.cartItem.aggregate({
            where: { cart: { customerId: user.id } },
            _sum: { quantity: true },
          })
        : null,
    ]);

    return ok({
      user,
      store,
      riderProfile: riderProfile
        ? {
            isOnboarded: riderProfile.isOnboarded,
            vehicleType: riderProfile.vehicleType,
            vehicleNumber: riderProfile.vehicleNumber,
            onboardingStep: riderProfile.onboardingStep,
          }
        : null,
      cartQuantity: cartCount?._sum.quantity ?? 0,
    });
  } catch (e) {
    return handleError(e, "auth.me");
  }
}
