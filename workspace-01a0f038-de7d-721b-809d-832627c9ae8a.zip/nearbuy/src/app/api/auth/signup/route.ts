import { cookies } from "next/headers";
import { signupSchema } from "@/lib/validation";
import { getClientIp, ok, parseJson, route } from "@/server/api";
import { signup } from "@/server/services/auth";
import { createSession, SESSION_COOKIE, sessionCookieOptions } from "@/server/session";
import { rateLimit } from "@/server/rate-limit";
import { env } from "@/lib/env";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const ip = getClientIp(req);
  // Signup is a write amplifier, so it is limited per-IP as well as globally.
  const limit = rateLimit(`signup:${ip}`, env().SIGNUP_RATE_LIMIT, 60 * 60 * 1000);
  if (!limit.ok) {
    return Response.json(
      { error: { code: "RATE_LIMITED", message: "Too many accounts created from this network. Please try again later." } },
      { status: 429, headers: { "Retry-After": String(limit.retryAfterSeconds) } },
    );
  }

  const input = await parseJson(req, signupSchema);
  const user = await signup(input);
  const { token, expiresAt } = await createSession(user.userId, {
    userAgent: req.headers.get("user-agent") ?? undefined,
    ip,
  });
  (await cookies()).set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return ok({ user }, { status: 201 });
}, "auth.signup");
