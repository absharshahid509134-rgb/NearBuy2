import { cookies } from "next/headers";
import { loginSchema } from "@/lib/validation";
import { getClientIp, ok, parseJson, route } from "@/server/api";
import { login } from "@/server/services/auth";
import { createSession, SESSION_COOKIE, sessionCookieOptions } from "@/server/session";
import { rateLimit } from "@/server/rate-limit";
import { env } from "@/lib/env";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const ip = getClientIp(req);

  // The body is a stream and can only be read once. Rate limiting needs the
  // email before validation runs, so parse it here and hand the already-parsed
  // value to the schema — calling req.json() a second time (as an earlier
  // version of this route did) throws and breaks every successful sign-in.
  const raw = await req.json().catch(() => null);
  const email =
    raw && typeof raw === "object" && typeof (raw as { email?: unknown }).email === "string"
      ? ((raw as { email: string }).email.toLowerCase().trim())
      : "unknown";

  const limit = rateLimit(`login:${ip}:${email}`, env().LOGIN_RATE_LIMIT, 15 * 60 * 1000);
  const broad = rateLimit(`login:${ip}`, 30, 15 * 60 * 1000);
  if (!limit.ok || !broad.ok) {
    return Response.json(
      { error: { code: "RATE_LIMITED", message: "Too many sign-in attempts. Please wait a few minutes and try again." } },
      { status: 429, headers: { "Retry-After": String(Math.max(limit.retryAfterSeconds, broad.retryAfterSeconds)) } },
    );
  }

  const input = loginSchema.parse(raw);
  const user = await login(input);
  const { token, expiresAt } = await createSession(user.userId, {
    userAgent: req.headers.get("user-agent") ?? undefined,
    ip,
  });
  (await cookies()).set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return ok({ user });
}, "auth.login");
