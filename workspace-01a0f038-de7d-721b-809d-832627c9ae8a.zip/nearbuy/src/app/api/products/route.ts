import { searchQuerySchema } from "@/lib/validation";
import { ok, route } from "@/server/api";
import { searchProducts } from "@/server/services/discovery";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (req: Request) => {
  const url = new URL(req.url);
  const input = searchQuerySchema.parse(Object.fromEntries(url.searchParams));
  return ok(await searchProducts(input));
}, "products.search");
