import { cartAddSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { addToCart } from "@/server/services/cart";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const user = await requireCustomer();
  const { productId, quantity } = await parseJson(req, cartAddSchema);
  return ok(await addToCart(user.id, productId, quantity));
}, "cart.add");
