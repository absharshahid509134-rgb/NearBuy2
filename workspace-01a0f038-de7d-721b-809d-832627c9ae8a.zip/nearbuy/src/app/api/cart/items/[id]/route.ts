import { cartUpdateSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { removeCartItem, updateCartItem } from "@/server/services/cart";

export const runtime = "nodejs";

export const PATCH = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireCustomer();
  const { id } = await ctx.params;
  const { quantity } = await parseJson(req, cartUpdateSchema);
  return ok(await updateCartItem(user.id, id, quantity));
}, "cart.update");

export const DELETE = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireCustomer();
  const { id } = await ctx.params;
  return ok(await removeCartItem(user.id, id));
}, "cart.remove");
