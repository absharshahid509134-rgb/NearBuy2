import { ok, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { getCartView } from "@/server/services/cart";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const user = await requireCustomer();
  return ok(await getCartView(user.id));
}, "cart.get");
