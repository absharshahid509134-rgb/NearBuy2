import { ok, route } from "@/server/api";
import { requireUser } from "@/server/auth";
import { prisma } from "@/server/db";
import { orderView } from "@/server/services/orders";
import { listAvailableJobs } from "@/server/services/rider";
import { getSellerStore } from "@/server/services/seller";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/** One order list per role, each scoped to exactly the rows that role owns. */
export const GET = route(async (req: Request) => {
  const user = await requireUser();
  const url = new URL(req.url);
  const status = url.searchParams.get("status") ?? undefined;
  const take = Math.min(Number(url.searchParams.get("take") ?? 50), 100);

  if (user.role === "CUSTOMER") {
    const orders = await prisma.order.findMany({
      where: { customerId: user.id, ...(status && status !== "ALL" ? { status } : {}) },
      include: {
        items: true,
        store: { select: { id: true, name: true, city: true, slug: true, addressLine1: true, sellerId: true } },
        deliveryJob: { select: { id: true, status: true } },
      },
      orderBy: { placedAt: "desc" },
      take,
    });
    return ok({ orders: orders.map((o) => orderView(o, user)) });
  }

  if (user.role === "SELLER") {
    const store = await getSellerStore(user.id);
    if (!store) return ok({ orders: [] });
    const orders = await prisma.order.findMany({
      where: { storeId: store.id, ...(status && status !== "ALL" ? { status } : {}) },
      include: {
        items: true,
        store: { select: { id: true, name: true, city: true, slug: true, addressLine1: true, sellerId: true } },
        customer: { select: { id: true, name: true, phone: true } },
        deliveryJob: { select: { id: true, status: true, riderId: true } },
        handoffEvents: { orderBy: { createdAt: "asc" } },
      },
      orderBy: { placedAt: "desc" },
      take,
    });
    return ok({ orders: orders.map((o) => orderView(o, user)) });
  }

  // Riders read their assigned jobs rather than raw order rows.
  const jobs = await listAvailableJobs(user.id, take);
  const mine = await prisma.order.findMany({
    where: { riderId: user.id },
    include: {
      items: true,
      store: { select: { id: true, name: true, city: true, slug: true, addressLine1: true, sellerId: true } },
      deliveryJob: { select: { id: true, status: true } },
    },
    orderBy: { placedAt: "desc" },
    take,
  });
  return ok({ orders: mine.map((o) => orderView(o, user)), availableJobs: jobs });
}, "orders.list");
