import { orderStatusSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireUser } from "@/server/auth";
import { assertValidTransitionTarget, loadOrderForActor, orderView, transitionOrder } from "@/server/services/orders";

export const runtime = "nodejs";

/**
 * Role-agnostic status endpoint. It is safe to expose one route because
 * `transitionOrder` re-checks ownership and the state machine on every call —
 * a rider POSTing ACCEPTED still gets 403, not a moved order.
 */
export const POST = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const { status } = await parseJson(req, orderStatusSchema);
  const order = await transitionOrder(id, user, assertValidTransitionTarget(status), {
    reason: req.headers.get("x-reason") ?? undefined,
  });
  return ok({ order: orderView(order, user) });
}, "orders.transition");
