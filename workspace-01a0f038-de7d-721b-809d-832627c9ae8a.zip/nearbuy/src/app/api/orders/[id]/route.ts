import { ok, route } from "@/server/api";
import { requireUser } from "@/server/auth";
import { loadOrderForActor, orderView } from "@/server/services/orders";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const order = await loadOrderForActor(id, user);
  // Handoff codes are injected here and only here, per viewer and per stage.
  return ok({ order: orderView(order, user) });
}, "orders.detail");
