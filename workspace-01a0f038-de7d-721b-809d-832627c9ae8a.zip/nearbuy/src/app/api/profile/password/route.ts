import { z } from "zod";
import { passwordSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireUser } from "@/server/auth";
import { changePassword } from "@/server/services/auth";
import { cookies } from "next/headers";
import { clearedCookieOptions, SESSION_COOKIE } from "@/server/session";
import { rateLimit } from "@/server/rate-limit";

export const runtime = "nodejs";

const schema = z.object({
  currentPassword: z.string().min(1, "Enter your current password"),
  newPassword: passwordSchema,
});

export const POST = route(async (req: Request) => {
  const user = await requireUser();
  const limit = rateLimit(`pwchange:${user.id}`, 5, 60 * 60 * 1000);
  if (!limit.ok) {
    return Response.json(
      { error: { code: "RATE_LIMITED", message: "Too many password changes. Try again later." } },
      { status: 429 },
    );
  }
  const { currentPassword, newPassword } = await parseJson(req, schema);
  await changePassword(user.id, currentPassword, newPassword);
  // changePassword drops every session, including the one making this call.
  (await cookies()).set(SESSION_COOKIE, "", clearedCookieOptions());
  return ok({ changed: true });
}, "profile.password");
