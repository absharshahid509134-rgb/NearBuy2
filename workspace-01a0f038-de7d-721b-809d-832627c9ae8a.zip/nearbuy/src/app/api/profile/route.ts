import { profileSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireUser } from "@/server/auth";
import { prisma } from "@/server/db";

export const runtime = "nodejs";

/** Any signed-in role can edit their own name and phone — nothing else. */
export const PATCH = route(async (req: Request) => {
  const user = await requireUser();
  const input = await parseJson(req, profileSchema);
  const updated = await prisma.user.update({
    where: { id: user.id },
    data: { name: input.name, phone: input.phone || null },
    select: { id: true, name: true, email: true, phone: true, role: true },
  });
  return ok({ user: updated });
}, "profile.update");
