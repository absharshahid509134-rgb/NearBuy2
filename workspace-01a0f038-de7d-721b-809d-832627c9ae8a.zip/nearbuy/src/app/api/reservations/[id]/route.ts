import { ok, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { cancelReservation } from "@/server/services/requests";

export const runtime = "nodejs";

export const DELETE = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireCustomer();
  const { id } = await ctx.params;
  const reservation = await cancelReservation(user.id, id);
  return ok({ reservation });
}, "reservations.cancel");
