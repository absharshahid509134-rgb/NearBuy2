import { reservationRespondSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { respondToReservation } from "@/server/services/requests";

export const runtime = "nodejs";

export const POST = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  const { status, response, holdStock } = await parseJson(req, reservationRespondSchema);
  const reservation = await respondToReservation(seller.id, id, status, response, holdStock);
  return ok({ reservation });
}, "reservations.respond");
