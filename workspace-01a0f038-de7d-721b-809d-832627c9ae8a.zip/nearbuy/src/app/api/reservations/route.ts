import { reservationSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { createReservation, listCustomerReservations } from "@/server/services/requests";
import { rateLimit } from "@/server/rate-limit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const user = await requireCustomer();
  return ok({ reservations: await listCustomerReservations(user.id) });
}, "reservations.list");

export const POST = route(async (req: Request) => {
  const user = await requireCustomer();
  const limit = rateLimit(`reservation:${user.id}`, 30, 60 * 60 * 1000);
  if (!limit.ok) {
    return Response.json({ error: { code: "RATE_LIMITED", message: "Too many requests. Please try again later." } }, { status: 429 });
  }
  const { productId, quantity } = await parseJson(req, reservationSchema);
  const reservation = await createReservation(user.id, productId, quantity);
  return ok({ reservation }, { status: 201 });
}, "reservations.create");
