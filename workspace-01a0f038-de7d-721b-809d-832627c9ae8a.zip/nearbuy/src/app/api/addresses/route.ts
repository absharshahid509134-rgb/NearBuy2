import { addressSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { prisma } from "@/server/db";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const user = await requireCustomer();
  const addresses = await prisma.address.findMany({
    where: { customerId: user.id },
    orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
  });
  return ok({ addresses });
}, "addresses.list");

export const POST = route(async (req: Request) => {
  const user = await requireCustomer();
  const input = await parseJson(req, addressSchema);

  const count = await prisma.address.count({ where: { customerId: user.id } });
  if (count >= 10) throw new Error("too many");

  // First address is always the default, and clearing the old one and setting
  // the new one happens in one transaction so there is never a moment with two.
  return ok(
    await prisma.$transaction(async (tx) => {
      if (input.isDefault || count === 0) {
        await tx.address.updateMany({ where: { customerId: user.id }, data: { isDefault: false } });
      }
      return tx.address.create({ data: { ...input, customerId: user.id } });
    }),
    { status: 201 },
  );
}, "addresses.create");
