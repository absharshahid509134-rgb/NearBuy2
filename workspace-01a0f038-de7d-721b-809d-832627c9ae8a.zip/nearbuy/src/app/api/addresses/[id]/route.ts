import { z } from "zod";
import { addressPatchSchema } from "@/lib/validation";
import { badRequest, notFound } from "@/lib/errors";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { prisma } from "@/server/db";

export const runtime = "nodejs";

/** Every field is optional on edit, but each one that is present is validated. */
// Schema imported from validation.ts so it stays in one place.

export const PATCH = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireCustomer();
  const { id } = await ctx.params;
  const existing = await prisma.address.findFirst({ where: { id, customerId: user.id } });
  if (!existing) throw notFound("We couldn't find that address.");
  const input = await parseJson(req, addressPatchSchema);
  const address = await prisma.$transaction(async (tx) => {
    if (input.isDefault) {
      await tx.address.updateMany({ where: { customerId: user.id }, data: { isDefault: false } });
    }
    return tx.address.update({ where: { id }, data: input });
  });
  return ok({ address });
}, "addresses.update");

export const DELETE = route(async (_req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const user = await requireCustomer();
  const { id } = await ctx.params;
  const existing = await prisma.address.findFirst({ where: { id, customerId: user.id } });
  if (!existing) throw notFound("We couldn't find that address.");
  await prisma.address.delete({ where: { id } });

  // Never leave a customer with zero addresses — the default checkout needs one.
  const remaining = await prisma.address.findMany({
    where: { customerId: user.id },
    orderBy: { createdAt: "asc" },
    take: 1,
  });
  if (remaining.length && !remaining[0].isDefault) {
    await prisma.address.update({ where: { id: remaining[0].id }, data: { isDefault: true } });
  }
  return ok({ deleted: true });
}, "addresses.delete");
