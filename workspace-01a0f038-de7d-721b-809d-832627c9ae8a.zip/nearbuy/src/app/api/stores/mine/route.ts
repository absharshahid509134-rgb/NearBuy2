import { notFound } from "@/lib/errors";
import { storePatchSchema, storeSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { createStore, getSellerStore, updateStore } from "@/server/services/seller";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const seller = await requireSeller();
  return ok({ store: await getSellerStore(seller.id) });
}, "seller.store.get");

export const POST = route(async (req: Request) => {
  const seller = await requireSeller();
  const input = await parseJson(req, storeSchema);
  return ok({ store: await createStore(seller.id, input) }, { status: 201 });
}, "seller.store.create");

export const PUT = route(async (req: Request) => {
  const seller = await requireSeller();
  const input = await parseJson(req, storePatchSchema);
  const store = await getSellerStore(seller.id);
  if (!store) throw notFound("Create your store first.");
  return ok({ store: await updateStore(seller.id, store.id, input) });
}, "seller.store.update");
