import { notFound } from "@/lib/errors";
import { ok, route } from "@/server/api";
import { getStoreBySlug } from "@/server/services/discovery";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async (_req: Request, ctx: { params: Promise<{ slug: string }> }) => {
  const { slug } = await ctx.params;
  const store = await getStoreBySlug(slug);
  if (!store) throw notFound("We couldn't find that store.");
  return ok({ store });
}, "stores.detail");
