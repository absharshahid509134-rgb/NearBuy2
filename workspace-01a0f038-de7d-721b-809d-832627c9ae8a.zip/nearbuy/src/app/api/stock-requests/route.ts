import { stockRequestSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { createStockRequest, listCustomerStockRequests } from "@/server/services/requests";
import { rateLimit } from "@/server/rate-limit";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => {
  const user = await requireCustomer();
  return ok({ stockRequests: await listCustomerStockRequests(user.id) });
}, "stockRequests.list");

export const POST = route(async (req: Request) => {
  const user = await requireCustomer();
  const limit = rateLimit(`stockreq:${user.id}`, 60, 60 * 60 * 1000);
  if (!limit.ok) {
    return Response.json({ error: { code: "RATE_LIMITED", message: "Too many requests. Please try again later." } }, { status: 429 });
  }
  const { productId, quantity } = await parseJson(req, stockRequestSchema);
  const stockRequest = await createStockRequest(user.id, productId, quantity);
  return ok({ stockRequest }, { status: 201 });
}, "stockRequests.create");
