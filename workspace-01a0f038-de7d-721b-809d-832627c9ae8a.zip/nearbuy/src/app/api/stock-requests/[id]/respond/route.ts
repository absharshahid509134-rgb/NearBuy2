import { stockRequestRespondSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireSeller } from "@/server/auth";
import { respondToStockRequest } from "@/server/services/requests";

export const runtime = "nodejs";

export const POST = route(async (req: Request, ctx: { params: Promise<{ id: string }> }) => {
  const seller = await requireSeller();
  const { id } = await ctx.params;
  const { status, response } = await parseJson(req, stockRequestRespondSchema);
  const stockRequest = await respondToStockRequest(seller.id, id, status, response);
  return ok({ stockRequest });
}, "stockRequests.respond");
