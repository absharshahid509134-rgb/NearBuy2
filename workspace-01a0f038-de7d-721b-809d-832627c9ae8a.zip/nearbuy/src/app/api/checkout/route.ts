import { checkoutSchema } from "@/lib/validation";
import { ok, parseJson, route } from "@/server/api";
import { requireCustomer } from "@/server/auth";
import { checkout } from "@/server/services/checkout";
import { rateLimit } from "@/server/rate-limit";

export const runtime = "nodejs";

export const POST = route(async (req: Request) => {
  const user = await requireCustomer();

  // Cheap brake on accidental submit loops. It is not the real duplicate
  // guard — the unique (customerId, idempotencyKey) index is.
  const limit = rateLimit(`checkout:${user.id}`, 30, 60_000);
  if (!limit.ok) {
    return Response.json(
      { error: { code: "RATE_LIMITED", message: "Too many checkout attempts. Please wait a moment." } },
      { status: 429 },
    );
  }

  const input = await parseJson(req, checkoutSchema);
  const result = await checkout(user.id, input);
  return ok(result, { status: result.idempotentReplay ? 200 : 201 });
}, "checkout.create");
