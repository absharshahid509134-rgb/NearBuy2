import { ok, route } from "@/server/api";
import { getCategoriesWithCounts, CATEGORIES } from "@/server/services/discovery";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const GET = route(async () => ok({ categories: await getCategoriesWithCounts(), all: CATEGORIES }), "categories");
