import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AppError } from "@/lib/errors";
import { log } from "./logger";

/** Every API response in NearBuy is this shape, so the client has one parser. */
export interface ApiError {
  error: { code: string; message: string; details?: Record<string, unknown> };
}

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ data }, init);
}

export function fail(
  status: number,
  code: string,
  message: string,
  details?: Record<string, unknown>,
) {
  return NextResponse.json({ error: { code, message, details } }, { status });
}

/**
 * The single place an exception becomes a response.
 *
 * Known AppErrors keep their message, because someone wrote that copy on
 * purpose for a human. Everything else is an unexpected fault: it is logged
 * with a request id and reported as a generic message, so stack traces, SQL
 * and internal identifiers never reach the client.
 */
export function handleError(e: unknown, context: string) {
  if (e instanceof AppError) {
    if (e.status >= 500) log.error(context, { code: e.code, message: e.message });
    else log.info(context, { code: e.code, status: e.status });
    return fail(e.status, e.code, e.message, e.details);
  }

  if (e instanceof ZodError) {
    const details: Record<string, string> = {};
    for (const issue of e.issues) {
      details[issue.path.join(".") || "form"] = issue.message;
    }
    return fail(400, "VALIDATION", "Please check the highlighted fields.", details);
  }

  const requestId = Math.random().toString(36).slice(2, 10);
  log.error(context, {
    requestId,
    message: e instanceof Error ? e.message : String(e),
    stack: e instanceof Error ? e.stack?.split("\n").slice(0, 6).join(" | ") : undefined,
  });
  return fail(
    500,
    "INTERNAL",
    "Something went wrong on our side. Please try again in a moment.",
    { requestId },
  );
}

/** Async route wrapper so handlers can `throw` freely. */
export function route<A extends unknown[]>(
  fn: (...args: A) => Promise<Response>,
  context: string,
) {
  return (...args: A) => fn(...args).catch((e) => handleError(e, context));
}

export async function parseJson<T>(req: Request, schema: { parse: (v: unknown) => T }): Promise<T> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new AppError(400, "BAD_JSON", "That request could not be read as JSON.");
  }
  return schema.parse(raw);
}

export function getClientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}
