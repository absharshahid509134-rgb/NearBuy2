import "server-only";
import { prisma } from "@/server/db";
import { badRequest, conflict, notFound } from "@/lib/errors";
import { log } from "@/server/logger";

/* ------------------------------------------------------- stock checking -- */

/**
 * A stock check is a question, not a transaction. It never moves stock and it
 * must never be presented as a hold — a CONFIRMED response means "yes, we had
 * it when you asked", nothing more.
 */
export async function createStockRequest(
  customerId: string,
  productId: string,
  quantity: number,
) {
  const product = await prisma.product.findUnique({
    where: { id: productId },
    include: { store: { select: { id: true, status: true } } },
  });
  if (!product) throw notFound("We couldn't find that product.");
  if (product.store.status !== "PUBLISHED") {
    throw conflict("This product is no longer listed.");
  }

  const open = await prisma.stockRequest.findFirst({
    where: { customerId, productId, status: "PENDING" },
  });
  if (open) throw conflict("You already have an open stock check for this item.");

  return prisma.stockRequest.create({
    data: { customerId, productId, storeId: product.store.id, requestedQuantity: quantity },
    include: { product: { select: { name: true, imageUrl: true } }, store: { select: { name: true } } },
  });
}

export async function listCustomerStockRequests(customerId: string) {
  return prisma.stockRequest.findMany({
    where: { customerId },
    include: {
      product: { select: { id: true, name: true, imageUrl: true, unit: true, pricePaise: true, category: true } },
      store: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function respondToStockRequest(
  sellerId: string,
  requestId: string,
  status: "CONFIRMED" | "UNAVAILABLE",
  response?: string,
) {
  const request = await prisma.stockRequest.findFirst({
    where: { id: requestId, store: { sellerId } },
  });
  if (!request) throw notFound("We couldn't find that stock request, or it isn't yours to answer.");
  if (request.status !== "PENDING") {
    throw conflict("You have already answered this stock check.");
  }
  if (status === "CONFIRMED") {
    // Be honest at reply time: if the shelf cannot cover the ask, say so.
    const inv = await prisma.inventory.findUnique({ where: { productId: request.productId } });
    const available = (inv?.stockQuantity ?? 0) - (inv?.reservedQuantity ?? 0);
    if (available < request.requestedQuantity) {
      throw conflict(
        `You only have ${available} in sellable stock right now. Mark it unavailable or restock first.`,
      );
    }
  }
  return prisma.stockRequest.update({
    where: { id: requestId },
    data: { status, sellerResponse: response ?? null, sellerRespondedAt: new Date() },
  });
}

/* ------------------------------------------------------------ reservations -- */

/**
 * Reservations can be answered in two distinct ways, and the product refuses
 * to blur them:
 *
 *  holdStock = false -> CONFIRMED means "yes, we'll keep one aside informally".
 *                       Nothing in the database reserves stock.
 *  holdStock = true  -> CONFIRMED physically increments `reservedQuantity`,
 *                       reducing sellable stock until it is released.
 *
 * `stockHeld` on the row records which of the two actually happened, and the
 * customer UI reads that field rather than assuming.
 */
export async function createReservation(
  customerId: string,
  productId: string,
  quantity: number,
) {
  const product = await prisma.product.findUnique({
    where: { id: productId },
    include: { store: { select: { id: true, status: true } } },
  });
  if (!product) throw notFound("We couldn't find that product.");
  if (product.store.status !== "PUBLISHED") throw conflict("This product is no longer listed.");

  const open = await prisma.reservation.findFirst({
    where: { customerId, productId, status: "PENDING" },
  });
  if (open) throw conflict("You already have an open reservation for this item.");

  return prisma.reservation.create({
    data: { customerId, productId, storeId: product.store.id, requestedQuantity: quantity },
    include: { product: { select: { name: true, imageUrl: true, unit: true } }, store: { select: { name: true } } },
  });
}

export async function listCustomerReservations(customerId: string) {
  return prisma.reservation.findMany({
    where: { customerId },
    include: {
      product: { select: { id: true, name: true, imageUrl: true, unit: true, pricePaise: true, category: true } },
      store: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function cancelReservation(customerId: string, reservationId: string) {
  const reservation = await prisma.reservation.findFirst({ where: { id: reservationId, customerId } });
  if (!reservation) throw notFound("We couldn't find that reservation.");
  if (reservation.status !== "PENDING" && reservation.status !== "CONFIRMED") {
    throw conflict("This reservation can no longer be cancelled.");
  }
  return prisma.reservation.update({
    where: { id: reservationId },
    data: { status: "CANCELLED", stockHeld: false },
  }).then(async (updated) => {
    if (reservation.stockHeld) await releaseHold(reservation.productId, reservation.requestedQuantity);
    return updated;
  });
}

async function releaseHold(productId: string, quantity: number) {
  await prisma.inventory.updateMany({
    where: { productId },
    data: { reservedQuantity: { decrement: quantity } },
  });
}

export async function respondToReservation(
  sellerId: string,
  reservationId: string,
  status: "CONFIRMED" | "REJECTED",
  response: string | undefined,
  holdStock: boolean,
) {
  const reservation = await prisma.reservation.findFirst({
    where: { id: reservationId, store: { sellerId } },
  });
  if (!reservation) throw notFound("We couldn't find that reservation, or it isn't yours to answer.");
  if (reservation.status !== "PENDING") {
    throw conflict("You have already answered this reservation.");
  }

  if (status === "CONFIRMED" && holdStock) {
    // Conditional increment: only succeeds if there is still sellable stock.
    const inv = await prisma.inventory.findUnique({ where: { productId: reservation.productId } });
    const sellable = (inv?.stockQuantity ?? 0) - (inv?.reservedQuantity ?? 0);
    if (sellable < reservation.requestedQuantity) {
      throw conflict(
        `Only ${sellable} unit(s) are available to hold. Confirm without holding, or restock first.`,
      );
    }
    const updated = await prisma.inventory.updateMany({
      where: { productId: reservation.productId },
      data: { reservedQuantity: { increment: reservation.requestedQuantity } },
    });
    if (updated.count === 0) throw conflict("Stock changed while you were responding. Please try again.");

    log.info("reservation.held", {
      reservationId,
      productId: reservation.productId,
      quantity: reservation.requestedQuantity,
    });
  }

  return prisma.reservation.update({
    where: { id: reservationId },
    data: {
      status,
      stockHeld: status === "CONFIRMED" && holdStock,
      sellerResponse: response ?? null,
      sellerRespondedAt: new Date(),
      // Only a *held* reservation has something to expire. An informal
      // confirmation is a promise, not a lock on the shelf, so giving it an
      // expiry would make the UI claim stock will be released when it never was.
      expiresAt:
        status === "CONFIRMED" && holdStock ? new Date(Date.now() + 24 * 60 * 60 * 1000) : null,
    },
  });
}

/**
 * Releases expired holds. Called opportunistically on seller dashboards; a
 * production deployment should also run this on a schedule so sellable stock
 * does not stay artificially reduced.
 */
export async function expireStaleReservations() {
  const stale = await prisma.reservation.findMany({
    where: { status: "CONFIRMED", stockHeld: true, expiresAt: { lt: new Date() } },
  });
  for (const r of stale) {
    await prisma.reservation.update({ where: { id: r.id }, data: { status: "EXPIRED", stockHeld: false } });
    await releaseHold(r.productId, r.requestedQuantity);
  }
  return stale.length;
}

export async function listSellerStockRequests(sellerId: string, status?: string) {
  const store = await prisma.store.findFirst({ where: { sellerId } });
  if (!store) return [];
  return prisma.stockRequest.findMany({
    where: { storeId: store.id, ...(status && status !== "ALL" ? { status } : {}) },
    include: {
      product: { select: { id: true, name: true, imageUrl: true, unit: true, pricePaise: true } },
      customer: { select: { name: true, phone: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function listSellerReservations(sellerId: string, status?: string) {
  const store = await prisma.store.findFirst({ where: { sellerId } });
  if (!store) return [];
  return prisma.reservation.findMany({
    where: { storeId: store.id, ...(status && status !== "ALL" ? { status } : {}) },
    include: {
      product: { select: { id: true, name: true, imageUrl: true, unit: true, pricePaise: true } },
      customer: { select: { name: true, phone: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export { badRequest };
