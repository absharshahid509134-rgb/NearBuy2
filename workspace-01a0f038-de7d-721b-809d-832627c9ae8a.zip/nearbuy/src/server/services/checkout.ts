import "server-only";
import { randomBytes } from "node:crypto";
import { Prisma } from "@prisma/client";
import { AppError, badRequest, conflict, notFound } from "@/lib/errors";
import { deliveryFeePaise, haversineKm } from "@/lib/geo";
import { env } from "@/lib/env";
import { codeHint, encryptSecret, generateHandoffCode } from "@/lib/crypto";
import { prisma } from "@/server/db";
import { log } from "@/server/logger";
import type { CheckoutInput } from "@/lib/validation";

function orderNumber(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  const ymd = `${String(d.getFullYear()).slice(2)}${p(d.getMonth() + 1)}${p(d.getDate())}`;
  return `NB-${ymd}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

export interface CheckoutResult {
  orders: Array<{
    id: string;
    orderNumber: string;
    storeId: string;
    storeName: string;
    status: string;
    fulfillmentType: string;
    subtotalPaise: number;
    deliveryFeePaise: number;
    totalPaise: number;
  }>;
  grandTotalPaise: number;
  idempotentReplay: boolean;
}

type Tx = Prisma.TransactionClient;

/** The subset of a freshly created order that the checkout response needs. */
export interface CreatedOrder {
  id: string;
  orderNumber: string;
  storeId: string;
  status: string;
  fulfillmentType: string;
  subtotalPaise: number;
  deliveryFeePaise: number;
  totalPaise: number;
  store: { name: string };
}

/**
 * Multi-store checkout.
 *
 * Rules this function exists to enforce, none of which are optional:
 *  - prices, stock, availability and store status come from the DATABASE,
 *    never from the request body;
 *  - one Order row per store, so each seller runs their own pipeline;
 *  - stock is decremented with a conditional UPDATE (`stockQuantity >= qty`),
 *    which is the atomic guard that makes overselling impossible under
 *    concurrency rather than merely unlikely;
 *  - the whole thing is one transaction, so a failure leaves no partial order
 *    and no phantom stock deduction;
 *  - a replayed `idempotencyKey` returns the original orders instead of
 *    creating new ones.
 */
export async function checkout(
  customerId: string,
  input: CheckoutInput,
): Promise<CheckoutResult> {
  const e = env();

  // Replay check before doing any work at all.
  const existing = await prisma.order.findMany({
    where: { customerId, idempotencyKey: input.idempotencyKey },
    include: { store: { select: { name: true } } },
    orderBy: { placedAt: "asc" },
  });
  if (existing.length > 0) {
    return shape(existing, true);
  }

  const cart = await prisma.cart.findUnique({
    where: { customerId },
    include: { items: { include: { product: { include: { store: true, inventory: true } } } } },
  });
  if (!cart || cart.items.length === 0) {
    throw badRequest("Your cart is empty. Add something before checking out.");
  }

  // Address is only required for delivery. For pickup the customer is already
  // at the store, and a delivery address would be misleading.
  let address: {
    id: string; fullName: string; phone: string; line1: string; line2: string | null;
    landmark: string | null; city: string; state: string; pincode: string;
    latitude: number; longitude: number;
  } | null = null;

  if (input.fulfillmentType === "DELIVERY") {
    if (!input.addressId) throw badRequest("Choose a delivery address for this order.");
    const found = await prisma.address.findFirst({ where: { id: input.addressId, customerId } });
    // Scoping by customerId is what stops one customer reading another's
    // address by guessing an id.
    if (!found) throw notFound("We couldn't find that delivery address.");
    address = found;
  } else {
    address = await prisma.address.findFirst({ where: { customerId, isDefault: true } });
  }

  // Group the cart by store — this is what makes it a multi-store checkout.
  const byStore = new Map<string, typeof cart.items>();
  for (const item of cart.items) {
    const list = byStore.get(item.product.storeId) ?? [];
    list.push(item);
    byStore.set(item.product.storeId, list);
  }

  try {
    const created = await prisma.$transaction(
      async (tx) => {
        const results: CreatedOrder[] = [];

        for (const [storeId, items] of byStore) {
          const store = await tx.store.findUnique({ where: { id: storeId } });
          if (!store) throw notFound("One of the stores in your cart is no longer available.");

          if (store.status !== "PUBLISHED") {
            throw conflict(`${store.name} is not accepting orders right now. Please remove their items from your cart.`);
          }
          if (!store.isOpen) {
            throw conflict(`${store.name} is currently closed. Please try again when it reopens.`);
          }
          if (input.fulfillmentType === "DELIVERY" && !store.supportsDelivery) {
            throw conflict(`${store.name} does not offer delivery. Please switch those items to pickup.`);
          }
          if (input.fulfillmentType === "PICKUP" && !store.supportsPickup) {
            throw conflict(`${store.name} does not offer pickup. Please switch those items to delivery.`);
          }

          let subtotal = 0;
          for (const item of items) {
            const p = item.product;

            if (p.status !== "PUBLISHED") {
              throw conflict(`${p.name} is no longer listed. Please remove it from your cart.`);
            }
            if (!p.isAvailable) {
              throw conflict(`${p.name} is currently unavailable at ${store.name}.`);
            }

            // The conditional UPDATE is the concurrency control. Two shoppers
            // racing for the last unit both run this; the loser updates 0 rows
            // and the whole transaction rolls back.
            const updated = await tx.inventory.updateMany({
              where: {
                productId: p.id,
                stockQuantity: { gte: item.quantity },
              },
              data: { stockQuantity: { decrement: item.quantity } },
            });

            if (updated.count === 0) {
              const inv = await tx.inventory.findUnique({ where: { productId: p.id } });
              const left = inv?.stockQuantity ?? 0;
              throw conflict(
                left <= 0
                  ? `${p.name} just went out of stock. Please update your cart.`
                  : `Only ${left} × ${p.name} left in stock. Please update your cart.`,
              );
            }

            // Price is read from the row we just locked, never echoed back.
            subtotal += p.pricePaise * item.quantity;
          }

          const deliveryFee =
            input.fulfillmentType === "DELIVERY" && address
              ? deliveryFeePaise(haversineKm(
                  { lat: store.latitude, lng: store.longitude },
                  { lat: address.latitude, lng: address.longitude },
                ), {
                  basePaise: e.DELIVERY_BASE_PAISE,
                  perKmPaise: e.DELIVERY_PER_KM_PAISE,
                  minPaise: e.DELIVERY_MIN_PAISE,
                  maxPaise: e.DELIVERY_MAX_PAISE,
                })
              : 0;

          const pickupCode = generateHandoffCode();
          const deliveryCode = generateHandoffCode();

          const order = await tx.order.create({
            data: {
              orderNumber: orderNumber(),
              customerId,
              storeId,
              status: "PLACED",
              fulfillmentType: input.fulfillmentType,
              subtotalPaise: subtotal,
              deliveryFeePaise: deliveryFee,
              totalPaise: subtotal + deliveryFee,
              paymentMethod: "COD",
              paymentStatus: "PENDING",
              shipFullName: address?.fullName ?? "Pickup customer",
              shipPhone: address?.phone ?? "",
              shipLine1: address?.line1 ?? store.addressLine1,
              shipLine2: address?.line2 ?? null,
              shipLandmark: address?.landmark ?? null,
              shipCity: address?.city ?? store.city,
              shipState: address?.state ?? store.state,
              shipPincode: address?.pincode ?? store.pincode,
              shipLat: address?.latitude ?? store.latitude,
              shipLng: address?.longitude ?? store.longitude,
              idempotencyKey: input.idempotencyKey,
              pickupCodeEnc: encryptSecret(pickupCode),
              pickupCodeHint: codeHint(pickupCode),
              deliveryCodeEnc: encryptSecret(deliveryCode),
              deliveryCodeHint: codeHint(deliveryCode),
              items: {
                create: items.map((item) => ({
                  productId: item.product.id,
                  nameSnapshot: item.product.name,
                  unitPricePaise: item.product.pricePaise,
                  quantity: item.quantity,
                  lineTotalPaise: item.product.pricePaise * item.quantity,
                  imageUrlSnapshot: item.product.imageUrl,
                  unitSnapshot: item.product.unit,
                })),
              },
              handoffEvents: {
                create: {
                  actorUserId: customerId,
                  actorRole: "CUSTOMER",
                  type: "ORDER_PLACED",
                  metadata: JSON.stringify({
                    fulfillmentType: input.fulfillmentType,
                    totalPaise: subtotal + deliveryFee,
                  }),
                },
              },
            },
            include: { store: { select: { name: true } } },
          });

          // A delivery job only exists for orders a rider must fulfil. Pickup
          // orders go straight to the customer, so no job is ever broadcast.
          if (input.fulfillmentType === "DELIVERY") {
            await tx.deliveryJob.create({
              data: {
                orderId: order.id,
                status: "AVAILABLE",
                pickupCodeEnc: order.pickupCodeEnc,
                deliveryCodeEnc: order.deliveryCodeEnc,
                earningsPaise: Math.round(order.totalPaise * 0.15),
                handoffEvents: {
                  create: {
                    orderId: order.id,
                    actorUserId: customerId,
                    actorRole: "SYSTEM",
                    type: "JOB_AVAILABLE",
                  },
                },
              },
            });
          }

          results.push(order);
        }

        // Only remove the items that were actually purchased.
        await tx.cartItem.deleteMany({
          where: { cartId: cart.id, productId: { in: items0(cart.items) } },
        });

        return results;
      },
      { timeout: 20_000, maxWait: 10_000 },
    );

    return shape(created, false);
  } catch (err) {
    // A concurrent replay of the same idempotency key lost the unique-index
    // race. The winner's order is the correct answer, not an error.
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") {
      // Replay of the same key lost the unique-index race: the winner's order
      // is the correct answer, not an error.
      const replay = await prisma.order.findMany({
        where: { customerId, idempotencyKey: input.idempotencyKey },
        include: { store: { select: { name: true } } },
        orderBy: { placedAt: "asc" },
      });
      if (replay.length > 0) return shape(replay, true);

      // A different unique constraint (orderNumber, cart, …) was violated.
      // Log which one; the client still only learns it must refresh.
      const target = (err.meta as { target?: string[] | string } | undefined)?.target;
      log.error("checkout.unique_violation", {
        customerId,
        target: Array.isArray(target) ? target.join(",") : String(target ?? "unknown"),
      });
      throw new AppError(
        409,
        "CONFLICT",
        "We couldn't finish placing that order. Please try again in a moment.",
      );
    }
    if (err instanceof AppError) throw err;
    log.error("checkout.failed", {
      customerId,
      message: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}

const items0 = (items: Array<{ productId: string }>): string[] =>
  Array.from(new Set(items.map((i) => i.productId)));

function shape(orders: CreatedOrder[], replay: boolean): CheckoutResult {
  return {
    orders: orders.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      storeId: o.storeId,
      storeName: o.store.name,
      status: o.status,
      fulfillmentType: o.fulfillmentType,
      subtotalPaise: o.subtotalPaise,
      deliveryFeePaise: o.deliveryFeePaise,
      totalPaise: o.totalPaise,
    })),
    grandTotalPaise: orders.reduce((sum, o) => sum + o.totalPaise, 0),
    idempotentReplay: replay,
  };
}
