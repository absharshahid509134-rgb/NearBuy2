import "server-only";
import { Prisma } from "@prisma/client";
import { forbidden, notFound, conflict } from "@/lib/errors";
import { prisma } from "@/server/db";
import { log } from "@/server/logger";
import type { ProductInput, StoreInput } from "@/lib/validation";

/* ------------------------------------------------------------------ store -- */

function slugify(value: string): string {
  return (
    value
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "store"
  );
}

async function uniqueSlug(name: string, excludeId?: string): Promise<string> {
  const base = slugify(name);
  for (let i = 0; i < 50; i++) {
    const candidate = i === 0 ? base : `${base}-${i + 1}`;
    const clash = await prisma.store.findUnique({ where: { slug: candidate } });
    if (!clash || clash.id === excludeId) return candidate;
  }
  return `${base}-${Date.now().toString(36)}`;
}

/**
 * Loads the seller's own store, proving ownership in the query. A seller
 * passing another seller's storeId gets 404 — not 403, which would confirm
 * the record exists.
 */
export async function getSellerStore(sellerId: string) {
  return prisma.store.findFirst({ where: { sellerId } });
}

export async function createStore(sellerId: string, input: StoreInput) {
  const existing = await prisma.store.findFirst({ where: { sellerId } });
  if (existing) {
    throw conflict("You already have a store. Update its settings instead of creating another.");
  }
  const { operatingDays, ...rest } = input;
  const store = await prisma.store.create({
    data: {
      ...rest,
      operatingDays: operatingDays.join(","),
      slug: await uniqueSlug(input.name),
      sellerId,
      publishedAt: input.status === "PUBLISHED" ? new Date() : null,
    },
  });
  log.info("store.created", { storeId: store.id, sellerId });
  return store;
}

export async function updateStore(sellerId: string, storeId: string, input: Partial<StoreInput>) {
  const store = await getSellerStore(sellerId);
  if (!store || store.id !== storeId) {
    throw notFound("We couldn't find that store, or it isn't yours to manage.");
  }
  const { operatingDays, ...rest } = input;
  return prisma.store.update({
    where: { id: storeId },
    data: {
      ...rest,
      ...(operatingDays ? { operatingDays: operatingDays.join(",") } : {}),
      ...(input.name && input.name !== store.name ? { slug: await uniqueSlug(input.name, storeId) } : {}),
      // Publishing for the first time stamps publishedAt; re-publishing keeps it.
      ...(input.status === "PUBLISHED" && !store.publishedAt ? { publishedAt: new Date() } : {}),
    },
  });
}

/* --------------------------------------------------------------- products -- */

export async function listSellerProducts(sellerId: string) {
  const store = await getSellerStore(sellerId);
  if (!store) return [];
  return prisma.product.findMany({
    where: { storeId: store.id },
    include: { inventory: true },
    orderBy: { createdAt: "desc" },
  });
}

/** Ownership is proven by walking product -> store -> sellerId. */
export async function getSellerProduct(sellerId: string, productId: string) {
  const product = await prisma.product.findFirst({
    where: { id: productId, store: { sellerId } },
    include: { inventory: true, store: { select: { id: true, name: true } } },
  });
  if (!product) throw notFound("We couldn't find that product, or it isn't yours to manage.");
  return product;
}

export async function createProduct(sellerId: string, input: ProductInput, imageUrl: string | null) {
  const store = await getSellerStore(sellerId);
  if (!store) throw forbidden("Create your store before adding products.");
  if (input.compareAtPricePaise && input.compareAtPricePaise <= input.pricePaise) {
    throw conflict("The compare-at price should be higher than the selling price.");
  }
  return prisma.product.create({
    data: {
      storeId: store.id,
      name: input.name,
      description: input.description,
      category: input.category,
      unit: input.unit,
      pricePaise: input.pricePaise,
      compareAtPricePaise: input.compareAtPricePaise ?? null,
      imageUrl,
      status: input.status,
      isAvailable: input.isAvailable,
      inventory: {
        create: {
          stockQuantity: input.stockQuantity,
          lowStockThreshold: input.lowStockThreshold,
        },
      },
    },
    include: { inventory: true },
  });
}

export async function updateProduct(
  sellerId: string,
  productId: string,
  input: Partial<ProductInput>,
  imageUrl: string | undefined,
) {
  const product = await getSellerProduct(sellerId, productId);
  const newPrice = input.pricePaise ?? product.pricePaise;
  const newCompare = input.compareAtPricePaise ?? product.compareAtPricePaise;
  if (newCompare && newCompare <= newPrice) {
    throw conflict("The compare-at price should be higher than the selling price.");
  }

  return prisma.$transaction(async (tx) => {
    if (input.stockQuantity !== undefined) {
      // Never let a stock edit push quantity below what reservations hold.
      const inv = await tx.inventory.findUnique({ where: { productId } });
      if (inv && input.stockQuantity < inv.reservedQuantity) {
        throw conflict(
          `You have ${inv.reservedQuantity} unit(s) held for reservations. Stock cannot go below that.`,
        );
      }
      await tx.inventory.update({
        where: { productId },
        data: {
          stockQuantity: input.stockQuantity,
          ...(input.lowStockThreshold !== undefined
            ? { lowStockThreshold: input.lowStockThreshold }
            : {}),
        },
      });
    } else if (input.lowStockThreshold !== undefined) {
      await tx.inventory.update({
        where: { productId },
        data: { lowStockThreshold: input.lowStockThreshold },
      });
    }

    return tx.product.update({
      where: { id: productId },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.description !== undefined ? { description: input.description } : {}),
        ...(input.category !== undefined ? { category: input.category } : {}),
        ...(input.unit !== undefined ? { unit: input.unit } : {}),
        ...(input.pricePaise !== undefined ? { pricePaise: input.pricePaise } : {}),
        ...(input.compareAtPricePaise !== undefined
          ? { compareAtPricePaise: input.compareAtPricePaise }
          : {}),
        ...(input.isAvailable !== undefined ? { isAvailable: input.isAvailable } : {}),
        ...(input.status !== undefined ? { status: input.status } : {}),
        ...(imageUrl !== undefined ? { imageUrl } : {}),
      },
      include: { inventory: true },
    });
  });
}

export async function archiveProduct(sellerId: string, productId: string) {
  await getSellerProduct(sellerId, productId);
  return prisma.product.update({
    where: { id: productId },
    data: { status: "ARCHIVED", isAvailable: false },
  });
}

/* -------------------------------------------------------------- dashboard -- */

/** Every number below is an aggregate over real rows. Nothing is invented. */
export async function sellerDashboard(sellerId: string) {
  const store = await getSellerStore(sellerId);
  if (!store) {
    return {
      store: null,
      counts: null,
      lowStock: [],
      recentOrders: [],
      revenue: { totalPaise: 0, todayPaise: 0, last7DaysPaise: 0, orderCount: 0 },
    };
  }

  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const [
    newOrders,
    preparing,
    readyForPickup,
    pendingStockRequests,
    pendingReservations,
    lowStock,
    revenueAgg,
    recentOrders,
    totalProducts,
    inStockCount,
  ] = await Promise.all([
    prisma.order.count({ where: { storeId: store.id, status: "PLACED" } }),
    prisma.order.count({ where: { storeId: store.id, status: { in: ["ACCEPTED", "PREPARING", "PACKED"] } } }),
    prisma.order.count({ where: { storeId: store.id, status: "READY_FOR_PICKUP" } }),
    prisma.stockRequest.count({ where: { storeId: store.id, status: "PENDING" } }),
    prisma.reservation.count({ where: { storeId: store.id, status: "PENDING" } }),
    prisma.product.findMany({
      where: { storeId: store.id, status: "PUBLISHED" },
      include: { inventory: true },
      take: 50,
    }),
    prisma.order.aggregate({
      where: { storeId: store.id, status: "DELIVERED" },
      _sum: { totalPaise: true },
      _count: { _all: true },
    }),
    prisma.order.findMany({
      where: { storeId: store.id },
      include: {
        items: true,
        customer: { select: { name: true } },
        deliveryJob: { select: { riderId: true, earningsPaise: true } },
      },
      orderBy: { placedAt: "desc" },
      take: 8,
    }),
    prisma.product.count({ where: { storeId: store.id, status: "PUBLISHED" } }),
    prisma.product.count({
      where: { storeId: store.id, status: "PUBLISHED", inventory: { stockQuantity: { gt: 0 } } },
    }),
  ]);

  const lowStockList = lowStock
    .filter((p) => {
      const inv = p.inventory;
      if (!inv) return false;
      return inv.stockQuantity <= inv.lowStockThreshold;
    })
    .map((p) => ({
      id: p.id,
      name: p.name,
      imageUrl: p.imageUrl,
      stockQuantity: p.inventory?.stockQuantity ?? 0,
      lowStockThreshold: p.inventory?.lowStockThreshold ?? 0,
    }))
    .slice(0, 8);

  const [todayAgg, weekAgg] = await Promise.all([
    prisma.order.aggregate({
      where: { storeId: store.id, status: "DELIVERED", deliveredAt: { gte: startOfToday } },
      _sum: { totalPaise: true },
    }),
    prisma.order.aggregate({
      where: { storeId: store.id, status: "DELIVERED", deliveredAt: { gte: sevenDaysAgo } },
      _sum: { totalPaise: true },
    }),
  ]);

  return {
    store,
    counts: {
      newOrders,
      preparing,
      readyForPickup,
      pendingStockRequests,
      pendingReservations,
      totalProducts,
      inStockCount,
    },
    lowStock: lowStockList,
    recentOrders: recentOrders.map((o) => ({
      id: o.id,
      orderNumber: o.orderNumber,
      customerName: o.customer.name,
      status: o.status,
      fulfillmentType: o.fulfillmentType,
      totalPaise: o.totalPaise,
      itemCount: o.items.reduce((s, i) => s + i.quantity, 0),
      placedAt: o.placedAt,
    })),
    revenue: {
      totalPaise: revenueAgg._sum.totalPaise ?? 0,
      todayPaise: todayAgg._sum.totalPaise ?? 0,
      last7DaysPaise: weekAgg._sum.totalPaise ?? 0,
      orderCount: revenueAgg._count._all,
    },
  };
}

export async function listSellerOrders(sellerId: string, status?: string) {
  const store = await getSellerStore(sellerId);
  if (!store) return [];
  const valid = status && status !== "ALL" ? status : undefined;
  if (valid) {
    // Guard against a caller pushing an arbitrary string into the where clause.
    const allowed = new Set([
      "PLACED", "ACCEPTED", "PREPARING", "PACKED", "READY_FOR_PICKUP",
      "PICKED_UP", "OUT_FOR_DELIVERY", "DELIVERED", "REJECTED", "CANCELLED",
    ]);
    if (!allowed.has(valid)) throw conflict("That is not a valid order status.");
  }
  return prisma.order.findMany({
    where: { storeId: store.id, ...(valid ? { status: valid } : {}) },
    include: {
      items: true,
      // orderView() derives seller ownership from store.sellerId, so the
      // store row is required — not decorative.
      store: { select: { id: true, sellerId: true, name: true, city: true, slug: true, addressLine1: true, latitude: true, longitude: true, phone: true, openingTime: true, closingTime: true } },
      customer: { select: { id: true, name: true, phone: true } },
      rider: { select: { id: true, name: true, phone: true } },
      deliveryJob: { select: { id: true, status: true, riderId: true } },
      handoffEvents: { orderBy: { createdAt: "asc" } },
    },
    orderBy: { placedAt: "desc" },
    take: 100,
  });
}

/** Orders that genuinely need a human decision right now. */
export async function listActionItems(sellerId: string) {
  const store = await getSellerStore(sellerId);
  if (!store) return { orders: [], stockRequests: [], reservations: [] };

  const [orders, stockRequests, reservations] = await Promise.all([
    prisma.order.findMany({
      where: { storeId: store.id, status: { in: ["PLACED", "ACCEPTED", "PREPARING", "PACKED", "READY_FOR_PICKUP"] } },
      include: {
        items: true,
        customer: { select: { name: true, phone: true } },
        deliveryJob: { select: { status: true, riderId: true } },
      },
      orderBy: { placedAt: "asc" },
    }),
    prisma.stockRequest.findMany({
      where: { storeId: store.id, status: "PENDING" },
      include: {
        product: { select: { name: true, imageUrl: true, pricePaise: true } },
        customer: { select: { name: true, phone: true } },
      },
      orderBy: { createdAt: "asc" },
    }),
    prisma.reservation.findMany({
      where: { storeId: store.id, status: "PENDING" },
      include: {
        product: { select: { name: true, imageUrl: true, pricePaise: true } },
        customer: { select: { name: true, phone: true } },
      },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  return { orders, stockRequests, reservations };
}

export { Prisma };
