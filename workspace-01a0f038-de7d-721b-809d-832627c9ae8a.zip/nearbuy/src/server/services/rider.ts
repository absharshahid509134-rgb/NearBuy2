import "server-only";
import { Prisma } from "@prisma/client";
import { decryptSecret, safeEqual } from "@/lib/crypto";
import { conflict, forbidden, notFound } from "@/lib/errors";
import { prisma } from "@/server/db";
import { log } from "@/server/logger";
import { loadOrderForActor, transitionOrder, orderView } from "./orders";

/**
 * A job is created the moment the customer checks out, but it only becomes
 * *claimable* once the seller marks the order READY_FOR_PICKUP — otherwise
 * riders would queue outside stores waiting for goods still being packed.
 */
export async function listAvailableJobs(
  riderId: string,
  limit = 50,
): Promise<unknown[]> {
  void riderId;
  const jobs = await prisma.deliveryJob.findMany({
    where: {
      status: "AVAILABLE",
      riderId: null,
      order: { status: "READY_FOR_PICKUP", fulfillmentType: "DELIVERY" },
    },
    include: {
      order: {
        include: {
          items: true,
          store: {
            select: {
              name: true, addressLine1: true, city: true, latitude: true,
              longitude: true, phone: true, category: true,
            },
          },
        },
      },
    },
    orderBy: { createdAt: "asc" },
    take: limit,
  });

  return jobs.map((j) => ({
    id: j.id,
    orderId: j.orderId,
    orderNumber: j.order.orderNumber,
    status: j.status,
    earningsPaise: j.earningsPaise,
    itemCount: j.order.items.reduce((n, i) => n + i.quantity, 0),
    storeName: j.order.store.name,
    storeAddress: `${j.order.store.addressLine1}, ${j.order.store.city}`,
    // Only what a rider needs to physically complete the job: the destination,
    // never the customer's phone number or the codes.
    dropArea: j.order.shipCity,
    dropPincode: j.order.shipPincode,
    placedAt: j.order.placedAt,
  }));
}

export async function listRiderJobs(riderId: string) {
  const [active, completed] = await Promise.all([
    prisma.deliveryJob.findMany({
      where: {
        riderId,
        status: { in: ["ASSIGNED", "PICKED_UP", "OUT_FOR_DELIVERY"] },
      },
      include: jobInclude,
      orderBy: { claimedAt: "asc" },
    }),
    prisma.deliveryJob.findMany({
      where: { riderId, status: "COMPLETED" },
      include: jobInclude,
      orderBy: { completedAt: "desc" },
      take: 100,
    }),
  ]);
  return { active, completed };
}

const jobInclude = {
  order: {
    include: {
      items: true,
      store: {
        select: {
          name: true, addressLine1: true, city: true, latitude: true,
          longitude: true, phone: true, category: true,
        },
      },
    },
  },
} satisfies Prisma.DeliveryJobInclude;

/**
 * Atomic job claiming.
 *
 * The guarantee is a compare-and-swap inside a single UPDATE: only a row that
 * is still `status = AVAILABLE AND riderId IS NULL` can match. If two riders
 * press "Claim Job" in the same instant, the database serialises the writes
 * and the loser's UPDATE matches zero rows — so exactly one rider can ever win,
 * with no application-level lock and no second SELECT to race against.
 */
export async function claimJob(jobId: string, riderId: string) {
  const job = await prisma.deliveryJob.findUnique({ where: { id: jobId } });
  if (!job) throw notFound("We couldn't find that delivery job.");

  if (job.status === "AVAILABLE" && job.riderId) {
    throw conflict("This delivery has already been claimed by another rider.");
  }
  if (job.status !== "AVAILABLE") {
    throw conflict("This delivery is no longer available.");
  }
  if (job.riderId && job.riderId !== riderId) {
    throw conflict("This delivery has already been claimed by another rider.");
  }

  try {
    const claimed = await prisma.$transaction(async (tx) => {
      const result = await tx.deliveryJob.updateMany({
        where: { id: jobId, status: "AVAILABLE", riderId: null },
        data: { riderId, status: "ASSIGNED", claimedAt: new Date() },
      });

      // Zero rows matched: someone else won the race between our read and our
      // write. This is the expected outcome under contention, not a crash.
      if (result.count === 0) return null;

      const updated = await tx.deliveryJob.findUniqueOrThrow({
        where: { id: jobId },
        include: jobInclude,
      });

      await tx.order.update({ where: { id: job.orderId }, data: { riderId } });

      await tx.handoffEvent.create({
        data: {
          orderId: job.orderId,
          jobId,
          actorUserId: riderId,
          actorRole: "RIDER",
          type: "JOB_ASSIGNED",
        },
      });

      return updated;
    });

    if (!claimed) {
      log.warn("job.claim_lost", { jobId, riderId });
      throw conflict("This delivery has already been claimed by another rider.");
    }

    log.info("job.claimed", { jobId, riderId, orderId: job.orderId });
    return claimed;
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      throw conflict("This delivery has already been claimed by another rider.");
    }
    throw e;
  }
}

export async function releaseJob(jobId: string, riderId: string) {
  const result = await prisma.deliveryJob.updateMany({
    where: { id: jobId, riderId, status: "ASSIGNED" },
    data: { riderId: null, status: "AVAILABLE", claimedAt: null },
  });
  if (result.count === 0) {
    throw conflict("This job can no longer be released. Refresh to see its current state.");
  }
  return { released: true };
}

/**
 * Pickup verification. The rider submits the code the seller read out; we
 * check job identity, job ownership, current status and the code itself.
 * On failure we record the attempt without ever echoing the expected value.
 */
export async function verifyPickup(jobId: string, riderId: string, submitted: string) {
  const job = await prisma.deliveryJob.findUnique({ where: { id: jobId } });
  if (!job) throw notFound("We couldn't find that delivery job.");
  if (job.riderId !== riderId) throw forbidden("This delivery is not assigned to you.");
  if (job.status !== "ASSIGNED") {
    throw conflict("This job is not waiting for pickup. Refresh to see its current state.");
  }
  if (!job.pickupCodeEnc) throw conflict("This job has no pickup code set.");

  const expected = decryptSecret(job.pickupCodeEnc);
  if (!safeEqual(submitted, expected)) {
    await prisma.handoffEvent.create({
      data: {
        orderId: job.orderId,
        jobId,
        actorUserId: riderId,
        actorRole: "RIDER",
        type: "PICKUP_CODE_FAILED",
      },
    });
    log.warn("handoff.pickup_failed", { jobId, riderId });
    throw conflict("Incorrect pickup code. Please confirm the code with the seller.");
  }

  const order = await transitionOrder(job.orderId, { id: riderId, role: "RIDER" }, "PICKED_UP", {
    viaJobId: jobId,
  });
  return orderView(order, { id: riderId, role: "RIDER" });
}

export async function startDelivery(jobId: string, riderId: string) {
  const job = await prisma.deliveryJob.findUnique({ where: { id: jobId } });
  if (!job) throw notFound("We couldn't find that delivery job.");
  if (job.riderId !== riderId) throw forbidden("This delivery is not assigned to you.");
  if (job.status !== "PICKED_UP") {
    throw conflict("Verify the pickup code before starting delivery.");
  }
  const order = await transitionOrder(job.orderId, { id: riderId, role: "RIDER" }, "OUT_FOR_DELIVERY", {
    viaJobId: jobId,
  });
  return orderView(order, { id: riderId, role: "RIDER" });
}

/** Delivery verification, symmetric to verifyPickup. */
export async function verifyDelivery(jobId: string, riderId: string, submitted: string) {
  const job = await prisma.deliveryJob.findUnique({ where: { id: jobId } });
  if (!job) throw notFound("We couldn't find that delivery job.");
  if (job.riderId !== riderId) throw forbidden("This delivery is not assigned to you.");
  if (job.status !== "OUT_FOR_DELIVERY") {
    throw conflict("Start delivery before completing it.");
  }
  if (!job.deliveryCodeEnc) throw conflict("This job has no delivery code set.");

  const expected = decryptSecret(job.deliveryCodeEnc);
  if (!safeEqual(submitted, expected)) {
    await prisma.handoffEvent.create({
      data: {
        orderId: job.orderId,
        jobId,
        actorUserId: riderId,
        actorRole: "RIDER",
        type: "DELIVERY_CODE_FAILED",
      },
    });
    log.warn("handoff.delivery_failed", { jobId, riderId });
    throw conflict("Incorrect delivery code. Please confirm the code with the customer.");
  }

  const order = await transitionOrder(job.orderId, { id: riderId, role: "RIDER" }, "DELIVERED", {
    viaJobId: jobId,
  });
  return orderView(order, { id: riderId, role: "RIDER" });
}

export async function riderEarnings(riderId: string) {
  const jobs = await prisma.deliveryJob.findMany({
    where: { riderId, status: "COMPLETED" },
    select: { earningsPaise: true, completedAt: true, order: { select: { orderNumber: true, shipCity: true } } },
    orderBy: { completedAt: "desc" },
  });
  const totalPaise = jobs.reduce((s, j) => s + j.earningsPaise, 0);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayPaise = jobs
    .filter((j) => j.completedAt && j.completedAt >= today)
    .reduce((s, j) => s + j.earningsPaise, 0);
  return {
    totalPaise,
    todayPaise,
    completedCount: jobs.length,
    history: jobs.map((j) => ({
      jobId: (j as unknown as { id: string }).id,
      orderNumber: j.order.orderNumber,
      area: j.order.shipCity,
      earningsPaise: j.earningsPaise,
      completedAt: j.completedAt,
    })),
  };
}

export { loadOrderForActor };
