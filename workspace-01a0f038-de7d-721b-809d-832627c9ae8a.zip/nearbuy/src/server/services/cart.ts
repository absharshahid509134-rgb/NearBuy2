import "server-only";
import { prisma } from "@/server/db";
import { badRequest, conflict, notFound } from "@/lib/errors";

/** Every customer has exactly one cart; create it lazily. */
export async function getOrCreateCart(customerId: string) {
  const existing = await prisma.cart.findUnique({
    where: { customerId },
    include: {
      items: {
        include: {
          product: {
            include: {
              inventory: true,
              store: { select: { id: true, name: true, slug: true, isOpen: true, status: true } },
            },
          },
        },
        orderBy: { addedAt: "asc" },
      },
    },
  });
  if (existing) return existing;
  return prisma.cart.create({
    data: { customerId },
    include: {
      items: {
        include: {
          product: {
            include: {
              inventory: true,
              store: { select: { id: true, name: true, slug: true, isOpen: true, status: true } },
            },
          },
        },
      },
    },
  });
}

export async function addToCart(customerId: string, productId: string, quantity: number) {
  const product = await prisma.product.findUnique({
    where: { id: productId },
    include: { inventory: true, store: { select: { name: true, status: true, isOpen: true } } },
  });
  if (!product) throw notFound("We couldn't find that product.");
  if (product.status !== "PUBLISHED") throw conflict("This product is no longer available.");
  if (!product.store.isOpen || product.store.status !== "PUBLISHED") {
    throw conflict(`${product.store.name} is not accepting orders right now.`);
  }

  const cart = await getOrCreateCart(customerId);
  const existing = cart.items.find((i) => i.productId === productId);
  const desired = (existing?.quantity ?? 0) + quantity;
  const available = product.inventory?.stockQuantity ?? 0;

  if (desired > available) {
    throw conflict(
      available <= 0
        ? `${product.name} is out of stock.`
        : `Only ${available} × ${product.name} available.`,
    );
  }

  if (existing) {
    await prisma.cartItem.update({ where: { id: existing.id }, data: { quantity: desired } });
  } else {
    await prisma.cartItem.create({ data: { cartId: cart.id, productId, quantity } });
  }
  return getCartView(customerId);
}

export async function updateCartItem(customerId: string, itemId: string, quantity: number) {
  const item = await prisma.cartItem.findFirst({
    where: { id: itemId, cart: { customerId } }, // ownership in the query
    include: { product: { include: { inventory: true } } },
  });
  if (!item) throw notFound("That item is not in your cart.");

  if (quantity === 0) {
    await prisma.cartItem.delete({ where: { id: itemId } });
    return getCartView(customerId);
  }

  const available = item.product.inventory?.stockQuantity ?? 0;
  if (quantity > available) {
    throw conflict(
      available <= 0
        ? `${item.product.name} is now out of stock. Please remove it from your cart.`
        : `Only ${available} × ${item.product.name} available.`,
    );
  }
  if (quantity < 1 || quantity > 99) throw badRequest("Quantity must be between 1 and 99.");

  await prisma.cartItem.update({ where: { id: itemId }, data: { quantity } });
  return getCartView(customerId);
}

export async function removeCartItem(customerId: string, itemId: string) {
  const item = await prisma.cartItem.findFirst({ where: { id: itemId, cart: { customerId } } });
  if (!item) throw notFound("That item is not in your cart.");
  await prisma.cartItem.delete({ where: { id: itemId } });
  return getCartView(customerId);
}

export async function clearCart(customerId: string) {
  const cart = await prisma.cart.findUnique({ where: { customerId } });
  if (cart) await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
  return getCartView(customerId);
}

/**
 * The cart view recomputes everything from the database. The browser never
 * supplies a price, a store name or a stock figure — those are display-only
 * conveniences the server re-derives on every read.
 */
export async function getCartView(customerId: string) {
  const cart = await getOrCreateCart(customerId);

  type Item = (typeof cart.items)[number];

  const groups = new Map<string, { store: Item["product"]["store"]; items: Item[] }>();
  for (const item of cart.items) {
    const g = groups.get(item.product.storeId);
    if (g) g.items.push(item);
    else groups.set(item.product.storeId, { store: item.product.store, items: [item] });
  }

  const issues: string[] = [];
  const groupsOut = Array.from(groups.values()).map((g) => {
    const items = g.items.map((item) => {
      const available = item.product.inventory?.stockQuantity ?? 0;
      const lineTotal = item.product.pricePaise * item.quantity;
      let note: string | null = null;

      if (item.product.status !== "PUBLISHED") {
        note = "This product is no longer available. Please remove it.";
        issues.push(`${item.product.name} is no longer available.`);
      } else if (!g.store.isOpen || g.store.status !== "PUBLISHED") {
        note = `${g.store.name} is currently closed.`;
        issues.push(`${g.store.name} is currently closed.`);
      } else if (available === 0) {
        note = "This item is now out of stock. Please update your cart.";
        issues.push(`${item.product.name} is out of stock.`);
      } else if (item.quantity > available) {
        note = `Only ${available} left in stock.`;
        issues.push(`Only ${available} × ${item.product.name} left in stock.`);
      }

      return {
        id: item.id,
        productId: item.productId,
        name: item.product.name,
        imageUrl: item.product.imageUrl,
        unit: item.product.unit,
        pricePaise: item.product.pricePaise,
        quantity: item.quantity,
        availableStock: available,
        lineTotalPaise: lineTotal,
        note,
      };
    });
    const subtotal = items.reduce((s, i) => s + i.lineTotalPaise, 0);
    return {
      store: g.store,
      items,
      subtotalPaise: subtotal,
      itemCount: items.reduce((s, i) => s + i.quantity, 0),
    };
  });

  return {
    groups: groupsOut,
    itemCount: groupsOut.reduce((s, g) => s + g.itemCount, 0),
    subtotalPaise: groupsOut.reduce((s, g) => s + g.subtotalPaise, 0),
    storeCount: groupsOut.length,
    issues,
    hasBlockingIssues: issues.length > 0,
  };
}
