import "server-only";
import { Prisma } from "@prisma/client";
import { haversineKm } from "@/lib/geo";
import { prisma } from "@/server/db";
import type { z } from "zod";
import type { searchQuerySchema, storeSearchSchema } from "@/lib/validation";

type SearchInput = z.infer<typeof searchQuerySchema>;
type StoreSearchInput = z.infer<typeof storeSearchSchema>;

/** Store card projection. Never includes seller PII. */
const storeCard = {
  id: true,
  name: true,
  slug: true,
  description: true,
  category: true,
  imageUrl: true,
  addressLine1: true,
  city: true,
  state: true,
  pincode: true,
  latitude: true,
  longitude: true,
  openingTime: true,
  closingTime: true,
  operatingDays: true,
  isOpen: true,
  status: true,
  supportsDelivery: true,
  supportsPickup: true,
  deliveryEtaMinutes: true,
  publishedAt: true,
} satisfies Prisma.StoreSelect;

export const CATEGORIES = [
  "Grocery",
  "Fruits & Vegetables",
  "Dairy",
  "Bakery",
  "Pharmacy",
  "Snacks",
  "Beverages",
  "Personal Care",
  "Household",
  "Stationery",
] as const;

export async function searchProducts(input: SearchInput) {
  const where: Prisma.ProductWhereInput = {
    // Discovery may only ever see published, available goods in a published,
    // open store. These three predicates are the whole public surface.
    status: "PUBLISHED",
    isAvailable: true,
    store: { status: "PUBLISHED", isOpen: true },
    ...(input.q
      ? {
          OR: [
            { name: { contains: input.q } },
            { description: { contains: input.q } },
            { category: { contains: input.q } },
          ],
        }
      : {}),
    ...(input.category ? { category: { contains: input.category } } : {}),
    ...(input.storeId ? { storeId: input.storeId } : {}),
    ...(input.minPrice !== undefined || input.maxPrice !== undefined
      ? {
          pricePaise: {
            ...(input.minPrice !== undefined ? { gte: input.minPrice } : {}),
            ...(input.maxPrice !== undefined ? { lte: input.maxPrice } : {}),
          },
        }
      : {}),
    ...(input.inStock ? { inventory: { stockQuantity: { gt: 0 } } } : {}),
  };

  const orderBy: Prisma.ProductOrderByWithRelationInput[] =
    input.sort === "price_asc" ? [{ pricePaise: "asc" }]
    : input.sort === "price_desc" ? [{ pricePaise: "desc" }]
    : input.sort === "newest" ? [{ createdAt: "desc" }]
    : input.q ? [{ name: "asc" }] : [{ createdAt: "desc" }];

  const [total, products] = await Promise.all([
    prisma.product.count({ where }),
    prisma.product.findMany({
      where,
      include: {
        inventory: { select: { stockQuantity: true, reservedQuantity: true } },
        store: { select: { id: true, name: true, slug: true, city: true, deliveryEtaMinutes: true, latitude: true, longitude: true } },
      },
      orderBy,
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
  ]);

  return {
    total,
    page: input.page,
    pageSize: input.pageSize,
    items: products.map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description,
      category: p.category,
      unit: p.unit,
      imageUrl: p.imageUrl,
      pricePaise: p.pricePaise,
      compareAtPricePaise: p.compareAtPricePaise,
      stockQuantity: p.inventory?.stockQuantity ?? 0,
      inStock: (p.inventory?.stockQuantity ?? 0) > 0,
      store: p.store,
      distanceKm:
        input.lat !== undefined && input.lng !== undefined
          ? Number(
              haversineKm(
                { lat: input.lat, lng: input.lng },
                { lat: p.store.latitude, lng: p.store.longitude },
              ).toFixed(2),
            )
          : null,
    })),
  };
}

export async function searchStores(input: StoreSearchInput) {
  const where: Prisma.StoreWhereInput = {
    status: "PUBLISHED",
    ...(input.q
      ? { OR: [{ name: { contains: input.q } }, { description: { contains: input.q } }, { category: { contains: input.q } }] }
      : {}),
    ...(input.category ? { category: { contains: input.category } } : {}),
    ...(input.open ? { isOpen: true } : {}),
  };

  const [total, stores] = await Promise.all([
    prisma.store.count({ where }),
    prisma.store.findMany({
      where,
      select: {
        ...storeCard,
        products: {
          where: { status: "PUBLISHED", isAvailable: true },
          select: { id: true },
        },
      },
      orderBy:
        input.sort === "name" ? [{ name: "asc" }] : input.sort === "newest" ? [{ publishedAt: "desc" }] : [{ publishedAt: "desc" }],
      skip: (input.page - 1) * input.pageSize,
      take: input.pageSize,
    }),
  ]);

  let items = stores.map((s) => ({
    ...s,
    productCount: s.products.length,
    products: undefined,
    distanceKm:
      input.lat !== undefined && input.lng !== undefined
        ? Number(
            haversineKm(
              { lat: input.lat, lng: input.lng },
              { lat: s.latitude, lng: s.longitude },
            ).toFixed(2),
          )
        : null,
  }));

  // Distance sorting happens in memory because SQLite/Postgres cannot sort by
  // a haversine expression through Prisma. Paging still happens in SQL.
  if (input.sort === "distance" && input.lat !== undefined && input.lng !== undefined) {
    items = items.sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0));
  }

  return { total, page: input.page, pageSize: input.pageSize, items };
}

export async function getStoreBySlug(slug: string) {
  const store = await prisma.store.findFirst({
    where: { slug, status: "PUBLISHED" },
    select: {
      ...storeCard,
      products: {
        where: { status: "PUBLISHED" },
        include: { inventory: { select: { stockQuantity: true, reservedQuantity: true } } },
        orderBy: { name: "asc" },
      },
    },
  });
  if (!store) return null;
  return {
    ...store,
    products: store.products.map((p) => ({
      ...p,
      inventory: undefined,
      stockQuantity: p.inventory?.stockQuantity ?? 0,
      inStock: (p.inventory?.stockQuantity ?? 0) > 0,
    })),
  };
}

export async function getCategoriesWithCounts() {
  const grouped = await prisma.product.groupBy({
    by: ["category"],
    where: {
      status: "PUBLISHED",
      isAvailable: true,
      store: { status: "PUBLISHED", isOpen: true },
      inventory: { stockQuantity: { gt: 0 } },
    },
    _count: { _all: true },
  });
  return grouped
    .map((g) => ({ category: g.category, count: g._count._all }))
    .sort((a, b) => b.count - a.count);
}
