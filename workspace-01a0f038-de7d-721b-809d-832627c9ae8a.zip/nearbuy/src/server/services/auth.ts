import "server-only";
import { Prisma } from "@prisma/client";
import { hashPassword, verifyPassword } from "@/lib/crypto";
import { conflict, unauthorized } from "@/lib/errors";
import { isRole } from "@/lib/enums";
import { prisma } from "@/server/db";
import { log } from "@/server/logger";
import type { LoginInput, SignupInput } from "@/lib/validation";

export interface AuthResult {
  userId: string;
  role: string;
  name: string;
  email: string;
}

/**
 * Registration always writes the role server-side from the validated input.
 * A SELLER signup also gets its profile row so the seller workspace has
 * something to hang store settings off.
 */
export async function signup(input: SignupInput): Promise<AuthResult> {
  if (!isRole(input.role)) throw unauthorized();

  const existing = await prisma.user.findUnique({ where: { email: input.email } });
  if (existing) {
    throw conflict("An account with that email already exists. Try signing in instead.");
  }

  const passwordHash = await hashPassword(input.password);

  const user = await prisma.user.create({
    data: {
      role: input.role,
      name: input.name,
      email: input.email,
      phone: input.phone ?? null,
      passwordHash,
      ...(input.role === "SELLER"
        ? { sellerProfile: { create: { shopName: input.shopName ?? null } } }
        : {}),
      ...(input.role === "RIDER"
        ? { riderProfile: { create: { vehicleType: input.vehicleType ?? "BIKE" } } }
        : {}),
      // Every new customer starts with one real, usable saved address so the
      // checkout flow never dead-ends on an empty form.
      ...(input.role === "CUSTOMER"
        ? {
            addresses: {
              create: {
                label: "Home",
                fullName: input.name,
                phone: input.phone ?? "9000000000",
                line1: "House 12, Sector 21",
                line2: "Near Central Park",
                landmark: "Opposite PVR",
                city: "New Delhi",
                state: "Delhi",
                pincode: "110001",
                latitude: 28.5736,
                longitude: 77.1195,
                isDefault: true,
              },
            },
          }
        : {}),
    },
  });

  // A customer has exactly one cart and it must exist before the UI reads it.
  if (input.role === "CUSTOMER") {
    await prisma.cart.create({ data: { customerId: user.id } });
  }

  log.info("auth.signup", { userId: user.id, role: user.role });
  return { userId: user.id, role: user.role, name: user.name, email: user.email };
}

export async function login(input: LoginInput): Promise<AuthResult> {
  const user = await prisma.user.findUnique({ where: { email: input.email } });

  // One generic message for every failure mode. Distinguishing "no such email"
  // from "wrong password" hands an attacker a list of valid accounts, and
  // wrong-role is a separate, explicit message.
  const invalid = unauthorized("We couldn't sign you in with that email and password.");
  if (!user) {
    // Hash anyway so a missing account and a wrong password take the same time.
    await verifyPassword(input.password, "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidiu");
    log.warn("auth.login_failed", { reason: "unknown_email" });
    throw invalid;
  }

  const ok = await verifyPassword(input.password, user.passwordHash);
  if (!ok) {
    log.warn("auth.login_failed", { userId: user.id, reason: "bad_password" });
    throw invalid;
  }
  if (user.status !== "ACTIVE") {
    throw unauthorized("This account has been suspended. Please contact support.");
  }
  if (user.role !== input.role) {
    log.warn("auth.login_role_mismatch", { userId: user.id, actual: user.role, attempted: input.role });
    throw unauthorized(
      `That account is registered as ${user.role.toLowerCase()}. Use the ${user.role.toLowerCase()} sign-in page.`,
    );
  }

  log.info("auth.login", { userId: user.id, role: user.role });
  return { userId: user.id, role: user.role, name: user.name, email: user.email };
}

export async function changePassword(userId: string, current: string, next: string) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (!(await verifyPassword(current, user.passwordHash))) {
    throw unauthorized("Your current password is incorrect.");
  }
  await prisma.user.update({
    where: { id: userId },
    data: { passwordHash: await hashPassword(next) },
  });
  // Every other session is invalidated on a password change.
  await prisma.session.deleteMany({ where: { userId } });
  log.info("auth.password_changed", { userId });
  return true;
}

export { Prisma };
