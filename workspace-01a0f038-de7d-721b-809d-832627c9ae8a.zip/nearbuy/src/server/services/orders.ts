import "server-only";
import { Prisma } from "@prisma/client";
import {
  canTransition,
  ORDER_STATE_MACHINE,
  type OrderStatus,
  type Role,
} from "@/lib/enums";
import { decryptSecret } from "@/lib/crypto";
import { badRequest, conflict, forbidden, notFound } from "@/lib/errors";
import { prisma } from "@/server/db";
import { log } from "@/server/logger";

const orderInclude = {
  items: true,
  store: {
    select: {
      id: true, sellerId: true, name: true, city: true, addressLine1: true,
      latitude: true, longitude: true, phone: true, openingTime: true, closingTime: true,
    },
  },
  customer: { select: { id: true, name: true, phone: true } },
  rider: { select: { id: true, name: true, phone: true } },
  deliveryJob: true,
  handoffEvents: { orderBy: { createdAt: "asc" as const } },
} satisfies Prisma.OrderInclude;

export type OrderWithRelations = Prisma.OrderGetPayload<{ include: typeof orderInclude }>;

const TIMESTAMP_FIELD: Partial<Record<OrderStatus, string>> = {
  ACCEPTED: "acceptedAt",
  PREPARING: "preparingAt",
  PACKED: "packedAt",
  READY_FOR_PICKUP: "readyAt",
  PICKED_UP: "pickedUpAt",
  OUT_FOR_DELIVERY: "outForDeliveryAt",
  DELIVERED: "deliveredAt",
};

/**
 * Loads an order **and proves the caller is entitled to it** in the same query.
 *
 * This is the app's IDOR boundary. Ownership is expressed as a `where` clause
 * rather than checked after loading, so a wrong id returns 404 without ever
 * revealing that the record exists.
 */
export async function loadOrderForActor(orderId: string, user: { id: string; role: string }) {
  const where: Prisma.OrderWhereInput = { id: orderId };
  if (user.role === "CUSTOMER") where.customerId = user.id;
  else if (user.role === "RIDER") {
    // Riders see only jobs assigned to them. Browsing the unclaimed pool goes
    // through listAvailableJobs, which is a separate, deliberately narrow query.
    where.riderId = user.id;
  } else if (user.role === "SELLER") {
    where.store = { sellerId: user.id };
  } else {
    throw forbidden();
  }

  const order = await prisma.order.findFirst({ where, include: orderInclude });
  if (!order) throw notFound("We couldn't find that order, or it isn't yours to view.");
  return order;
}

/**
 * Applies a state transition, enforcing three things the UI cannot:
 *  1. the edge exists in the state machine;
 *  2. the actor's role is allowed to drive that edge;
 *  3. the order actually belongs to that actor.
 * Plus side effects: timestamps, payment capture, stock return on cancel, and
 * an immutable audit event.
 */
export async function transitionOrder(
  orderId: string,
  actor: { id: string; role: string },
  to: OrderStatus,
  meta: { reason?: string; viaJobId?: string } = {},
): Promise<OrderWithRelations> {
  const role = actor.role as Role;
  const current = await prisma.order.findFirst({
    where: {
      id: orderId,
      ...(role === "CUSTOMER" ? { customerId: actor.id }
        : role === "SELLER" ? { store: { sellerId: actor.id } }
        : role === "RIDER" ? { riderId: actor.id }
        : {}),
    },
  });
  if (!current) throw notFound("We couldn't find that order, or it isn't yours to change.");

  if (!canTransition(current.status as OrderStatus, to, role)) {
    const edges = ORDER_STATE_MACHINE[current.status as OrderStatus] ?? [];
    const edge = edges.find((t) => t.to === to);

    // The move exists but belongs to another role. That is an authorisation
    // failure (403), not a state conflict — the distinction matters because a
    // client retries 409s but must not retry 403s.
    if (edge && !edge.actors.includes(role)) {
      const owners = edge.actors
        .map((a) => a.toLowerCase())
        .join(" or ");
      throw forbidden(`Only the ${owners} can ${edge.label.toLowerCase()} this order.`);
    }

    const allowed = edges.filter((t) => t.actors.includes(role));
    throw conflict(
      allowed.length === 0
        ? `This order is already ${current.status.toLowerCase().replace(/_/g, " ")} and cannot change.`
        : `You cannot move this order to ${to.toLowerCase().replace(/_/g, " ")} from ${current.status
            .toLowerCase()
            .replace(/_/g, " ")}. Right now you can: ${allowed.map((a) => a.label.toLowerCase()).join(", ")}.`,
    );
  }

  // A seller may only confirm collection on a self-pickup order. This stops the
  // otherwise-legal SELLER -> DELIVERED edge from being used to fake a delivery.
  if (to === "DELIVERED" && role === "SELLER" && current.fulfillmentType !== "PICKUP") {
    throw forbidden("Only the customer or the assigned rider can complete a delivery.");
  }

  const now = new Date();
  const data: Prisma.OrderUpdateInput = { status: to };
  const tsField = TIMESTAMP_FIELD[to];
  if (tsField) (data as Record<string, unknown>)[tsField] = now;
  if (to === "REJECTED" || to === "CANCELLED") {
    data.closedAt = now;
    if (meta.reason) data.closeReason = meta.reason.slice(0, 300);
  }
  if (to === "DELIVERED") {
    // COD is collected in cash at the door. Only now is that true.
    data.paymentStatus = "COLLECTED";
  }

  const eventType =
    to === "ACCEPTED" ? "SELLER_ACCEPTED"
    : to === "PREPARING" ? "SELLER_PREPARING"
    : to === "PACKED" ? "SELLER_PACKED"
    : to === "READY_FOR_PICKUP" ? "READY_FOR_PICKUP"
    : to === "PICKED_UP" ? "PICKUP_VERIFIED"
    : to === "OUT_FOR_DELIVERY" ? "OUT_FOR_DELIVERY"
    : to === "DELIVERED" ? "DELIVERY_VERIFIED"
    : to === "REJECTED" ? "ORDER_REJECTED"
    : to === "CANCELLED" ? "ORDER_CANCELLED"
    : "ORDER_PLACED";

  const updated = await prisma.$transaction(async (tx) => {
    const order = await tx.order.update({
      where: { id: current.id, status: current.status }, // compare-and-swap
      data,
    });

    await tx.handoffEvent.create({
      data: {
        orderId: order.id,
        jobId: meta.viaJobId,
        actorUserId: actor.id,
        actorRole: role,
        type: eventType,
        metadata: meta.reason ? JSON.stringify({ reason: meta.reason.slice(0, 300) }) : null,
      },
    });

    // Cancelling puts the goods back on the shelf. Only valid while the order
    // was still consuming stock (a delivered order cannot be reopened).
    if ((to === "CANCELLED" || to === "REJECTED") && current.status !== "PICKED_UP") {
      const items = await tx.orderItem.findMany({ where: { orderId: order.id } });
      for (const item of items) {
        await tx.inventory.updateMany({
          where: { productId: item.productId },
          data: { stockQuantity: { increment: item.quantity } },
        });
      }
      const job = await tx.deliveryJob.findUnique({ where: { orderId: order.id } });
      if (job && job.status !== "COMPLETED" && job.status !== "CANCELLED") {
        await tx.deliveryJob.update({
          where: { id: job.id },
          data: { status: "CANCELLED", cancelledAt: now },
        });
      }
    }

    if (to === "DELIVERED") {
      const job = await tx.deliveryJob.findUnique({ where: { orderId: order.id } });
      if (job) {
        await tx.deliveryJob.update({
          where: { id: job.id },
          data: { status: "COMPLETED", completedAt: now },
        });
      }
    }

    if (to === "PICKED_UP" || to === "OUT_FOR_DELIVERY" || to === "DELIVERED") {
      const job = await tx.deliveryJob.findUnique({ where: { orderId: order.id } });
      if (job) {
        await tx.deliveryJob.update({
          where: { id: job.id },
          data:
            to === "PICKED_UP" ? { status: "PICKED_UP", pickedUpAt: now }
            : to === "OUT_FOR_DELIVERY" ? { status: "OUT_FOR_DELIVERY", outForDeliveryAt: now }
            : { status: "COMPLETED", completedAt: now },
        });
      }
    }

    return order;
  });

  log.info("order.transition", { orderId, from: current.status, to, actorRole: role, actorId: actor.id });

  return prisma.order.findUniqueOrThrow({ where: { id: updated.id }, include: orderInclude });
}

/**
 * The handoff codes are the security boundary of the whole delivery flow, so
 * who can read them — and when — is decided here and nowhere else.
 *
 *  pickup code   -> the store's own seller, from READY_FOR_PICKUP onwards
 *  delivery code -> the ordering customer, from PICKED_UP onwards
 *
 * A rider never reads either code; they verify by submitting it. Sellers never
 * receive the customer delivery code, and customers never receive the pickup
 * code. Ownership is taken from the loaded order's store row, so it cannot be
 * influenced by whatever the caller claims about themselves.
 */
/** Masked hints are safe for any party to the order; plaintext is not. */
/**
 * The minimum shape `orderView` needs. Kept structural rather than tied to one
 * `include`, so list endpoints (lean queries) and the detail endpoint (full
 * relations) can share the exact same redaction logic. If a new include ever
 * adds a sensitive column, it is still stripped unless listed here.
 */
export type OrderViewInput = {
  id: string;
  status: string;
  customerId: string;
  pickupCodeEnc: string | null;
  pickupCodeHint: string | null;
  deliveryCodeEnc: string | null;
  deliveryCodeHint: string | null;
  store: { sellerId: string };
  [key: string]: unknown;
};

/**
 * What the client is allowed to see. The encrypted secrets are removed from
 * the type as well as the value, so a page cannot accidentally read one.
 */
export type OrderViewOf<T> = Omit<
  T,
  "pickupCodeEnc" | "deliveryCodeEnc" | "pickupCodeHint" | "deliveryCodeHint"
> & {
  pickupCodeHint: string | null;
  deliveryCodeHint: string | null;
  pickupCode?: string;
  deliveryCode?: string;
};

export function orderView<T extends OrderViewInput>(
  order: T,
  viewer: { id: string; role: string },
): OrderViewOf<T> {
  const { pickupCodeEnc, deliveryCodeEnc, pickupCodeHint, deliveryCodeHint, ...rest } = order;
  const status = order.status as OrderStatus;

  const isOwnerCustomer = viewer.role === "CUSTOMER" && viewer.id === order.customerId;
  const isOwnerSeller = viewer.role === "SELLER" && viewer.id === order.store.sellerId;

  const pickupVisible =
    isOwnerSeller && ["READY_FOR_PICKUP", "PICKED_UP", "OUT_FOR_DELIVERY"].includes(status);
  const deliveryVisible =
    isOwnerCustomer && ["PICKED_UP", "OUT_FOR_DELIVERY"].includes(status);

  return {
    ...rest,
    // Hints are withheld too, not just the plaintext, so a rider cannot learn
    // the last four digits of a code they are not meant to hold.
    pickupCodeHint: pickupVisible ? pickupCodeHint : null,
    deliveryCodeHint: deliveryVisible ? deliveryCodeHint : null,
    pickupCode: pickupVisible && pickupCodeEnc ? decryptSecret(pickupCodeEnc) : undefined,
    deliveryCode: deliveryVisible && deliveryCodeEnc ? decryptSecret(deliveryCodeEnc) : undefined,
  };
}

export function assertValidTransitionTarget(value: unknown): OrderStatus {
  if (typeof value !== "string" || !(value in ORDER_STATE_MACHINE)) {
    throw badRequest("That is not a valid order status.");
  }
  return value as OrderStatus;
}
