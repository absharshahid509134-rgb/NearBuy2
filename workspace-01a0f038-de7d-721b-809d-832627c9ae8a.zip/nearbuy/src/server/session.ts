import "server-only";
import { cookies } from "next/headers";
import { randomToken, sha256 } from "@/lib/crypto";
import { env } from "@/lib/env";
import { prisma } from "./db";
import { log } from "./logger";

export const SESSION_COOKIE = "nb_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14; // 14 days

export interface SessionUser {
  id: string;
  role: string;
  name: string;
  email: string;
  phone: string | null;
}

/**
 * Opaque, server-side sessions. The cookie holds a random token; only its
 * SHA-256 is stored, so a leaked database snapshot cannot be replayed as a
 * live login. This also makes logout and "sign out everywhere" real rather
 * than a client-side illusion.
 */
export async function createSession(
  userId: string,
  meta: { userAgent?: string; ip?: string } = {},
): Promise<{ token: string; expiresAt: Date }> {
  const token = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await prisma.session.create({
    data: {
      tokenHash: sha256(token),
      userId,
      expiresAt,
      userAgent: meta.userAgent?.slice(0, 250) ?? null,
      ip: meta.ip?.slice(0, 64) ?? null,
    },
  });
  return { token, expiresAt };
}

export async function resolveSession(token: string): Promise<SessionUser | null> {
  const session = await prisma.session.findUnique({
    where: { tokenHash: sha256(token) },
    include: { user: true },
  });
  if (!session) return null;

  if (session.expiresAt.getTime() <= Date.now()) {
    // Best-effort cleanup; a failure here must not block the request.
    void prisma.session.delete({ where: { id: session.id } }).catch(() => {});
    return null;
  }
  if (session.user.status !== "ACTIVE") return null;

  if (Date.now() - session.lastUsedAt.getTime() > 1000 * 60 * 15) {
    void prisma.session
      .update({ where: { id: session.id }, data: { lastUsedAt: new Date() } })
      .catch(() => {});
  }

  return {
    id: session.user.id,
    role: session.user.role,
    name: session.user.name,
    email: session.user.email,
    phone: session.user.phone,
  };
}

export async function destroySession(token: string): Promise<void> {
  await prisma.session.deleteMany({ where: { tokenHash: sha256(token) } });
}

export function sessionCookieOptions(expiresAt: Date) {
  const secure = env().NODE_ENV === "production";
  return {
    httpOnly: true,
    secure,
    sameSite: "lax" as const,
    path: "/",
    expires: expiresAt,
  };
}

export function clearedCookieOptions() {
  return {
    httpOnly: true,
    secure: env().NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 0,
  };
}

/** Read + validate the session cookie. Returns null for anonymous visitors. */
export async function currentUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return resolveSession(token);
}

export function readTokenFromCookieHeader(header: string | null | undefined): string | null {
  if (!header) return null;
  for (const part of header.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === SESSION_COOKIE) return decodeURIComponent(rest.join("="));
  }
  return null;
}

export { log };
