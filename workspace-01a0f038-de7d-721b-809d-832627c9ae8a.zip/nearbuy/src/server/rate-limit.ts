/**
 * Fixed-window limiter, in-process.
 *
 * Honest limitation: this is per-instance. With N app instances the effective
 * limit is N * configured. The documented production answer is a shared store
 * (Upstash Redis / provider rate limiter) via RATE_LIMIT_REDIS_URL — this
 * module is the single seam to swap, so callers never change.
 */
interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();
let lastSweep = Date.now();
const SWEEP_MS = 60_000;

function sweep(now: number) {
  if (now - lastSweep < SWEEP_MS) return;
  lastSweep = now;
  for (const [k, b] of buckets) if (b.resetAt <= now) buckets.delete(k);
}

export interface RateLimitResult {
  ok: boolean;
  remaining: number;
  retryAfterSeconds: number;
}

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number,
): RateLimitResult {
  const now = Date.now();
  sweep(now);
  const b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: limit - 1, retryAfterSeconds: Math.ceil(windowMs / 1000) };
  }
  b.count += 1;
  if (b.count > limit) {
    return {
      ok: false,
      remaining: 0,
      retryAfterSeconds: Math.max(1, Math.ceil((b.resetAt - now) / 1000)),
    };
  }
  return { ok: true, remaining: limit - b.count, retryAfterSeconds: Math.ceil((b.resetAt - now) / 1000) };
}

/** Test hook so the integration suite starts from a clean slate. */
export function resetRateLimits(): void {
  buckets.clear();
}
