import "server-only";
import { redirect } from "next/navigation";
import { currentUser, type SessionUser } from "./session";
import type { Role } from "@/lib/enums";

/**
 * Server-side workspace guard.
 *
 * This is a *convenience* redirect for good UX, not the security boundary —
 * every API route independently re-checks the session and the role. A user who
 * hand-types /seller while signed in as a customer is bounced to their own
 * workspace; a user with no session is bounced to the matching sign-in page.
 */
export async function requireWorkspace(
  role: Role,
  signedInPath: string,
  signedOutPath: string,
): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) redirect(signedOutPath);
  if (user.role !== role) redirect(`/${user.role.toLowerCase()}`);
  return user;
}
