type Level = "info" | "warn" | "error";

/** Keys whose values must never reach a log line. */
const REDACT = new Set([
  "password", "newPassword", "currentPassword", "passwordHash", "token",
  "code", "pickupCode", "deliveryCode", "codeHash", "authorization", "cookie",
]);

function scrub(value: unknown): unknown {
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map(scrub);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    out[k] = REDACT.has(k) ? "[redacted]" : scrub(v);
  }
  return out;
}

/**
 * Structured single-line JSON logging. Hand-off codes and passwords are
 * stripped here rather than trusted to every call site.
 */
function emit(level: Level, event: string, data: Record<string, unknown> = {}) {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event,
    ...(scrub(data) as Record<string, unknown>),
  });
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const log = {
  info: (event: string, data?: Record<string, unknown>) => emit("info", event, data),
  warn: (event: string, data?: Record<string, unknown>) => emit("warn", event, data),
  error: (event: string, data?: Record<string, unknown>) => emit("error", event, data),
};

/** Distinctive marker so a leak in production logs is obvious. */
export const sentry = (e: unknown, data?: Record<string, unknown>) => {
  const message = e instanceof Error ? e.message : String(e);
  log.error("unhandled", { message, ...data });
};
