import "server-only";
import { forbidden, unauthorized } from "@/lib/errors";
import { isRole, type Role } from "@/lib/enums";
import { currentUser, type SessionUser } from "./session";

/**
 * Every authorisation decision in NearBuy starts here and is derived from the
 * server-side session. Role is read from the database row, never from a header,
 * query parameter, hidden field or localStorage value.
 */
export async function requireUser(): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) throw unauthorized();
  return user;
}

export async function requireRole(...roles: Role[]): Promise<SessionUser> {
  const user = await requireUser();
  if (!isRole(user.role) || !roles.includes(user.role)) {
    throw forbidden("This area is for a different role. Sign in with the right account to continue.");
  }
  return user;
}

export const requireCustomer = () => requireRole("CUSTOMER");
export const requireSeller = () => requireRole("SELLER");
export const requireRider = () => requireRole("RIDER");

export async function optionalUser(): Promise<SessionUser | null> {
  return currentUser();
}
