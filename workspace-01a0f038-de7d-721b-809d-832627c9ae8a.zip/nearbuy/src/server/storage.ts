import "server-only";
import { randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { env } from "@/lib/env";
import { badRequest } from "@/lib/errors";

const ALLOWED = new Map<string, string>([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["image/avif", "avif"],
  ["image/gif", "gif"],
]);

/**
 * Content type is decided by sniffing magic bytes, never by trusting the
 * browser-supplied `type` or the filename extension.
 */
function sniff(bytes: Buffer): string | null {
  if (bytes.length < 12) return null;
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])))
    return "image/png";
  if (bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP")
    return "image/webp";
  if (bytes.subarray(4, 8).toString("ascii") === "ftyp") {
    const brand = bytes.subarray(8, 12).toString("ascii");
    if (brand.startsWith("avif") || brand.startsWith("avis")) return "image/avif";
  }
  if (bytes.subarray(0, 3).toString("ascii") === "GIF") return "image/gif";
  return null;
}

let s3Client: S3Client | null = null;
function s3(): S3Client {
  if (!s3Client) {
    const e = env();
    s3Client = new S3Client({
      region: e.S3_REGION || "auto",
      endpoint: e.S3_ENDPOINT || undefined,
      forcePathStyle: Boolean(e.S3_ENDPOINT),
      credentials:
        e.S3_ACCESS_KEY_ID && e.S3_SECRET_ACCESS_KEY
          ? { accessKeyId: e.S3_ACCESS_KEY_ID, secretAccessKey: e.S3_SECRET_ACCESS_KEY }
          : undefined,
    });
  }
  return s3Client;
}

export interface StoredImage {
  url: string;
  key: string;
}

/**
 * Two drivers behind one interface. `local` is for development only — app
 * instances have independent disks, so a container restart loses images.
 * Production boot refuses to start with the local driver (see
 * `assertProductionConfig`), which forces an S3-compatible bucket.
 */
export async function storeImage(
  file: File,
  ownerKey: string,
): Promise<StoredImage> {
  const e = env();
  const bytes = Buffer.from(await file.arrayBuffer());

  if (bytes.length === 0) throw badRequest("That image is empty. Please choose another file.");
  if (bytes.length > e.MAX_UPLOAD_BYTES) {
    throw badRequest(
      `Images must be under ${Math.round(e.MAX_UPLOAD_BYTES / 1024 / 1024)} MB.`,
    );
  }

  const sniffed = sniff(bytes);
  if (!sniffed || !ALLOWED.has(sniffed)) {
    throw badRequest("Please upload a JPG, PNG, WebP, AVIF or GIF image.");
  }
  const ext = ALLOWED.get(sniffed)!;

  // Owner-scoped, random key: a seller cannot guess or overwrite another
  // seller's asset, and the original filename never reaches the filesystem.
  const key = `${ownerKey}/${randomBytes(12).toString("hex")}.${ext}`;

  if (e.STORAGE_DRIVER === "s3") {
    if (!e.S3_BUCKET) throw badRequest("Image storage is not configured. Please try again later.");
    await s3().send(
      new PutObjectCommand({
        Bucket: e.S3_BUCKET,
        Key: key,
        Body: bytes,
        ContentType: sniffed,
        CacheControl: "public, max-age=31536000, immutable",
      }),
    );
    const base = e.S3_PUBLIC_BASE_URL.replace(/\/$/, "");
    return { url: `${base}/${key}`, key };
  }

  const dir = path.join(process.cwd(), ".uploads", ownerKey);
  await mkdir(dir, { recursive: true });
  const filePath = path.join(dir, path.basename(key));
  await writeFile(filePath, bytes);
  return { url: `/api/uploads/${key}`, key };
}
