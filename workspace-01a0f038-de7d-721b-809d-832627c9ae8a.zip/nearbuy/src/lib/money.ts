/**
 * Money is integer paise everywhere: database, API, and server logic.
 * Rupees exist only at the two edges — parsing user input and rendering UI.
 */
export const formatINR = (paise: number): string =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: paise % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(paise / 100);

/** e.g. 6800 -> "68", 4999 -> "49.99" — for <input type="number"> round-trips. */
export const rupeesToPaise = (rupees: string | number): number =>
  Math.round(Number(rupees) * 100);

export function assertValidPaise(value: number, label = "amount"): number {
  if (!Number.isInteger(value) || value < 0) {
    throw new Error(`Invalid ${label}: ${value}`);
  }
  // Guard against overflow of a 32-bit int column in Postgres.
  if (value > 2_000_000_000) throw new Error(`${label} out of range`);
  return value;
}
