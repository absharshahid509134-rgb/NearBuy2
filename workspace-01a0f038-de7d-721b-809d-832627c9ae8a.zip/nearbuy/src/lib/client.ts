"use client";

/**
 * The browser's single door to the API.
 *
 * Every call returns a discriminated result rather than throwing, so forms can
 * render a real message instead of a blank screen. The server remains the
 * authority on prices, stock and permissions; nothing here is trusted.
 */
export interface ApiErrorShape {
  code: string;
  message: string;
  details?: Record<string, string>;
}

export type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: ApiErrorShape };

async function request<T>(
  path: string,
  init: RequestInit & { json?: unknown } = {},
): Promise<ApiResult<T>> {
  const { json, ...rest } = init;
  try {
    const res = await fetch(path, {
      ...rest,
      headers: {
        ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
        ...(rest.headers ?? {}),
      },
      body: json !== undefined ? JSON.stringify(json) : rest.body,
      credentials: "same-origin",
    });

    const payload = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        ok: false,
        error: {
          code: payload?.error?.code ?? "UNKNOWN",
          message: payload?.error?.message ?? "We couldn't complete that. Please try again.",
          details: payload?.error?.details,
        },
      };
    }
    return { ok: true, data: payload?.data as T };
  } catch {
    return {
      ok: false,
      error: {
        code: "NETWORK",
        message: "We couldn't reach NearBuy. Check your connection and try again.",
      },
    };
  }
}

export const api = {
  get: <T,>(path: string) => request<T>(path),
  post: <T,>(path: string, json?: unknown) => request<T>(path, { method: "POST", json }),
  put: <T,>(path: string, json?: unknown) => request<T>(path, { method: "PUT", json }),
  patch: <T,>(path: string, json?: unknown) => request<T>(path, { method: "PATCH", json }),
  del: <T,>(path: string) => request<T>(path, { method: "DELETE" }),
};

export const qs = (params: Record<string, string | number | boolean | undefined | null>) => {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") sp.set(k, String(v));
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
};
