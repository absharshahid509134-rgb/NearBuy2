import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import bcrypt from "bcryptjs";
import { env } from "./env";

/* ------------------------------------------------------------ passwords -- */

const BCRYPT_ROUNDS = 12;

export const hashPassword = (plain: string): Promise<string> => bcrypt.hash(plain, BCRYPT_ROUNDS);

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  try {
    return await bcrypt.compare(plain, hash);
  } catch {
    return false;
  }
}

/* -------------------------------------------------------------- secrets -- */

export const sha256 = (value: string): string =>
  createHash("sha256").update(value).digest("hex");

/** URL-safe random token used for session cookies and idempotency keys. */
export const randomToken = (bytes = 32): string => randomBytes(bytes).toString("base64url");

/**
 * Human-typable 6-digit handoff code, generated without modulo bias
 * (a plain `% 1000000` would over-represent 000000-003999).
 */
export function generateHandoffCode(): string {
  let n: number;
  do {
    n = randomBytes(4).readUInt32BE(0);
  } while (n >= 4_294_000_000); // largest multiple of 1e6 below 2^32
  return String(n % 1_000_000).padStart(6, "0");
}

/* -------------------------------------------- handoff code at-rest crypto -- */

function encryptionKey(): Buffer {
  const configured = env().HANDOFF_ENCRYPTION_KEY;
  const decoded = Buffer.from(configured, "base64");
  if (decoded.length === 32) return decoded;
  // Tolerates a non-base64 passphrase: still 32 deterministic bytes.
  return createHash("sha256").update(configured).digest();
}

/**
 * Pickup and delivery codes are secrets: they are the only thing standing
 * between a stranger and someone's groceries. They are AES-256-GCM encrypted
 * at rest so a database dump does not hand over live codes, and so we never
 * hold a second plaintext copy anywhere.
 */
export function encryptSecret(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString("base64url"), tag.toString("base64url"), enc.toString("base64url")].join(".");
}

export function decryptSecret(payload: string): string {
  const [ivB64, tagB64, dataB64] = payload.split(".");
  if (!ivB64 || !tagB64 || !dataB64) throw new Error("Malformed encrypted secret");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(ivB64, "base64url"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(dataB64, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

/** Constant-time compare that tolerates different lengths. */
export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  // Hash first so differing lengths do not short-circuit into a length oracle.
  const ha = createHash("sha256").update(ab).digest();
  const hb = createHash("sha256").update(bb).digest();
  return timingSafeEqual(ha, hb);
}

/** "4821" from a stored hint — enough for a rider to read over the phone. */
export const codeHint = (code: string): string => code.slice(-4);
