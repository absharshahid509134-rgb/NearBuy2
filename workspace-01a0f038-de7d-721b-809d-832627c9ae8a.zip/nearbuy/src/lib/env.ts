import { z } from "zod";

const num = (def: number) =>
  z.coerce.number().int().nonnegative().default(def);

const schema = z.object({
  DATABASE_URL: z.string().min(1),
  SESSION_SECRET: z.string().min(16, "SESSION_SECRET must be at least 16 characters"),
  APP_URL: z.string().url().default("http://localhost:3000"),
  HANDOFF_ENCRYPTION_KEY: z.string().min(1),
  STORAGE_DRIVER: z.enum(["local", "s3"]).default("local"),
  S3_BUCKET: z.string().default(""),
  S3_REGION: z.string().default(""),
  S3_ENDPOINT: z.string().default(""),
  S3_ACCESS_KEY_ID: z.string().default(""),
  S3_SECRET_ACCESS_KEY: z.string().default(""),
  S3_PUBLIC_BASE_URL: z.string().default(""),
  MAX_UPLOAD_BYTES: num(5_242_880),
  DELIVERY_BASE_PAISE: num(2500),
  DELIVERY_PER_KM_PAISE: num(400),
  DELIVERY_MIN_PAISE: num(2000),
  DELIVERY_MAX_PAISE: num(6000),
  // Per-IP signup throttle. Raised in test/staging environments, where a
  // whole suite shares one address; the production default stays strict.
  SIGNUP_RATE_LIMIT: num(10),
  LOGIN_RATE_LIMIT: num(8),
  ENABLE_DEMO_ACCOUNTS: z.string().default("false"),
  DEMO_PASSWORD: z.string().default("NearBuy@2026"),
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
});

export type Env = z.infer<typeof schema>;

let cached: Env | null = null;

export function env(): Env {
  if (cached) return cached;
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  - ${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(`Invalid environment configuration:\n${issues}\n\nCopy .env.example to .env and fill it in.`);
  }
  cached = parsed.data;
  return cached;
}

/**
 * Production refuses to boot with development-grade secrets. This is the one
 * place that decides "is this really production", so it is deliberately strict.
 */
export function assertProductionConfig(): void {
  const e = env();
  if (e.NODE_ENV !== "production") return;

  const problems: string[] = [];
  if (e.SESSION_SECRET.includes("dev-only") || e.SESSION_SECRET.includes("change-me")) {
    problems.push("SESSION_SECRET is still the example value");
  }
  if (e.HANDOFF_ENCRYPTION_KEY === "ZGV2LW9ubHktaW5zZWN1cmUta2V5LTMyLWJ5dGVzISE=") {
    problems.push("HANDOFF_ENCRYPTION_KEY is still the example value");
  }
  if (!e.DATABASE_URL.startsWith("postgresql://")) {
    problems.push("DATABASE_URL must be a postgresql:// URL in production");
  }
  if (e.STORAGE_DRIVER !== "s3") {
    problems.push("STORAGE_DRIVER must be 's3' in production (local disk is not durable)");
  }
  if (e.ENABLE_DEMO_ACCOUNTS === "true") {
    problems.push("ENABLE_DEMO_ACCOUNTS must be false in production");
  }
  if (problems.length) {
    throw new Error(
      `Refusing to start in production with unsafe configuration:\n${problems
        .map((p) => `  - ${p}`)
        .join("\n")}`,
    );
  }
}
