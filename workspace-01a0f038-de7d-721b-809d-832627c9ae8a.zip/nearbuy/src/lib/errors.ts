/**
 * Errors safe to show a user. Anything that is not an AppError is treated as
 * an unexpected fault: logged server-side, reported to the client as a
 * generic message. Stack traces never cross the API boundary.
 */
export class AppError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: Record<string, unknown>;

  constructor(status: number, code: string, message: string, details?: Record<string, unknown>) {
    super(message);
    this.name = "AppError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (m: string, d?: Record<string, unknown>) =>
  new AppError(400, "BAD_REQUEST", m, d);
export const unauthorized = (m = "You need to sign in to continue.") =>
  new AppError(401, "UNAUTHORIZED", m);
export const forbidden = (m = "You do not have permission to perform this action.") =>
  new AppError(403, "FORBIDDEN", m);
export const notFound = (m = "We couldn't find what you were looking for.") =>
  new AppError(404, "NOT_FOUND", m);
export const conflict = (m: string, d?: Record<string, unknown>) =>
  new AppError(409, "CONFLICT", m, d);
/** Used for stock/claim races so the UI can explain the competition. */
export const raceLost = (m: string) => new AppError(409, "CONFLICT", m);
