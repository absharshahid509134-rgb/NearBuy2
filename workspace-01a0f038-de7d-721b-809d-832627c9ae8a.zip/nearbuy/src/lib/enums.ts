/**
 * Single source of truth for every status / role value in NearBuy.
 *
 * The Prisma schema stores these as TEXT (Prisma cannot express `enum` on
 * SQLite), which means nothing stops a careless write from inventing a value.
 * So: every value is declared here, every transition is declared here, and
 * nothing outside this file is allowed to hard-code a status string.
 */

export const ROLES = ["CUSTOMER", "SELLER", "RIDER"] as const;
export type Role = (typeof ROLES)[number];

export const ORDER_STATUSES = [
  "PLACED",
  "ACCEPTED",
  "PREPARING",
  "PACKED",
  "READY_FOR_PICKUP",
  "PICKED_UP",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
  "REJECTED",
  "CANCELLED",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const JOB_STATUSES = [
  "AVAILABLE",
  "ASSIGNED",
  "PICKED_UP",
  "OUT_FOR_DELIVERY",
  "COMPLETED",
  "CANCELLED",
] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];

export const RESERVATION_STATUSES = [
  "PENDING",
  "CONFIRMED",
  "REJECTED",
  "EXPIRED",
  "CANCELLED",
  "FULFILLED",
] as const;
export type ReservationStatus = (typeof RESERVATION_STATUSES)[number];

export const STOCK_REQUEST_STATUSES = ["PENDING", "CONFIRMED", "UNAVAILABLE"] as const;
export type StockRequestStatus = (typeof STOCK_REQUEST_STATUSES)[number];

export const FULFILLMENT_TYPES = ["DELIVERY", "PICKUP"] as const;
export type FulfillmentType = (typeof FULFILLMENT_TYPES)[number];

export const STORE_STATUSES = ["DRAFT", "PUBLISHED", "SUSPENDED"] as const;
export type StoreStatus = (typeof STORE_STATUSES)[number];

export const PRODUCT_STATUSES = ["DRAFT", "PUBLISHED", "ARCHIVED"] as const;
export type ProductStatus = (typeof PRODUCT_STATUSES)[number];

export const HANDOFF_EVENTS = [
  "ORDER_PLACED",
  "SELLER_ACCEPTED",
  "SELLER_PREPARING",
  "SELLER_PACKED",
  "READY_FOR_PICKUP",
  "JOB_AVAILABLE",
  "JOB_ASSIGNED",
  "PICKUP_VERIFIED",
  "OUT_FOR_DELIVERY",
  "DELIVERY_VERIFIED",
  "ORDER_REJECTED",
  "ORDER_CANCELLED",
  "PICKUP_CODE_FAILED",
  "DELIVERY_CODE_FAILED",
] as const;
export type HandoffEventType = (typeof HANDOFF_EVENTS)[number];

/** Which role is allowed to drive which transition. Enforced alongside the graph. */
export type Actor = Role | "SYSTEM";

/**
 * The order state machine. `ORDER_STATE_MACHINE[from]` is the set of states
 * that `from` may legally move to, and nothing outside this map is reachable.
 *
 * Note there is deliberately no `PLACED -> DELIVERED`: a seller cannot mark a
 * delivery done, and a rider cannot mark an order ready for pickup.
 */
export const ORDER_STATE_MACHINE: Record<
  OrderStatus,
  { to: OrderStatus; actors: Actor[]; label: string }[]
> = {
  PLACED: [
    { to: "ACCEPTED", actors: ["SELLER"], label: "Accept order" },
    { to: "REJECTED", actors: ["SELLER"], label: "Reject order" },
    { to: "CANCELLED", actors: ["CUSTOMER"], label: "Cancel order" },
  ],
  ACCEPTED: [
    { to: "PREPARING", actors: ["SELLER"], label: "Start preparing" },
    { to: "REJECTED", actors: ["SELLER"], label: "Reject order" },
    { to: "CANCELLED", actors: ["CUSTOMER", "SELLER"], label: "Cancel order" },
  ],
  PREPARING: [
    { to: "PACKED", actors: ["SELLER"], label: "Mark packed" },
    { to: "CANCELLED", actors: ["CUSTOMER", "SELLER"], label: "Cancel order" },
  ],
  PACKED: [
    { to: "READY_FOR_PICKUP", actors: ["SELLER"], label: "Ready for pickup" },
    { to: "CANCELLED", actors: ["CUSTOMER", "SELLER"], label: "Cancel order" },
  ],
  READY_FOR_PICKUP: [
    { to: "PICKED_UP", actors: ["RIDER"], label: "Verify pickup" },
    // Self-pickup has no rider leg, so the seller confirms the collection
    // instead. The order service additionally requires fulfillmentType
    // PICKUP for this edge — a delivered order is never completed by a seller.
    { to: "DELIVERED", actors: ["SELLER"], label: "Confirm customer collected" },
    { to: "CANCELLED", actors: ["CUSTOMER", "SELLER"], label: "Cancel order" },
  ],
  PICKED_UP: [{ to: "OUT_FOR_DELIVERY", actors: ["RIDER"], label: "Start delivery" }],
  OUT_FOR_DELIVERY: [{ to: "DELIVERED", actors: ["RIDER"], label: "Verify delivery" }],
  DELIVERED: [],
  REJECTED: [],
  CANCELLED: [],
};

export type OrderTransition = (typeof ORDER_STATE_MACHINE)[OrderStatus][number];

export function canTransition(from: OrderStatus, to: OrderStatus, actor: Actor): boolean {
  return (ORDER_STATE_MACHINE[from] ?? []).some((t) => t.to === to && t.actors.includes(actor));
}

export function nextTransitions(from: OrderStatus, actor: Actor): OrderTransition[] {
  return (ORDER_STATE_MACHINE[from] ?? []).filter((t) => t.actors.includes(actor));
}

/** The customer-facing verb for a status, in NearBuy's plain-language voice. */
export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PLACED: "Placed",
  ACCEPTED: "Accepted",
  PREPARING: "Preparing",
  PACKED: "Packed",
  READY_FOR_PICKUP: "Ready for pickup",
  PICKED_UP: "Picked up",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered",
  REJECTED: "Rejected",
  CANCELLED: "Cancelled",
};

export const JOB_STATUS_LABEL: Record<JobStatus, string> = {
  AVAILABLE: "Available",
  ASSIGNED: "Assigned",
  PICKED_UP: "Picked up",
  OUT_FOR_DELIVERY: "Out for delivery",
  COMPLETED: "Completed",
  CANCELLED: "Cancelled",
};

export const RESERVATION_STATUS_LABEL: Record<ReservationStatus, string> = {
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  REJECTED: "Declined",
  EXPIRED: "Expired",
  CANCELLED: "Cancelled",
  FULFILLED: "Fulfilled",
};

export const STOCK_REQUEST_STATUS_LABEL: Record<StockRequestStatus, string> = {
  PENDING: "Awaiting store reply",
  CONFIRMED: "Confirmed in stock",
  UNAVAILABLE: "Not available",
};

export const TERMINAL_ORDER_STATUSES: OrderStatus[] = ["DELIVERED", "REJECTED", "CANCELLED"];
export const isTerminal = (s: OrderStatus) => TERMINAL_ORDER_STATUSES.includes(s);

/**
 * Customer-facing status copy. The same persisted status renders differently
 * per role, but the underlying value is identical for all three.
 */
export function customerFacingStatus(s: OrderStatus): string {
  if (s === "READY_FOR_PICKUP") return "Ready for pickup";
  if (s === "PICKED_UP") return "Picked up by rider";
  return ORDER_STATUS_LABEL[s];
}

export function isOrderStatus(v: unknown): v is OrderStatus {
  return typeof v === "string" && (ORDER_STATUSES as readonly string[]).includes(v);
}
export function isRole(v: unknown): v is Role {
  return typeof v === "string" && (ROLES as readonly string[]).includes(v);
}
