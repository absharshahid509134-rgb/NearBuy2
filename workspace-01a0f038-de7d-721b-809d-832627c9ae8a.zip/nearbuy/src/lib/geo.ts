const EARTH_RADIUS_KM = 6371;

export function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(s)));
}

export interface DeliveryPricing {
  basePaise: number;
  perKmPaise: number;
  minPaise: number;
  maxPaise: number;
}

/**
 * Delivery fee is computed on real coordinates, never faked. Pickup is free.
 * The clamp keeps a cross-city address from producing an absurd fee.
 */
export function deliveryFeePaise(
  distanceKm: number,
  pricing: DeliveryPricing,
): number {
  const raw = pricing.basePaise + Math.round(distanceKm * pricing.perKmPaise);
  return Math.min(pricing.maxPaise, Math.max(pricing.minPaise, raw));
}
