import { z } from "zod";
import {
  FULFILLMENT_TYPES,
  JOB_STATUSES,
  ORDER_STATUSES,
  RESERVATION_STATUSES,
  STOCK_REQUEST_STATUSES,
} from "./enums";

/* ------------------------------------------------------------ primitives -- */

const phone = z
  .string()
  .trim()
  .regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number");

/**
 * A store's published contact number. Shops usually list a landline
 * (011-4000 1234), not a mobile, so reusing the strict mobile validator here
 * would reject the number most stores actually have.
 */
const storePhone = z
  .string()
  .trim()
  .min(7, "Enter a contact number")
  .max(20, "That contact number is too long")
  .regex(
    /^(?:[6-9]\d{9}|[0-9]{2,4}[-\s]?[0-9]{3,8}[-\s]?[0-9]{0,6})$/,
    "Enter a valid phone number, for example 9810012345 or 011-4000 1234",
  );

const pincode = z
  .string()
  .trim()
  .regex(/^\d{6}$/, "Enter a valid 6-digit PIN code");

const latitude = z.coerce.number().min(-90).max(90);
const longitude = z.coerce.number().min(-180).max(180);

const time24 = z
  .string()
  .trim()
  .regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use 24-hour HH:MM, for example 09:30");

const dayCodes = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"] as const;

export const addressSchema = z.object({
  label: z.string().trim().min(1).max(40).default("Home"),
  fullName: z.string().trim().min(2, "Enter the recipient's full name").max(80),
  phone,
  line1: z.string().trim().min(4, "Enter the house or flat number and street").max(160),
  line2: z.string().trim().max(160).optional().or(z.literal("")).transform((v) => v || undefined),
  landmark: z.string().trim().max(120).optional().or(z.literal("")).transform((v) => v || undefined),
  city: z.string().trim().min(2).max(80),
  state: z.string().trim().min(2).max(80),
  pincode,
  latitude,
  longitude,
  isDefault: z.coerce.boolean().default(false),
});

/**
 * Deliberately strict. Common leaked-password shapes are rejected outright;
 * complexity rules are length-first, because length is what actually matters.
 */
export const passwordSchema = z
  .string()
  .min(10, "Use at least 10 characters")
  .max(128, "Passwords must be under 128 characters")
  .refine((p) => /[a-z]/.test(p), "Include at least one lowercase letter")
  .refine((p) => /[A-Z]/.test(p), "Include at least one uppercase letter")
  .refine((p) => /\d/.test(p), "Include at least one number")
  .refine((p) => /[^A-Za-z0-9]/.test(p), "Include at least one symbol")
  .refine(
    (p) => !/(nearbuy|welcome|password|qwerty|admin|letmein)/i.test(p),
    "That password is too easy to guess. Please choose something else.",
  );

/* ------------------------------------------------------------------ auth -- */

export const signupSchema = z.object({
  role: z.enum(["CUSTOMER", "SELLER", "RIDER"]),
  name: z.string().trim().min(2, "Enter your full name").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address").max(160),
  phone: phone.optional().or(z.literal("")).transform((v) => v || undefined),
  password: passwordSchema,
  // Seller-only, optional at signup so the account can exist before the store.
  shopName: z.string().trim().min(2).max(100).optional(),
  vehicleType: z.enum(["BIKE", "BICYCLE", "CAR"]).optional(),
});

export const loginSchema = z.object({
  role: z.enum(["CUSTOMER", "SELLER", "RIDER"]),
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

/* ----------------------------------------------------------------- store -- */

const storeBase = z.object({
    name: z.string().trim().min(3, "Enter your store name").max(100),
    description: z.string().trim().min(10, "Describe your store in at least 10 characters").max(1000),
    category: z.string().trim().min(2, "Choose a category").max(60),
    addressLine1: z.string().trim().min(4, "Enter your store address").max(160),
    city: z.string().trim().min(2).max(80),
    state: z.string().trim().min(2).max(80),
    pincode,
    latitude,
    longitude,
    phone: storePhone,
    openingTime: time24,
    closingTime: time24,
    operatingDays: z.array(z.enum(dayCodes)).min(1, "Select at least one operating day"),
    supportsDelivery: z.coerce.boolean().default(true),
    supportsPickup: z.coerce.boolean().default(true),
    deliveryEtaMinutes: z.coerce.number().int().min(10).max(240).default(35),
    isOpen: z.coerce.boolean().default(true),
    status: z.enum(["DRAFT", "PUBLISHED", "SUSPENDED"]).default("DRAFT"),
    // Set by the server after the image upload, never trusted from the client
    // as a filesystem path.
    imageUrl: z
      .string()
      .max(500)
      .refine((v) => v.startsWith("/api/uploads/") || /^https:\/\//.test(v), {
        message: "Image must be an uploaded file or an https URL.",
      })
      .optional(),
});

/**
 * Creating a store validates cross-field rules (at least one fulfilment
 * method, closing after opening). Those rules only make sense on a complete
 * form, so the patch schema is the same fields, all optional, no refinements.
 */
export const storeSchema = storeBase
  .refine((s) => s.supportsDelivery || s.supportsPickup, {
    message: "Enable at least one of delivery or pickup.",
    path: ["supportsDelivery"],
  })
  .refine((s) => s.openingTime < s.closingTime, {
    message: "Closing time must be after opening time.",
    path: ["closingTime"],
  });

export const storePatchSchema = z.object({
  name: storeBase.shape.name.optional(),
  description: storeBase.shape.description.optional(),
  category: storeBase.shape.category.optional(),
  addressLine1: storeBase.shape.addressLine1.optional(),
  city: storeBase.shape.city.optional(),
  state: storeBase.shape.state.optional(),
  pincode: storeBase.shape.pincode.optional(),
  latitude: storeBase.shape.latitude.optional(),
  longitude: storeBase.shape.longitude.optional(),
  phone: storeBase.shape.phone.optional(),
  openingTime: storeBase.shape.openingTime.optional(),
  closingTime: storeBase.shape.closingTime.optional(),
  operatingDays: storeBase.shape.operatingDays.optional(),
  supportsDelivery: storeBase.shape.supportsDelivery.optional(),
  supportsPickup: storeBase.shape.supportsPickup.optional(),
  deliveryEtaMinutes: storeBase.shape.deliveryEtaMinutes.optional(),
  isOpen: storeBase.shape.isOpen.optional(),
  status: storeBase.shape.status.optional(),
  imageUrl: storeBase.shape.imageUrl,
});

/** Address edits: same fields, each optional. Built field by field so this
 *  never has to call .partial() on a schema that may later gain a refinement. */
export const addressPatchSchema = z.object({
  label: addressSchema.shape.label.optional(),
  fullName: addressSchema.shape.fullName.optional(),
  phone: addressSchema.shape.phone.optional(),
  line1: addressSchema.shape.line1.optional(),
  line2: addressSchema.shape.line2,
  landmark: addressSchema.shape.landmark,
  city: addressSchema.shape.city.optional(),
  state: addressSchema.shape.state.optional(),
  pincode: addressSchema.shape.pincode.optional(),
  latitude: addressSchema.shape.latitude.optional(),
  longitude: addressSchema.shape.longitude.optional(),
  isDefault: addressSchema.shape.isDefault.optional(),
});

/* --------------------------------------------------------------- product -- */

export const productSchema = z.object({
  name: z.string().trim().min(2, "Enter the product name").max(120),
  description: z.string().trim().min(5, "Add a short description").max(1000),
  category: z.string().trim().min(2, "Choose a category").max(60),
  unit: z.string().trim().min(1).max(40).default("1 pc"),
  pricePaise: z.coerce.number().int().positive("Price must be greater than ₹0").max(100_000_000),
  compareAtPricePaise: z.coerce
    .number()
    .int()
    .positive()
    .max(100_000_000)
    .optional()
    .nullable(),
  stockQuantity: z.coerce.number().int().min(0, "Stock cannot be negative").max(1_000_000),
  lowStockThreshold: z.coerce.number().int().min(0).max(10_000).default(5),
  isAvailable: z.coerce.boolean().default(true),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).default("DRAFT"),
});

export const productPatchSchema = z.object({
  name: productSchema.shape.name.optional(),
  description: productSchema.shape.description.optional(),
  category: productSchema.shape.category.optional(),
  unit: productSchema.shape.unit.optional(),
  pricePaise: productSchema.shape.pricePaise.optional(),
  compareAtPricePaise: productSchema.shape.compareAtPricePaise,
  stockQuantity: z.coerce.number().int().min(0).max(1_000_000).optional(),
  lowStockThreshold: productSchema.shape.lowStockThreshold.optional(),
  isAvailable: z.coerce.boolean().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(),
});

/* ------------------------------------------------------------------ cart -- */

export const cartAddSchema = z.object({
  productId: z.string().cuid().or(z.string().min(1)),
  quantity: z.coerce.number().int().min(1, "Quantity must be at least 1").max(99),
});

export const cartUpdateSchema = z.object({
  quantity: z.coerce.number().int().min(0).max(99),
});

/* -------------------------------------------------------------- checkout -- */

export const checkoutSchema = z.object({
  // Required on the request, but never used as authority: the server reloads
  // prices, stock and store status from the database.
  fulfillmentType: z.enum(FULFILLMENT_TYPES),
  addressId: z.string().min(1, "Choose a delivery address").nullable().optional(),
  idempotencyKey: z.string().min(8).max(120),
});

/* ------------------------------------------------ reservations / requests -- */

export const reservationSchema = z.object({
  productId: z.string().min(1),
  quantity: z.coerce.number().int().min(1).max(999),
});

export const stockRequestSchema = z.object({
  productId: z.string().min(1),
  quantity: z.coerce.number().int().min(1).max(999),
});

export const reservationRespondSchema = z.object({
  status: z.enum(["CONFIRMED", "REJECTED"]),
  response: z.string().trim().max(500).optional(),
  holdStock: z.coerce.boolean().default(false),
});

export const stockRequestRespondSchema = z.object({
  status: z.enum(STOCK_REQUEST_STATUSES).refine((s) => s !== "PENDING", {
    message: "Choose whether the item is in stock.",
  }),
  response: z.string().trim().max(500).optional(),
});

/* ---------------------------------------------------------------- orders -- */

export const orderStatusSchema = z.object({
  status: z.enum(ORDER_STATUSES),
});

export const jobActionSchema = z.object({
  code: z.string().trim().regex(/^\d{6}$/, "Enter the 6-digit code").optional(),
});

/* --------------------------------------------------------------- profile -- */

export const riderProfileSchema = z.object({
  vehicleType: z.enum(["BIKE", "BICYCLE", "CAR"]),
  vehicleNumber: z.string().trim().min(4, "Enter a valid vehicle number").max(20),
  onboardingStep: z.coerce.number().int().min(0).max(3).default(3),
});

export const profileSchema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: phone.optional().or(z.literal("")),
});

/* ------------------------------------------------------------- discovery -- */

export const searchQuerySchema = z.object({
  q: z.string().trim().max(100).optional().default(""),
  category: z.string().trim().max(60).optional(),
  storeId: z.string().trim().max(64).optional(),
  minPrice: z.coerce.number().int().min(0).optional(),
  maxPrice: z.coerce.number().int().min(0).optional(),
  inStock: z
    .enum(["true", "false"])
    .optional()
    .transform((v) => v === "true"),
  sort: z.enum(["relevance", "price_asc", "price_desc", "newest"]).default("relevance"),
  page: z.coerce.number().int().min(1).max(500).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(24),
  lat: z.coerce.number().min(-90).max(90).optional(),
  lng: z.coerce.number().min(-180).max(180).optional(),
});

export const storeSearchSchema = z.object({
  q: z.string().trim().max(100).optional().default(""),
  category: z.string().trim().max(60).optional(),
  open: z
    .enum(["true", "false"])
    .optional()
    .transform((v) => v === "true"),
  lat: z.coerce.number().min(-90).max(90).optional(),
  lng: z.coerce.number().min(-180).max(180).optional(),
  sort: z.enum(["distance", "name", "newest"]).default("distance"),
  page: z.coerce.number().int().min(1).max(500).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(24),
});

export type SignupInput = z.infer<typeof signupSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type StoreInput = z.infer<typeof storeSchema>;
export type ProductInput = z.infer<typeof productSchema>;
export type CheckoutInput = z.infer<typeof checkoutSchema>;
export type AddressInput = z.infer<typeof addressSchema>;
