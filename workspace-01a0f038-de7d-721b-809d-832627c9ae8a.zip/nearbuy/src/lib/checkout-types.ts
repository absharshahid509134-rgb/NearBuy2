/** Server-computed checkout preview. The client renders it; it never computes it. */
export interface CheckoutPreview {
  groups: Array<{
    storeId: string;
    storeName: string;
    storeSlug: string;
    subtotalPaise: number;
    deliveryFeePaise: number;
    items: Array<{
      id: string;
      name: string;
      quantity: number;
      lineTotalPaise: number;
    }>;
  }>;
  addresses: Array<{
    id: string;
    label: string;
    fullName: string;
    phone: string;
    line1: string;
    line2: string | null;
    city: string;
    pincode: string;
    isDefault: boolean;
  }>;
  fulfillmentAvailable: { DELIVERY: boolean; PICKUP: boolean };
  subtotalPaise: number;
  deliveryFeePaise: number;
  grandTotalPaise: number;
  issues: string[];
  hasBlockingIssues: boolean;
}
