/** Shape returned by GET /api/cart, shared by the server page and client view. */
export interface CartView {
  groups: Array<{
    store: {
      id: string;
      name: string;
      slug: string;
      isOpen: boolean;
      status: string;
    };
    items: Array<{
      id: string;
      productId: string;
      name: string;
      imageUrl: string | null;
      unit: string;
      pricePaise: number;
      quantity: number;
      availableStock: number;
      lineTotalPaise: number;
      note: string | null;
    }>;
    subtotalPaise: number;
    itemCount: number;
  }>;
  itemCount: number;
  subtotalPaise: number;
  storeCount: number;
  issues: string[];
  hasBlockingIssues: boolean;
}
