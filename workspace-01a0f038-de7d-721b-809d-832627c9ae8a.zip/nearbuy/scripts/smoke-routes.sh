#!/usr/bin/env bash
# Route smoke test: every page must return a real HTTP status (no redirect loops,
# no 500s) for the correct role, and the wrong role must be redirected away.
set -u
BASE="${NEARBUY_BASE:-http://127.0.0.1:3000}"
JAR_DIR="$(mktemp -d)"
CUST="$JAR_DIR/cust.txt"
SELL="$JAR_DIR/sell.txt"
RIDE="$JAR_DIR/ride.txt"
ANON="$JAR_DIR/anon.txt"
: > "$CUST"; : > "$SELL"; : > "$RIDE"; : > "$ANON"
fail=0

code() { curl -s -o /dev/null -w '%{http_code}' -b "$1" -c "$1" "$BASE$2"; }
loc()  { curl -s -o /dev/null -w '%{redirect_url}' -b "$1" -c "$1" "$BASE$2"; }

login() { # email role jar
  curl -s -o /dev/null -w '%{http_code}' -b "$3" -c "$3" \
    -H 'Content-Type: application/json' \
    -d "{\"role\":\"$2\",\"email\":\"$1\",\"password\":\"NearBuy@2026\"}" \
    "$BASE/api/auth/login"
}

check() { # label expected actual
  if [ "$2" = "$3" ]; then printf '  ok   %-46s %s\n' "$1" "$3"
  else printf '  FAIL %-46s expected %s got %s\n' "$1" "$2" "$3"; fail=$((fail+1)); fi
}

echo "== public (signed out) =="
check "GET /"                      200 "$(code "$ANON" /)"
check "GET /stores"                200 "$(code "$ANON" /stores)"
check "GET /customer/login"        200 "$(code "$ANON" /customer/login)"
check "GET /customer/signup"       200 "$(code "$ANON" /customer/signup)"
check "GET /seller/login"          200 "$(code "$ANON" /seller/login)"
check "GET /seller/signup"         200 "$(code "$ANON" /seller/signup)"
check "GET /rider/login"           200 "$(code "$ANON" /rider/login)"
check "GET /rider/signup"          200 "$(code "$ANON" /rider/signup)"
check "GET /api/health"            200 "$(code "$ANON" /api/health)"
echo "  -> unauthenticated /customer redirects to: $(loc "$ANON" /customer)"

echo "== demo logins =="
check "POST /api/auth/login customer" 200 "$(login customer.demo@nearbuy.app CUSTOMER "$CUST")"
check "POST /api/auth/login seller"   200 "$(login seller.demo@nearbuy.app   SELLER  "$SELL")"
check "POST /api/auth/login rider"    200 "$(login rider.demo@nearbuy.app    RIDER   "$RIDE")"

echo "== customer workspace =="
for p in /customer /customer/cart /customer/orders /customer/addresses \
         /customer/reservations /customer/stock-requests /customer/profile /customer/search; do
  check "GET $p" 200 "$(code "$CUST" "$p")"
done
check "GET /customer/checkout (empty cart)" 200 "$(code "$CUST" /customer/checkout)"

echo "== seller workspace =="
for p in /seller /seller/products /seller/inventory /seller/orders /seller/inbox \
         /seller/reservations /seller/stock-requests /seller/performance \
         /seller/settings /seller/profile; do
  check "GET $p" 200 "$(code "$SELL" "$p")"
done

echo "== rider workspace =="
for p in /rider /rider/jobs /rider/earnings /rider/onboarding /rider/profile; do
  check "GET $p" 200 "$(code "$RIDE" "$p")"
done

echo "== cross-role isolation (must bounce away from the other workspace) =="
for spec in "$CUST:/seller" "$CUST:/rider" "$SELL:/customer" "$SELL:/rider" "$RIDE:/customer" "$RIDE:/seller"; do
  jar="${spec%%:*}"; path="${spec##*:}"
  target=$(loc "$jar" "$path")
  case "$target" in
    http*://*/customer*|http*://*/seller*|http*://*/rider*)
      printf '  ok   %-20s -> %s\n' "$path" "$target" ;;
    *) printf '  FAIL %-20s -> %s\n' "$path" "${target:-<none>}"; fail=$((fail+1)) ;;
  esac
done

echo
if [ "$fail" -eq 0 ]; then echo "ALL ROUTES OK"; else echo "$fail FAILURE(S)"; fi
rm -rf "$JAR_DIR"
exit $((fail > 0))
