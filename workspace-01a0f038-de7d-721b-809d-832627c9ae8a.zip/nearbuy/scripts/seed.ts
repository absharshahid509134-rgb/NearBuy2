/**
 * NearBuy demo seed — idempotent.
 *
 *   npm run db:seed
 *
 * Creates the three demo accounts, their store, and a realistic catalogue so
 * the app is explorable without typing seed data by hand. Running it twice
 * changes nothing the second time: every write is an upsert keyed on a natural
 * unique column (email / slug), never a blind create.
 *
 * SAFETY: demo accounts are only created when ENABLE_DEMO_ACCOUNTS=true.
 * Production boot refuses to run with that flag on, and this script refuses to
 * create demo users when it is off. Demo credentials never come from this file
 * at runtime — the accounts are real rows hashed with the app's own bcrypt
 * implementation, and they authenticate through the normal login endpoint.
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const DEMO = {
  enabled: (process.env.ENABLE_DEMO_ACCOUNTS ?? "false").toLowerCase() === "true",
  password: process.env.DEMO_PASSWORD ?? "NearBuy@2026",
};

const ACCOUNTS = {
  customer: { name: "Aarav Sharma", email: "customer.demo@nearbuy.app", phone: "9810012345" },
  seller: { name: "Rahul Verma", email: "seller.demo@nearbuy.app", phone: "9810023456" },
  rider: { name: "Arjun Kumar", email: "rider.demo@nearbuy.app", phone: "9810034567" },
} as const;

/** Dwarka, New Delhi — used for the demo store and the demo customer address. */
const DWARKA = { lat: 28.5921, lng: 77.046 };

const DEMO_STORE = {
  name: "Dwarka Fresh Mart",
  slug: "dwarka-fresh-mart",
  description:
    "Your everyday neighbourhood grocery in Dwarka — fresh produce, dairy, staples and household essentials, delivered across Sector 12 to Sector 22 in under 40 minutes.",
  category: "Grocery",
  addressLine1: "Plot 14, Sector 12, Dwarka",
  city: "New Delhi",
  state: "Delhi",
  pincode: "110075",
  latitude: DWARKA.lat,
  longitude: DWARKA.lng,
  phone: "011-4567 8901",
  openingTime: "07:00",
  closingTime: "22:00",
  operatingDays: "MON,TUE,WED,THU,FRI,SAT,SUN",
  imageUrl: "/seed/stores/dwarka-fresh-mart.jpg",
  // Exactly the catalogue specified for the demo seller.
  products: [
    { name: "Amul Taaza Milk 1L", price: 68, stock: 20, category: "Dairy", unit: "1 L",
      description: "Full-cream toned milk, homogenised and pasteurised. Chilled and delivered fresh every morning from the local depot.", image: "/seed/products/amul-taaza-milk.jpg" },
    { name: "Aashirvaad Atta 5kg", price: 285, stock: 15, category: "Grocery", unit: "5 kg",
      description: "Chakki atta made from whole wheat. Stone-milled for a softer, fresher rotis that stay soft for hours.", image: "/seed/products/aashirvaad-atta.jpg" },
    { name: "Tata Salt 1kg", price: 28, stock: 30, category: "Grocery", unit: "1 kg",
      description: "Iodised vacuum salt, free-flowing and impurity-free. The everyday staple for every Indian kitchen.", image: "/seed/products/tata-salt.jpg" },
    { name: "Fortune Sunflower Oil 1L", price: 145, stock: 12, category: "Grocery", unit: "1 L",
      description: "Refined sunflower oil with vitamin A and D fortification. Light, healthy and ideal for everyday cooking.", image: "/seed/products/fortune-oil.jpg" },
    { name: "Britannia Bread 400g", price: 45, stock: 18, category: "Bakery", unit: "400 g",
      description: "Soft white sandwich bread baked fresh daily. No artificial preservatives, no artificial colours.", image: "/seed/products/britannia-bread.jpg" },
  ],
};

/** Additional neighbourhood stores so discovery feels like a real marketplace. */
const SUPPORT_STORES = [
  {
    name: "Sharma General Store", slug: "sharma-general-store", category: "Grocery",
    description: "Family-run provision shop since 1994. Snacks, pulses, spices and all the little things you forget until you need them.",
    addressLine1: "B-42, Sector 9, Dwarka", city: "New Delhi", state: "Delhi", pincode: "110077",
    latitude: 28.5794, longitude: 77.0573, phone: "011-4567 1122", openingTime: "08:00", closingTime: "21:30",
    imageUrl: "/seed/stores/sharma-general-store.jpg",
    products: [
      { name: "Maggi 2-Minute Noodles 12-pack", price: 168, stock: 40, category: "Snacks", unit: "12 x 70 g", description: "The original masala-taste instant noodles. Twelve-pack, ready in two minutes.", image: "/seed/products/maggi-noodles.jpg" },
      { name: "Tata Sampann Toor Dal 1kg", price: 189, stock: 22, category: "Grocery", unit: "1 kg", description: "Unpolished toor dal, rich in protein and naturally rich in taste.", image: "/seed/products/sampann-dal.jpg" },
      { name: "Surf Excel Matic 2kg", price: 265, stock: 16, category: "Household", unit: "2 kg", description: "Matic detergent powder that removes tough stains in a single wash.", image: "/seed/products/surf-excel.jpg" },
    ],
  },
  {
    name: "City Pharmacy", slug: "city-pharmacy", category: "Pharmacy",
    description: "Licensed neighbourhood chemist. Prescription fulfilment, OTC medicines, first aid and wellness essentials — open late.",
    addressLine1: "A-7, Sector 12, Dwarka", city: "New Delhi", state: "Delhi", pincode: "110075",
    latitude: 28.5946, longitude: 77.0503, phone: "011-4567 3344", openingTime: "09:00", closingTime: "23:00",
    imageUrl: "/seed/stores/city-pharmacy.jpg",
    products: [
      { name: "Crocin 650mg Strip of 15", price: 89, stock: 50, category: "Pharmacy", unit: "15 tablets", description: "Paracetamol 650mg for relief from fever, headache and body pain.", image: "/seed/products/crocin.jpg" },
      { name: "Band-Aid Waterproof 20-pack", price: 120, stock: 25, category: "Pharmacy", unit: "20 strips", description: "Waterproof adhesive bandages that stay put through showers.", image: "/seed/products/band-aid.jpg" },
      { name: "Digital Thermometer", price: 210, stock: 14, category: "Pharmacy", unit: "1 pc", description: "Fast-reading digital thermometer with fever alarm and memory function.", image: "/seed/products/thermometer.jpg" },
    ],
  },
  {
    name: "Raj Fruits & Vegetables", slug: "raj-fruits-vegetables", category: "Fruits & Vegetables",
    description: "Fruit and vegetable shop sourcing directly from Azadpur each morning. Weighed honestly, priced fairly.",
    addressLine1: "Shop 3, Sector 15, Dwarka", city: "New Delhi", state: "Delhi", pincode: "110078",
    latitude: 28.5676, longitude: 77.0601, phone: "011-4567 5566", openingTime: "06:30", closingTime: "20:00",
    imageUrl: "/seed/stores/raj-fruits-vegetables.jpg",
    products: [
      { name: "Shimla Apples (Kinnaur)", price: 185, stock: 30, category: "Fruits & Vegetables", unit: "1 kg", description: "Crisp, sweet Kinnaur apples graded and packed fresh each morning.", image: "/seed/products/shimla-apples.jpg" },
      { name: "Nashik Bananas", price: 62, stock: 45, category: "Fruits & Vegetables", unit: "1 dozen", description: "Naturally ripened Robusta bananas — naturally sweet, no chemical ripening.", image: "/seed/products/bananas.jpg" },
      { name: "Local Tomato", price: 38, stock: 60, category: "Fruits & Vegetables", unit: "1 kg", description: "Vine-ripened tomatoes from local farms, picked the same morning.", image: "/seed/products/tomatoes.jpg" },
    ],
  },
  {
    name: "Daily Needs Corner", slug: "daily-needs-corner", category: "Personal Care",
    description: "Everything for the morning routine — soap, shampoo, toothpaste, tissues and baby care — at fair neighbourhood prices.",
    addressLine1: "C-19, Sector 11, Dwarka", city: "New Delhi", state: "Delhi", pincode: "110075",
    latitude: 28.5857, longitude: 77.0428, phone: "011-4567 7788", openingTime: "09:30", closingTime: "21:00",
    imageUrl: "/seed/stores/daily-needs-corner.jpg",
    products: [
      { name: "Dove Beauty Bar 100g (4-pack)", price: 196, stock: 28, category: "Personal Care", unit: "4 x 100 g", description: "Cleansing bar with moisturising cream. Gentle enough for daily use.", image: "/seed/products/dove-soap.jpg" },
      { name: "Colgate Strong Teeth 200g", price: 95, stock: 35, category: "Personal Care", unit: "200 g", description: "Cavity protection toothpaste with fluoride and mint freshness.", image: "/seed/products/colgate.jpg" },
    ],
  },
  {
    name: "Sector 22 Stationery", slug: "sector-22-stationery", category: "Stationery",
    description: "School and office stationery, printing and photocopies. Exam forms, notebooks and art supplies in one place.",
    addressLine1: "D-22, Sector 22, Dwarka", city: "New Delhi", state: "Delhi", pincode: "110046",
    latitude: 28.5569, longitude: 77.0689, phone: "011-4567 9900", openingTime: "09:00", closingTime: "20:30",
    imageUrl: "/seed/stores/sector-22-stationery.jpg",
    products: [
      { name: "Classmate Notebook A4 150 pages", price: 78, stock: 60, category: "Stationery", unit: "1 pc", description: "A4 ruled notebook with 150 pages and a durable plastic cover.", image: "/seed/products/classmate-notebook.jpg" },
      { name: "DOMS Geometry Box", price: 145, stock: 24, category: "Stationery", unit: "1 pc", description: "Complete geometry box with compass, scale, protractor and set squares.", image: "/seed/products/geometry-box.jpg" },
    ],
  },
];

async function upsertUser(input: { name: string; email: string; phone: string }, role: string) {
  const passwordHash = await bcrypt.hash(DEMO.password, 12);
  return prisma.user.upsert({
    where: { email: input.email },
    create: {
      role, name: input.name, email: input.email, phone: input.phone,
      passwordHash, isDemo: true, status: "ACTIVE",
    },
    update: { name: input.name, role, status: "ACTIVE" },
  });
}

async function main() {
  console.log("→ Seeding NearBuy demo data\n");

  if (!DEMO.enabled) {
    console.log("  ENABLE_DEMO_ACCOUNTS is not set to 'true'.");
    console.log("  Demo accounts were NOT created. This is the expected behaviour in production.");
    console.log("  To create them in a dev/staging environment, set ENABLE_DEMO_ACCOUNTS=true.\n");
    return;
  }

  const customer = await upsertUser(ACCOUNTS.customer, "CUSTOMER");
  const seller = await upsertUser(ACCOUNTS.seller, "SELLER");
  const rider = await upsertUser(ACCOUNTS.rider, "RIDER");
  console.log(`  ✓ 3 demo accounts (password: ${DEMO.password})`);

  await prisma.sellerProfile.upsert({
    where: { userId: seller.id },
    create: { userId: seller.id, shopName: DEMO_STORE.name },
    update: { shopName: DEMO_STORE.name },
  });

  await prisma.riderProfile.upsert({
    where: { userId: rider.id },
    create: {
      userId: rider.id, vehicleType: "BIKE", vehicleNumber: "DL 1L AB 4821",
      isOnboarded: true, onboardingStep: 3,
    },
    update: { isOnboarded: true, vehicleNumber: "DL 1L AB 4821" },
  });

  // Customer profile: one real saved address, and an empty cart.
  const addressCount = await prisma.address.count({ where: { customerId: customer.id } });
  if (addressCount === 0) {
    await prisma.address.create({
      data: {
        customerId: customer.id, label: "Home",
        fullName: ACCOUNTS.customer.name, phone: ACCOUNTS.customer.phone,
        line1: "Flat 402, Palm Grove Apartments",
        line2: "Sector 12, near Bank of Baroda",
        landmark: "Opposite City Park",
        city: "New Delhi", state: "Delhi", pincode: "110075",
        latitude: 28.5934, longitude: 77.0489, isDefault: true,
      },
    });
  }
  await prisma.cart.upsert({
    where: { customerId: customer.id },
    create: { customerId: customer.id },
    update: {},
  });
  console.log("  ✓ customer profile, saved address, empty cart");

  // --- demo seller's store + exact specified catalogue -----------------------
  const store = await prisma.store.upsert({
    where: { sellerId: seller.id },
    create: {
      sellerId: seller.id, name: DEMO_STORE.name, slug: DEMO_STORE.slug,
      description: DEMO_STORE.description, category: DEMO_STORE.category,
      addressLine1: DEMO_STORE.addressLine1, city: DEMO_STORE.city, state: DEMO_STORE.state,
      pincode: DEMO_STORE.pincode, latitude: DEMO_STORE.latitude, longitude: DEMO_STORE.longitude,
      phone: DEMO_STORE.phone, openingTime: DEMO_STORE.openingTime, closingTime: DEMO_STORE.closingTime,
      operatingDays: DEMO_STORE.operatingDays, imageUrl: DEMO_STORE.imageUrl,
      isOpen: true, status: "PUBLISHED", publishedAt: new Date(),
      supportsDelivery: true, supportsPickup: true, deliveryEtaMinutes: 35,
    },
    update: {
      name: DEMO_STORE.name, status: "PUBLISHED", isOpen: true,
      ...(DEMO_STORE.imageUrl ? { imageUrl: DEMO_STORE.imageUrl } : {}),
    },
  });

  let productCount = 0;
  for (const p of DEMO_STORE.products) {
    const id = await stableProductId(store.id, p.name);
    await prisma.product.upsert({
      where: { id },
      create: {
        id,
        storeId: store.id, name: p.name, description: p.description, category: p.category,
        unit: p.unit, imageUrl: p.image, pricePaise: p.price * 100,
        status: "PUBLISHED", isAvailable: true,
        inventory: { create: { stockQuantity: p.stock, lowStockThreshold: 5 } },
      },
      // Only reset stock if the row is brand new; otherwise leave the seller's
      // own inventory edits alone.
      update: { pricePaise: p.price * 100, imageUrl: p.image, status: "PUBLISHED" },
    });
    productCount++;
  }
  console.log(`  ✓ ${DEMO_STORE.name} (published, open) with ${productCount} products`);

  // --- supporting stores (distinct sellers) --------------------------------
  let supportCount = 0;
  for (const [i, s] of SUPPORT_STORES.entries()) {
    const ownerEmail = `store${i + 1}.demo@nearbuy.app`;
    const owner = await upsertUser(
      { name: `${s.name} Owner`, email: ownerEmail, phone: `9810100${(i + 10).toString().padStart(2, "0")}` },
      "SELLER",
    );
    await prisma.sellerProfile.upsert({
      where: { userId: owner.id },
      create: { userId: owner.id, shopName: s.name },
      update: { shopName: s.name },
    });

    const st = await prisma.store.upsert({
      where: { slug: s.slug },
      create: {
        sellerId: owner.id, name: s.name, slug: s.slug, description: s.description,
        category: s.category, addressLine1: s.addressLine1, city: s.city, state: s.state,
        pincode: s.pincode, latitude: s.latitude, longitude: s.longitude, phone: s.phone,
        openingTime: s.openingTime, closingTime: s.closingTime,
        operatingDays: "MON,TUE,WED,THU,FRI,SAT,SUN", imageUrl: s.imageUrl,
        isOpen: true, status: "PUBLISHED", publishedAt: new Date(),
        supportsDelivery: true, supportsPickup: true, deliveryEtaMinutes: 40,
      },
      update: { isOpen: true, status: "PUBLISHED" },
    });

    for (const p of s.products) {
      const id = await stableProductId(st.id, p.name);
      await prisma.product.upsert({
        where: { id },
        create: {
          id,
          storeId: st.id, name: p.name, description: p.description, category: p.category,
          unit: p.unit, imageUrl: p.image, pricePaise: p.price * 100,
          status: "PUBLISHED", isAvailable: true,
          inventory: { create: { stockQuantity: p.stock, lowStockThreshold: 5 } },
        },
        update: { pricePaise: p.price * 100, imageUrl: p.image, status: "PUBLISHED" },
      });
    }
    supportCount++;
  }
  console.log(`  ✓ ${supportCount} supporting neighbourhood stores`);

  const [stores, products] = await Promise.all([prisma.store.count(), prisma.product.count()]);
  console.log(`\n  Database now holds ${stores} stores and ${products} products.`);
}

/**
 * Products have no natural unique column, so the natural key (store + name) is
 * folded into a deterministic id. Re-running the seed therefore updates the
 * same rows instead of creating duplicates — the id is passed to `create` as
 * well as `where`, which is the part that is easy to forget and silently
 * turns an upsert back into an insert.
 */
async function stableProductId(storeId: string, name: string): Promise<string> {
  const { createHash } = await import("node:crypto");
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
  return `seed_${createHash("sha1").update(`${storeId}:${slug}`).digest("hex").slice(0, 22)}`;
}

main()
  .then(async () => { await prisma.$disconnect(); })
  .catch(async (e) => { console.error("\n  Seed failed:", e); await prisma.$disconnect(); process.exit(1); });
